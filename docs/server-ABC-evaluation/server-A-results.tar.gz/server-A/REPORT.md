# 固定速率性能测试

已记录 625 / 768 个任务。计划见 plan.json，逐次数据见 summary.csv，配置统计见 cases.csv。

发送不等待回复或决定。发送期吞吐只计该窗口内的执行结果；整批吞吐和整批延迟仅在全部计划请求取得执行结果时给出。未完成、拒绝、发送器限制保留，不混入完整延迟。

下表为各次运行中位数 [最小值, 最大值]，不是合并请求后的分位数。整批完成列给出完整样本轮数；未完成轮次不会被当成零延迟。校准项仅用于检查服务器差异，不计入正式主矩阵。


## calibration

| 服务器 / 场景 | CPU | 版本 | 已记录 / 计划 | 整批完成 | 发送期吞吐（条/s） | 整批吞吐（条/s） | 整批平均延迟（ms） | 整批 P99（ms） | 未完成请求（条） |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| A / calibration | 2c2t-g2 | baseline | 1/1 | 1/1 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 7.46 [7.46, 7.46] | 15.07 [15.07, 15.07] | 0 |
| A / calibration | 2c2t-g2 | v000 | 1/1 | 1/1 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.39 [2.39, 2.39] | 4.94 [4.94, 4.94] | 0 |
| A / calibration | 2c2t-g2 | v003 | 1/1 | 1/1 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.48 [2.48, 2.48] | 4.79 [4.79, 4.79] | 0 |

| 服务器 / 场景 | CPU | 版本 | 状态次数 | 未发出（条） | 拒绝（条） | 等待结束（条） | 历史未排空轮次 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
| A / calibration | 2c2t-g2 | baseline | {"measured": 1} | 0 | 0 | 0 | 0 |
| A / calibration | 2c2t-g2 | v000 | {"measured": 1} | 0 | 0 | 0 | 0 |
| A / calibration | 2c2t-g2 | v003 | {"measured": 1} | 0 | 0 | 0 | 0 |

## performance

| 服务器 / 场景 | CPU | 版本 | 已记录 / 计划 | 整批完成 | 发送期吞吐（条/s） | 整批吞吐（条/s） | 整批平均延迟（ms） | 整批 P99（ms） | 未完成请求（条） |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| A / ordinary-balanced-r100 | 1c1t-g1 | baseline | 5/5 | 5/5 | 99.97 [99.97, 100.00] | 100.00 [99.99, 100.00] | 9.93 [9.25, 11.68] | 19.25 [18.78, 19.76] | 0 |
| A / ordinary-balanced-r100 | 1c1t-g1 | v000 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.67 [2.67, 2.69] | 5.98 [5.83, 6.22] | 0 |
| A / ordinary-balanced-r100 | 1c1t-g1 | v003 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.89 [2.84, 2.96] | 8.29 [7.27, 9.90] | 0 |
| A / ordinary-balanced-r100 | 2c2t-g2 | baseline | 5/5 | 5/5 | 99.97 [99.97, 100.00] | 99.99 [99.98, 100.00] | 9.13 [8.57, 9.94] | 15.01 [14.49, 16.17] | 0 |
| A / ordinary-balanced-r100 | 2c2t-g2 | v000 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.37 [2.35, 2.38] | 4.01 [3.89, 4.22] | 0 |
| A / ordinary-balanced-r100 | 2c2t-g2 | v003 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.47 [2.46, 2.48] | 4.65 [4.42, 4.71] | 0 |
| A / ordinary-balanced-r100 | 2c4t-g4 | baseline | 5/5 | 5/5 | 99.97 [99.97, 100.00] | 100.00 [99.99, 100.00] | 8.21 [7.51, 10.33] | 13.96 [12.51, 14.39] | 0 |
| A / ordinary-balanced-r100 | 2c4t-g4 | v000 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.24 [2.24, 2.25] | 3.55 [3.47, 3.72] | 0 |
| A / ordinary-balanced-r100 | 2c4t-g4 | v003 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.32 [2.31, 2.32] | 3.78 [3.73, 4.08] | 0 |
| A / ordinary-balanced-r1200 | 1c1t-g1 | baseline | 5/5 | 0/5 | 19.67 [19.43, 20.50] | — | — | — | 176421 |
| A / ordinary-balanced-r1200 | 1c1t-g1 | v000 | 5/5 | 0/5 | 205.37 [205.03, 215.20] | — | — | — | 8663 |
| A / ordinary-balanced-r1200 | 1c1t-g1 | v003 | 5/5 | 0/5 | 107.47 [105.10, 109.87] | — | — | — | 97515 |
| A / ordinary-balanced-r1200 | 2c2t-g2 | baseline | 5/5 | 0/5 | 29.23 [29.13, 30.37] | — | — | — | 160243 |
| A / ordinary-balanced-r1200 | 2c2t-g2 | v000 | 5/5 | 5/5 | 1,199.90 [1,199.83, 1,199.97] | 1,199.93 [1,199.78, 1,199.96] | 3.36 [3.11, 3.69] | 20.95 [16.90, 26.43] | 0 |
| A / ordinary-balanced-r1200 | 2c2t-g2 | v003 | 5/5 | 4/5 | 1,199.90 [1,199.60, 1,199.97] | 1,199.76 [1,199.29, 1,199.98] | 4.11 [4.01, 4.49] | 26.91 [25.36, 35.33] | 1 |
| A / ordinary-balanced-r1200 | 2c4t-g4 | baseline | 5/5 | 0/5 | 624.77 [598.70, 710.53] | — | — | — | 53560 |
| A / ordinary-balanced-r1200 | 2c4t-g4 | v000 | 5/5 | 4/5 | 1,199.97 [1,199.87, 1,199.97] | 1,199.96 [1,199.92, 1,199.99] | 1.12 [1.10, 1.17] | 3.42 [3.12, 3.66] | 1 |
| A / ordinary-balanced-r1200 | 2c4t-g4 | v003 | 5/5 | 4/5 | 1,199.93 [1,199.87, 1,199.97] | 1,199.98 [1,199.95, 1,200.00] | 1.19 [1.14, 1.25] | 3.64 [3.17, 4.77] | 1 |
| A / ordinary-balanced-r1800 | 1c1t-g1 | baseline | 5/5 | 0/5 | 17.37 [17.03, 17.50] | — | — | — | 266312 |
| A / ordinary-balanced-r1800 | 1c1t-g1 | v000 | 5/5 | 0/5 | 166.93 [150.90, 181.47] | — | — | — | 102784 |
| A / ordinary-balanced-r1800 | 1c1t-g1 | v003 | 5/5 | 0/5 | 84.80 [82.23, 86.27] | — | — | — | 191240 |
| A / ordinary-balanced-r1800 | 2c2t-g2 | baseline | 5/5 | 0/5 | 25.50 [24.77, 25.80] | — | — | — | 250368 |
| A / ordinary-balanced-r1800 | 2c2t-g2 | v000 | 5/5 | 0/5 | 603.33 [539.90, 629.00] | — | — | — | 37505 |
| A / ordinary-balanced-r1800 | 2c2t-g2 | v003 | 5/5 | 0/5 | 131.83 [128.73, 132.63] | — | — | — | 155766 |
| A / ordinary-balanced-r1800 | 2c4t-g4 | baseline | 5/5 | 0/5 | 37.03 [35.50, 39.50] | — | — | — | 236174 |
| A / ordinary-balanced-r1800 | 2c4t-g4 | v000 | 5/5 | 3/5 | 1,799.90 [1,799.87, 1,799.97] | 1,799.89 [1,799.84, 1,799.92] | 1.72 [1.67, 1.77] | 16.37 [13.07, 16.45] | 2 |
| A / ordinary-balanced-r1800 | 2c4t-g4 | v003 | 5/5 | 3/5 | 1,799.87 [1,799.77, 1,799.90] | 1,799.82 [1,799.80, 1,799.85] | 1.77 [1.75, 1.94] | 14.31 [13.82, 20.38] | 3 |
| A / ordinary-balanced-r2600 | 1c1t-g1 | baseline | 5/5 | 0/5 | 15.90 [15.13, 16.63] | — | — | — | 386837 |
| A / ordinary-balanced-r2600 | 1c1t-g1 | v000 | 5/5 | 0/5 | 153.07 [142.37, 165.70] | — | — | — | 229557 |
| A / ordinary-balanced-r2600 | 1c1t-g1 | v003 | 5/5 | 0/5 | 78.73 [77.93, 80.07] | — | — | — | 311808 |
| A / ordinary-balanced-r2600 | 2c2t-g2 | baseline | 5/5 | 0/5 | 22.73 [21.73, 23.30] | — | — | — | 371019 |
| A / ordinary-balanced-r2600 | 2c2t-g2 | v000 | 5/5 | 0/5 | 492.33 [456.70, 581.93] | — | — | — | 171089 |
| A / ordinary-balanced-r2600 | 2c2t-g2 | v003 | 5/5 | 0/5 | 114.27 [113.80, 116.13] | — | — | — | 278401 |
| A / ordinary-balanced-r2600 | 2c4t-g4 | baseline | 5/5 | 0/5 | 31.47 [30.63, 32.27] | — | — | — | 358141 |
| A / ordinary-balanced-r2600 | 2c4t-g4 | v000 | 5/5 | 0/5 | 1,112.50 [1,102.33, 1,132.60] | — | — | — | 80375 |
| A / ordinary-balanced-r2600 | 2c4t-g4 | v003 | 5/5 | 0/5 | 320.03 [312.60, 343.53] | — | — | — | 198211 |
| A / ordinary-balanced-r400 | 1c1t-g1 | baseline | 5/5 | 5/5 | 399.83 [399.83, 399.90] | 399.83 [399.79, 399.91] | 9.41 [9.11, 9.62] | 23.11 [21.82, 23.65] | 0 |
| A / ordinary-balanced-r400 | 1c1t-g1 | v000 | 5/5 | 5/5 | 400.00 [400.00, 400.00] | 400.00 [400.00, 400.00] | 1.96 [1.95, 2.00] | 8.39 [7.53, 9.01] | 0 |
| A / ordinary-balanced-r400 | 1c1t-g1 | v003 | 5/5 | 5/5 | 400.00 [399.97, 400.00] | 400.00 [400.00, 400.00] | 2.03 [2.01, 2.09] | 8.49 [8.17, 9.55] | 0 |
| A / ordinary-balanced-r400 | 2c2t-g2 | baseline | 5/5 | 5/5 | 399.93 [399.90, 399.97] | 399.94 [399.88, 399.97] | 8.36 [8.25, 8.89] | 17.88 [16.72, 19.08] | 0 |
| A / ordinary-balanced-r400 | 2c2t-g2 | v000 | 5/5 | 5/5 | 399.97 [399.97, 399.97] | 399.98 [399.98, 399.99] | 2.08 [2.01, 2.10] | 6.79 [6.17, 7.13] | 0 |
| A / ordinary-balanced-r400 | 2c2t-g2 | v003 | 5/5 | 5/5 | 400.00 [399.97, 400.00] | 400.00 [400.00, 400.00] | 2.12 [2.08, 2.19] | 7.06 [6.49, 7.55] | 0 |
| A / ordinary-balanced-r400 | 2c4t-g4 | baseline | 5/5 | 5/5 | 399.93 [399.87, 399.93] | 399.90 [399.87, 399.94] | 7.51 [7.24, 7.73] | 13.82 [13.62, 14.84] | 0 |
| A / ordinary-balanced-r400 | 2c4t-g4 | v000 | 5/5 | 5/5 | 400.00 [399.93, 400.00] | 400.00 [399.99, 400.00] | 1.68 [1.64, 1.73] | 3.65 [3.55, 3.91] | 0 |
| A / ordinary-balanced-r400 | 2c4t-g4 | v003 | 5/5 | 5/5 | 400.00 [399.97, 400.00] | 400.00 [399.99, 400.00] | 1.74 [1.66, 1.82] | 3.83 [3.49, 4.19] | 0 |
| A / ordinary-balanced-r800 | 1c1t-g1 | baseline | 5/5 | 0/5 | 29.93 [26.60, 30.60] | — | — | — | 114154 |
| A / ordinary-balanced-r800 | 1c1t-g1 | v000 | 5/5 | 5/5 | 799.90 [799.53, 799.97] | 799.89 [799.27, 799.98] | 4.99 [4.74, 5.78] | 40.95 [35.28, 50.49] | 0 |
| A / ordinary-balanced-r800 | 1c1t-g1 | v003 | 5/5 | 5/5 | 799.60 [799.00, 799.83] | 798.97 [798.44, 799.29] | 7.21 [6.86, 7.57] | 59.14 [55.94, 62.90] | 0 |
| A / ordinary-balanced-r800 | 2c2t-g2 | baseline | 5/5 | 0/5 | 74.73 [52.63, 170.17] | — | — | — | 92212 |
| A / ordinary-balanced-r800 | 2c2t-g2 | v000 | 5/5 | 5/5 | 799.97 [799.97, 800.00] | 799.99 [799.90, 800.00] | 1.62 [1.55, 1.75] | 6.66 [5.34, 7.74] | 0 |
| A / ordinary-balanced-r800 | 2c2t-g2 | v003 | 5/5 | 5/5 | 799.97 [799.97, 800.00] | 800.00 [799.98, 800.00] | 1.61 [1.38, 1.85] | 5.93 [5.04, 13.05] | 0 |
| A / ordinary-balanced-r800 | 2c4t-g4 | baseline | 5/5 | 5/5 | 799.77 [799.73, 799.83] | 799.77 [799.69, 799.82] | 7.35 [7.10, 7.39] | 14.71 [13.79, 15.34] | 0 |
| A / ordinary-balanced-r800 | 2c4t-g4 | v000 | 5/5 | 5/5 | 799.97 [799.93, 799.97] | 799.99 [799.96, 799.99] | 1.24 [1.00, 1.31] | 3.20 [2.40, 3.59] | 0 |
| A / ordinary-balanced-r800 | 2c4t-g4 | v003 | 5/5 | 5/5 | 799.97 [799.93, 799.97] | 799.99 [799.95, 799.99] | 1.32 [0.99, 1.42] | 3.29 [2.45, 4.54] | 0 |
| A / ordinary-random-r100 | 1c1t-g1 | baseline | 5/5 | 5/5 | 99.97 [99.97, 100.00] | 100.00 [99.99, 100.00] | 10.11 [7.78, 10.84] | 18.63 [18.45, 19.49] | 0 |
| A / ordinary-random-r100 | 1c1t-g1 | v000 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.64 [2.61, 2.68] | 6.05 [5.85, 7.38] | 0 |
| A / ordinary-random-r100 | 1c1t-g1 | v003 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.83 [2.80, 2.88] | 8.03 [6.89, 8.58] | 0 |
| A / ordinary-random-r100 | 2c2t-g2 | baseline | 5/5 | 5/5 | 100.00 [99.97, 100.00] | 100.00 [99.99, 100.00] | 8.56 [6.80, 10.40] | 14.46 [14.02, 15.53] | 0 |
| A / ordinary-random-r100 | 2c2t-g2 | v000 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.35 [2.33, 2.36] | 4.10 [3.89, 4.21] | 0 |
| A / ordinary-random-r100 | 2c2t-g2 | v003 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.45 [2.44, 2.46] | 4.63 [4.56, 4.84] | 0 |
| A / ordinary-random-r100 | 2c4t-g4 | baseline | 5/5 | 5/5 | 99.97 [99.97, 100.00] | 100.00 [99.99, 100.00] | 8.41 [6.58, 9.34] | 13.83 [12.51, 14.03] | 0 |
| A / ordinary-random-r100 | 2c4t-g4 | v000 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.22 [2.21, 2.22] | 3.59 [3.44, 3.65] | 0 |
| A / ordinary-random-r100 | 2c4t-g4 | v003 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.28 [2.27, 2.31] | 3.69 [3.54, 3.96] | 0 |
| A / ordinary-random-r1200 | 1c1t-g1 | baseline | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1200 | 1c1t-g1 | v000 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1200 | 1c1t-g1 | v003 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1200 | 2c2t-g2 | baseline | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1200 | 2c2t-g2 | v000 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1200 | 2c2t-g2 | v003 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1200 | 2c4t-g4 | baseline | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1200 | 2c4t-g4 | v000 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1200 | 2c4t-g4 | v003 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1800 | 1c1t-g1 | baseline | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1800 | 1c1t-g1 | v000 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1800 | 1c1t-g1 | v003 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1800 | 2c2t-g2 | baseline | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1800 | 2c2t-g2 | v000 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1800 | 2c2t-g2 | v003 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1800 | 2c4t-g4 | baseline | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1800 | 2c4t-g4 | v000 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r1800 | 2c4t-g4 | v003 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r2600 | 1c1t-g1 | baseline | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r2600 | 1c1t-g1 | v000 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r2600 | 1c1t-g1 | v003 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r2600 | 2c2t-g2 | baseline | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r2600 | 2c2t-g2 | v000 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r2600 | 2c2t-g2 | v003 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r2600 | 2c4t-g4 | baseline | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r2600 | 2c4t-g4 | v000 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r2600 | 2c4t-g4 | v003 | 0/5 | 0/0 | — | — | — | — | — |
| A / ordinary-random-r400 | 1c1t-g1 | baseline | 5/5 | 5/5 | 399.90 [399.80, 399.93] | 399.89 [399.85, 399.92] | 9.91 [9.61, 9.95] | 24.38 [23.76, 24.92] | 0 |
| A / ordinary-random-r400 | 1c1t-g1 | v000 | 5/5 | 5/5 | 400.00 [399.97, 400.00] | 400.00 [400.00, 400.00] | 2.06 [2.05, 2.09] | 8.63 [8.52, 8.99] | 0 |
| A / ordinary-random-r400 | 1c1t-g1 | v003 | 5/5 | 5/5 | 400.00 [399.97, 400.00] | 400.00 [399.98, 400.00] | 2.16 [2.14, 2.18] | 9.69 [9.23, 9.91] | 0 |
| A / ordinary-random-r400 | 2c2t-g2 | baseline | 5/5 | 5/5 | 399.90 [399.83, 399.93] | 399.88 [399.84, 399.95] | 8.90 [8.77, 8.95] | 18.22 [18.12, 19.21] | 0 |
| A / ordinary-random-r400 | 2c2t-g2 | v000 | 5/5 | 5/5 | 400.00 [399.97, 400.00] | 400.00 [399.99, 400.00] | 2.06 [2.04, 2.08] | 6.73 [6.45, 6.91] | 0 |
| A / ordinary-random-r400 | 2c2t-g2 | v003 | 5/5 | 5/5 | 400.00 [399.97, 400.00] | 400.00 [399.98, 400.00] | 2.14 [2.12, 2.16] | 7.09 [6.75, 7.94] | 0 |
| A / ordinary-random-r400 | 2c4t-g4 | baseline | 5/5 | 5/5 | 399.93 [399.90, 399.93] | 399.89 [399.87, 399.92] | 7.76 [7.53, 7.81] | 14.17 [13.97, 14.32] | 0 |
| A / ordinary-random-r400 | 2c4t-g4 | v000 | 5/5 | 5/5 | 400.00 [399.97, 400.00] | 400.00 [400.00, 400.00] | 1.64 [1.62, 1.67] | 3.59 [3.49, 3.66] | 0 |
| A / ordinary-random-r400 | 2c4t-g4 | v003 | 5/5 | 5/5 | 400.00 [399.97, 400.00] | 400.00 [400.00, 400.00] | 1.71 [1.63, 1.75] | 3.76 [3.57, 3.95] | 0 |
| A / ordinary-random-r800 | 1c1t-g1 | baseline | 4/5 | 0/4 | 25.83 [24.30, 28.27] | — | — | — | 92102 |
| A / ordinary-random-r800 | 1c1t-g1 | v000 | 4/5 | 4/4 | 799.73 [799.60, 799.83] | 799.50 [799.48, 799.66] | 5.85 [5.32, 6.01] | 43.84 [40.86, 48.91] | 0 |
| A / ordinary-random-r800 | 1c1t-g1 | v003 | 4/5 | 4/4 | 799.63 [799.37, 799.93] | 799.47 [799.00, 799.97] | 7.76 [7.16, 8.15] | 62.41 [53.14, 67.43] | 0 |
| A / ordinary-random-r800 | 2c2t-g2 | baseline | 4/5 | 0/4 | 45.67 [39.67, 49.80] | — | — | — | 79004 |
| A / ordinary-random-r800 | 2c2t-g2 | v000 | 5/5 | 5/5 | 799.97 [799.93, 799.97] | 799.97 [799.93, 799.99] | 1.70 [1.64, 1.75] | 6.89 [6.34, 7.02] | 0 |
| A / ordinary-random-r800 | 2c2t-g2 | v003 | 4/5 | 4/4 | 799.97 [799.97, 799.97] | 799.99 [799.98, 800.00] | 1.77 [1.68, 1.98] | 6.89 [6.59, 8.71] | 0 |
| A / ordinary-random-r800 | 2c4t-g4 | baseline | 4/5 | 4/4 | 799.87 [799.83, 799.87] | 799.80 [799.76, 799.85] | 7.53 [7.40, 7.62] | 14.30 [13.89, 14.51] | 0 |
| A / ordinary-random-r800 | 2c4t-g4 | v000 | 4/5 | 4/4 | 799.97 [799.93, 800.00] | 799.98 [799.98, 800.00] | 1.24 [1.13, 1.29] | 3.05 [2.63, 3.27] | 0 |
| A / ordinary-random-r800 | 2c4t-g4 | v003 | 4/5 | 4/4 | 799.97 [799.97, 800.00] | 799.98 [799.97, 800.00] | 1.29 [1.22, 1.32] | 3.29 [2.96, 3.45] | 0 |
| A / ordinary-single-r100 | 1c1t-g1 | baseline | 5/5 | 5/5 | 100.00 [99.97, 100.00] | 100.00 [99.96, 100.00] | 5.59 [5.03, 10.32] | 15.11 [14.92, 17.52] | 0 |
| A / ordinary-single-r100 | 1c1t-g1 | v000 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.53 [2.52, 2.54] | 5.38 [4.97, 5.99] | 0 |
| A / ordinary-single-r100 | 1c1t-g1 | v003 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.64 [2.63, 2.68] | 6.55 [6.00, 7.32] | 0 |
| A / ordinary-single-r100 | 2c2t-g2 | baseline | 5/5 | 5/5 | 99.97 [99.97, 100.00] | 99.99 [99.99, 100.00] | 7.80 [5.57, 11.89] | 11.45 [9.76, 15.74] | 0 |
| A / ordinary-single-r100 | 2c2t-g2 | v000 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.33 [2.33, 2.34] | 4.23 [4.13, 4.41] | 0 |
| A / ordinary-single-r100 | 2c2t-g2 | v003 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.42 [2.42, 2.43] | 4.45 [4.34, 4.77] | 0 |
| A / ordinary-single-r100 | 2c4t-g4 | baseline | 5/5 | 5/5 | 100.00 [99.97, 100.00] | 100.00 [100.00, 100.00] | 6.26 [5.29, 10.59] | 8.69 [7.31, 14.83] | 0 |
| A / ordinary-single-r100 | 2c4t-g4 | v000 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.18 [2.17, 2.19] | 3.56 [3.43, 3.60] | 0 |
| A / ordinary-single-r100 | 2c4t-g4 | v003 | 5/5 | 5/5 | 100.00 [100.00, 100.00] | 100.00 [100.00, 100.00] | 2.24 [2.24, 2.25] | 3.65 [3.60, 3.84] | 0 |
| A / ordinary-single-r1000 | 1c1t-g1 | baseline | 5/5 | 0/5 | 18.87 [6.43, 23.07] | — | — | — | 130484 |
| A / ordinary-single-r1000 | 1c1t-g1 | v000 | 5/5 | 0/5 | 95.13 [78.17, 161.87] | — | — | — | 113736 |
| A / ordinary-single-r1000 | 1c1t-g1 | v003 | 5/5 | 0/5 | 17.00 [15.67, 17.07] | — | — | — | 143639 |
| A / ordinary-single-r1000 | 2c2t-g2 | baseline | 5/5 | 0/5 | 47.70 [12.40, 53.60] | — | — | — | 123268 |
| A / ordinary-single-r1000 | 2c2t-g2 | v000 | 5/5 | 0/5 | 573.77 [570.30, 575.57] | — | — | — | 43528 |
| A / ordinary-single-r1000 | 2c2t-g2 | v003 | 5/5 | 0/5 | 464.03 [419.57, 472.30] | — | — | — | 61431 |
| A / ordinary-single-r1000 | 2c4t-g4 | baseline | 5/5 | 0/5 | 44.37 [37.23, 45.40] | — | — | — | 123075 |
| A / ordinary-single-r1000 | 2c4t-g4 | v000 | 5/5 | 5/5 | 999.97 [999.97, 1,000.00] | 999.98 [999.97, 1,000.00] | 1.41 [1.26, 1.53] | 13.50 [5.19, 22.43] | 0 |
| A / ordinary-single-r1000 | 2c4t-g4 | v003 | 5/5 | 5/5 | 999.97 [999.93, 1,000.00] | 999.99 [999.99, 1,000.00] | 1.44 [1.39, 1.54] | 15.73 [13.78, 19.11] | 0 |
| A / ordinary-single-r1600 | 1c1t-g1 | baseline | 5/5 | 0/5 | 19.73 [11.30, 22.90] | — | — | — | 220328 |
| A / ordinary-single-r1600 | 1c1t-g1 | v000 | 5/5 | 0/5 | 93.73 [65.73, 106.50] | — | — | — | 206474 |
| A / ordinary-single-r1600 | 1c1t-g1 | v003 | 5/5 | 0/5 | 13.30 [12.17, 14.00] | — | — | — | 234021 |
| A / ordinary-single-r1600 | 2c2t-g2 | baseline | 5/5 | 0/5 | 51.40 [48.87, 53.73] | — | — | — | 211793 |
| A / ordinary-single-r1600 | 2c2t-g2 | v000 | 5/5 | 0/5 | 560.60 [543.07, 565.93] | — | — | — | 135835 |
| A / ordinary-single-r1600 | 2c2t-g2 | v003 | 5/5 | 0/5 | 432.23 [415.83, 468.93] | — | — | — | 153913 |
| A / ordinary-single-r1600 | 2c4t-g4 | baseline | 5/5 | 0/5 | 44.87 [44.53, 50.40] | — | — | — | 212585 |
| A / ordinary-single-r1600 | 2c4t-g4 | v000 | 5/5 | 0/5 | 962.03 [960.20, 963.57] | — | — | — | 75243 |
| A / ordinary-single-r1600 | 2c4t-g4 | v003 | 5/5 | 0/5 | 938.77 [936.93, 939.87] | — | — | — | 78754 |
| A / ordinary-single-r300 | 1c1t-g1 | baseline | 5/5 | 5/5 | 299.93 [299.77, 299.97] | 299.92 [299.87, 299.96] | 10.58 [9.69, 10.98] | 25.35 [24.52, 28.18] | 0 |
| A / ordinary-single-r300 | 1c1t-g1 | v000 | 5/5 | 5/5 | 300.00 [300.00, 300.00] | 300.00 [300.00, 300.00] | 1.54 [1.53, 1.60] | 6.94 [6.58, 7.24] | 0 |
| A / ordinary-single-r300 | 1c1t-g1 | v003 | 5/5 | 5/5 | 300.00 [300.00, 300.00] | 300.00 [300.00, 300.00] | 1.61 [1.57, 1.67] | 7.51 [6.57, 7.58] | 0 |
| A / ordinary-single-r300 | 2c2t-g2 | baseline | 5/5 | 5/5 | 299.93 [299.90, 299.93] | 299.95 [299.93, 299.96] | 9.34 [8.45, 9.96] | 18.29 [17.89, 19.06] | 0 |
| A / ordinary-single-r300 | 2c2t-g2 | v000 | 5/5 | 5/5 | 300.00 [299.97, 300.00] | 300.00 [299.98, 300.00] | 1.67 [1.63, 1.69] | 4.90 [4.29, 5.05] | 0 |
| A / ordinary-single-r300 | 2c2t-g2 | v003 | 5/5 | 5/5 | 300.00 [300.00, 300.00] | 300.00 [300.00, 300.00] | 1.71 [1.69, 1.74] | 4.97 [4.78, 5.25] | 0 |
| A / ordinary-single-r300 | 2c4t-g4 | baseline | 5/5 | 5/5 | 299.93 [299.90, 299.97] | 299.95 [299.94, 299.97] | 8.13 [7.57, 8.63] | 15.53 [14.18, 16.22] | 0 |
| A / ordinary-single-r300 | 2c4t-g4 | v000 | 5/5 | 5/5 | 300.00 [300.00, 300.00] | 300.00 [300.00, 300.00] | 1.53 [1.52, 1.54] | 3.12 [3.04, 3.27] | 0 |
| A / ordinary-single-r300 | 2c4t-g4 | v003 | 5/5 | 5/5 | 300.00 [300.00, 300.00] | 300.00 [300.00, 300.00] | 1.57 [1.56, 1.58] | 3.21 [3.16, 3.30] | 0 |
| A / ordinary-single-r600 | 1c1t-g1 | baseline | 5/5 | 0/5 | 20.17 [19.23, 20.70] | — | — | — | 66640 |
| A / ordinary-single-r600 | 1c1t-g1 | v000 | 5/5 | 1/5 | 437.10 [229.27, 486.30] | 270.06 [270.06, 270.06] | 4,257.46 [4,257.46, 4,257.46] | 35,278.92 [35,278.92, 35,278.92] | 8944 |
| A / ordinary-single-r600 | 1c1t-g1 | v003 | 5/5 | 0/5 | 228.80 [24.07, 250.17] | — | — | — | 56957 |
| A / ordinary-single-r600 | 2c2t-g2 | baseline | 5/5 | 0/5 | 48.87 [46.07, 55.37] | — | — | — | 62113 |
| A / ordinary-single-r600 | 2c2t-g2 | v000 | 5/5 | 5/5 | 599.97 [599.97, 600.00] | 600.00 [599.97, 600.00] | 1.52 [1.48, 1.60] | 5.72 [5.27, 6.72] | 0 |
| A / ordinary-single-r600 | 2c2t-g2 | v003 | 5/5 | 5/5 | 599.97 [599.97, 600.00] | 600.00 [599.98, 600.00] | 1.68 [1.58, 1.80] | 6.78 [6.06, 6.99] | 0 |
| A / ordinary-single-r600 | 2c4t-g4 | baseline | 5/5 | 0/5 | 47.40 [40.07, 52.57] | — | — | — | 62388 |
| A / ordinary-single-r600 | 2c4t-g4 | v000 | 5/5 | 5/5 | 599.97 [599.97, 600.00] | 600.00 [599.99, 600.00] | 1.19 [1.18, 1.22] | 2.86 [2.83, 3.00] | 0 |
| A / ordinary-single-r600 | 2c4t-g4 | v003 | 5/5 | 5/5 | 599.97 [599.97, 600.00] | 599.99 [599.99, 600.00] | 1.22 [1.19, 1.23] | 2.99 [2.88, 3.08] | 0 |

| 服务器 / 场景 | CPU | 版本 | 状态次数 | 未发出（条） | 拒绝（条） | 等待结束（条） | 历史未排空轮次 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
| A / ordinary-balanced-r100 | 1c1t-g1 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r100 | 1c1t-g1 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r100 | 1c1t-g1 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r100 | 2c2t-g2 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r100 | 2c2t-g2 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r100 | 2c2t-g2 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r100 | 2c4t-g4 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r100 | 2c4t-g4 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r100 | 2c4t-g4 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r1200 | 1c1t-g1 | baseline | {"incomplete_batch": 5} | 0 | 33662 | 142759 | 0 |
| A / ordinary-balanced-r1200 | 1c1t-g1 | v000 | {"incomplete_batch": 5} | 0 | 6768 | 1895 | 0 |
| A / ordinary-balanced-r1200 | 1c1t-g1 | v003 | {"driver_incomplete": 3, "incomplete_batch": 2} | 3 | 20532 | 76980 | 0 |
| A / ordinary-balanced-r1200 | 2c2t-g2 | baseline | {"driver_incomplete": 1, "incomplete_batch": 4} | 1 | 32211 | 128031 | 0 |
| A / ordinary-balanced-r1200 | 2c2t-g2 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r1200 | 2c2t-g2 | v003 | {"driver_incomplete": 1, "measured": 4} | 1 | 0 | 0 | 0 |
| A / ordinary-balanced-r1200 | 2c4t-g4 | baseline | {"driver_incomplete": 1, "incomplete_batch": 4} | 1 | 0 | 53559 | 0 |
| A / ordinary-balanced-r1200 | 2c4t-g4 | v000 | {"driver_incomplete": 1, "measured": 4} | 1 | 0 | 0 | 0 |
| A / ordinary-balanced-r1200 | 2c4t-g4 | v003 | {"driver_incomplete": 1, "measured": 4} | 1 | 0 | 0 | 0 |
| A / ordinary-balanced-r1800 | 1c1t-g1 | baseline | {"driver_incomplete": 2, "incomplete_batch": 3} | 23 | 124018 | 142271 | 0 |
| A / ordinary-balanced-r1800 | 1c1t-g1 | v000 | {"incomplete_batch": 5} | 0 | 101568 | 1216 | 0 |
| A / ordinary-balanced-r1800 | 1c1t-g1 | v003 | {"driver_incomplete": 1, "incomplete_batch": 4} | 1 | 113914 | 77325 | 0 |
| A / ordinary-balanced-r1800 | 2c2t-g2 | baseline | {"driver_incomplete": 1, "incomplete_batch": 4} | 1 | 122828 | 127539 | 0 |
| A / ordinary-balanced-r1800 | 2c2t-g2 | v000 | {"driver_incomplete": 1, "incomplete_batch": 4} | 1 | 37504 | 0 | 0 |
| A / ordinary-balanced-r1800 | 2c2t-g2 | v003 | {"driver_incomplete": 1, "incomplete_batch": 4} | 1 | 106984 | 48781 | 0 |
| A / ordinary-balanced-r1800 | 2c4t-g4 | baseline | {"driver_incomplete": 1, "incomplete_batch": 4} | 1 | 121065 | 115108 | 0 |
| A / ordinary-balanced-r1800 | 2c4t-g4 | v000 | {"driver_incomplete": 2, "measured": 3} | 2 | 0 | 0 | 0 |
| A / ordinary-balanced-r1800 | 2c4t-g4 | v003 | {"driver_incomplete": 2, "measured": 3} | 3 | 0 | 0 | 0 |
| A / ordinary-balanced-r2600 | 1c1t-g1 | baseline | {"driver_incomplete": 3, "incomplete_batch": 2} | 4 | 244245 | 142588 | 0 |
| A / ordinary-balanced-r2600 | 1c1t-g1 | v000 | {"driver_incomplete": 1, "incomplete_batch": 4} | 2 | 223551 | 6004 | 0 |
| A / ordinary-balanced-r2600 | 1c1t-g1 | v003 | {"driver_incomplete": 2, "incomplete_batch": 3} | 3 | 234795 | 77010 | 0 |
| A / ordinary-balanced-r2600 | 2c2t-g2 | baseline | {"driver_incomplete": 2, "incomplete_batch": 3} | 5 | 243229 | 127785 | 0 |
| A / ordinary-balanced-r2600 | 2c2t-g2 | v000 | {"incomplete_batch": 5} | 0 | 171089 | 0 | 0 |
| A / ordinary-balanced-r2600 | 2c2t-g2 | v003 | {"driver_incomplete": 2, "incomplete_batch": 3} | 4 | 229461 | 48936 | 0 |
| A / ordinary-balanced-r2600 | 2c4t-g4 | baseline | {"driver_incomplete": 1, "incomplete_batch": 4} | 1 | 241922 | 116218 | 0 |
| A / ordinary-balanced-r2600 | 2c4t-g4 | v000 | {"driver_incomplete": 1, "incomplete_batch": 4} | 1 | 80374 | 0 | 0 |
| A / ordinary-balanced-r2600 | 2c4t-g4 | v003 | {"driver_incomplete": 3, "incomplete_batch": 2} | 5 | 198206 | 0 | 0 |
| A / ordinary-balanced-r400 | 1c1t-g1 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r400 | 1c1t-g1 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r400 | 1c1t-g1 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r400 | 2c2t-g2 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r400 | 2c2t-g2 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r400 | 2c2t-g2 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r400 | 2c4t-g4 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r400 | 2c4t-g4 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r400 | 2c4t-g4 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r800 | 1c1t-g1 | baseline | {"incomplete_batch": 5} | 0 | 0 | 114154 | 0 |
| A / ordinary-balanced-r800 | 1c1t-g1 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r800 | 1c1t-g1 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r800 | 2c2t-g2 | baseline | {"incomplete_batch": 5} | 0 | 0 | 92212 | 0 |
| A / ordinary-balanced-r800 | 2c2t-g2 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r800 | 2c2t-g2 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r800 | 2c4t-g4 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r800 | 2c4t-g4 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-balanced-r800 | 2c4t-g4 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r100 | 1c1t-g1 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r100 | 1c1t-g1 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r100 | 1c1t-g1 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r100 | 2c2t-g2 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r100 | 2c2t-g2 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r100 | 2c2t-g2 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r100 | 2c4t-g4 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r100 | 2c4t-g4 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r100 | 2c4t-g4 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r1200 | 1c1t-g1 | baseline | {} | — | — | — | 0 |
| A / ordinary-random-r1200 | 1c1t-g1 | v000 | {} | — | — | — | 0 |
| A / ordinary-random-r1200 | 1c1t-g1 | v003 | {} | — | — | — | 0 |
| A / ordinary-random-r1200 | 2c2t-g2 | baseline | {} | — | — | — | 0 |
| A / ordinary-random-r1200 | 2c2t-g2 | v000 | {} | — | — | — | 0 |
| A / ordinary-random-r1200 | 2c2t-g2 | v003 | {} | — | — | — | 0 |
| A / ordinary-random-r1200 | 2c4t-g4 | baseline | {} | — | — | — | 0 |
| A / ordinary-random-r1200 | 2c4t-g4 | v000 | {} | — | — | — | 0 |
| A / ordinary-random-r1200 | 2c4t-g4 | v003 | {} | — | — | — | 0 |
| A / ordinary-random-r1800 | 1c1t-g1 | baseline | {} | — | — | — | 0 |
| A / ordinary-random-r1800 | 1c1t-g1 | v000 | {} | — | — | — | 0 |
| A / ordinary-random-r1800 | 1c1t-g1 | v003 | {} | — | — | — | 0 |
| A / ordinary-random-r1800 | 2c2t-g2 | baseline | {} | — | — | — | 0 |
| A / ordinary-random-r1800 | 2c2t-g2 | v000 | {} | — | — | — | 0 |
| A / ordinary-random-r1800 | 2c2t-g2 | v003 | {} | — | — | — | 0 |
| A / ordinary-random-r1800 | 2c4t-g4 | baseline | {} | — | — | — | 0 |
| A / ordinary-random-r1800 | 2c4t-g4 | v000 | {} | — | — | — | 0 |
| A / ordinary-random-r1800 | 2c4t-g4 | v003 | {} | — | — | — | 0 |
| A / ordinary-random-r2600 | 1c1t-g1 | baseline | {} | — | — | — | 0 |
| A / ordinary-random-r2600 | 1c1t-g1 | v000 | {} | — | — | — | 0 |
| A / ordinary-random-r2600 | 1c1t-g1 | v003 | {} | — | — | — | 0 |
| A / ordinary-random-r2600 | 2c2t-g2 | baseline | {} | — | — | — | 0 |
| A / ordinary-random-r2600 | 2c2t-g2 | v000 | {} | — | — | — | 0 |
| A / ordinary-random-r2600 | 2c2t-g2 | v003 | {} | — | — | — | 0 |
| A / ordinary-random-r2600 | 2c4t-g4 | baseline | {} | — | — | — | 0 |
| A / ordinary-random-r2600 | 2c4t-g4 | v000 | {} | — | — | — | 0 |
| A / ordinary-random-r2600 | 2c4t-g4 | v003 | {} | — | — | — | 0 |
| A / ordinary-random-r400 | 1c1t-g1 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r400 | 1c1t-g1 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r400 | 1c1t-g1 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r400 | 2c2t-g2 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r400 | 2c2t-g2 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r400 | 2c2t-g2 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r400 | 2c4t-g4 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r400 | 2c4t-g4 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r400 | 2c4t-g4 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r800 | 1c1t-g1 | baseline | {"incomplete_batch": 4} | 0 | 0 | 92102 | 0 |
| A / ordinary-random-r800 | 1c1t-g1 | v000 | {"measured": 4} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r800 | 1c1t-g1 | v003 | {"measured": 4} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r800 | 2c2t-g2 | baseline | {"incomplete_batch": 4} | 0 | 0 | 79004 | 0 |
| A / ordinary-random-r800 | 2c2t-g2 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r800 | 2c2t-g2 | v003 | {"measured": 4} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r800 | 2c4t-g4 | baseline | {"measured": 4} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r800 | 2c4t-g4 | v000 | {"measured": 4} | 0 | 0 | 0 | 0 |
| A / ordinary-random-r800 | 2c4t-g4 | v003 | {"measured": 4} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r100 | 1c1t-g1 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r100 | 1c1t-g1 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r100 | 1c1t-g1 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r100 | 2c2t-g2 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r100 | 2c2t-g2 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r100 | 2c2t-g2 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r100 | 2c4t-g4 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r100 | 2c4t-g4 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r100 | 2c4t-g4 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r1000 | 1c1t-g1 | baseline | {"incomplete_batch": 5} | 0 | 126955 | 3529 | 0 |
| A / ordinary-single-r1000 | 1c1t-g1 | v000 | {"driver_incomplete": 1, "incomplete_batch": 4} | 1 | 113735 | 0 | 0 |
| A / ordinary-single-r1000 | 1c1t-g1 | v003 | {"incomplete_batch": 5} | 0 | 127015 | 16624 | 0 |
| A / ordinary-single-r1000 | 2c2t-g2 | baseline | {"incomplete_batch": 5} | 0 | 123268 | 0 | 0 |
| A / ordinary-single-r1000 | 2c2t-g2 | v000 | {"incomplete_batch": 5} | 0 | 43528 | 0 | 0 |
| A / ordinary-single-r1000 | 2c2t-g2 | v003 | {"incomplete_batch": 5} | 0 | 61431 | 0 | 0 |
| A / ordinary-single-r1000 | 2c4t-g4 | baseline | {"incomplete_batch": 5} | 0 | 123075 | 0 | 0 |
| A / ordinary-single-r1000 | 2c4t-g4 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r1000 | 2c4t-g4 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r1600 | 1c1t-g1 | baseline | {"driver_incomplete": 2, "incomplete_batch": 3} | 2 | 216724 | 3602 | 0 |
| A / ordinary-single-r1600 | 1c1t-g1 | v000 | {"driver_incomplete": 2, "incomplete_batch": 3} | 2 | 206472 | 0 | 0 |
| A / ordinary-single-r1600 | 1c1t-g1 | v003 | {"incomplete_batch": 5} | 0 | 217546 | 16475 | 0 |
| A / ordinary-single-r1600 | 2c2t-g2 | baseline | {"driver_incomplete": 2, "incomplete_batch": 3} | 2 | 211791 | 0 | 0 |
| A / ordinary-single-r1600 | 2c2t-g2 | v000 | {"driver_incomplete": 2, "incomplete_batch": 3} | 2 | 135833 | 0 | 0 |
| A / ordinary-single-r1600 | 2c2t-g2 | v003 | {"incomplete_batch": 5} | 0 | 153913 | 0 | 0 |
| A / ordinary-single-r1600 | 2c4t-g4 | baseline | {"driver_incomplete": 4, "incomplete_batch": 1} | 4 | 212581 | 0 | 0 |
| A / ordinary-single-r1600 | 2c4t-g4 | v000 | {"incomplete_batch": 5} | 0 | 75243 | 0 | 0 |
| A / ordinary-single-r1600 | 2c4t-g4 | v003 | {"driver_incomplete": 2, "incomplete_batch": 3} | 2 | 78752 | 0 | 0 |
| A / ordinary-single-r300 | 1c1t-g1 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r300 | 1c1t-g1 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r300 | 1c1t-g1 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r300 | 2c2t-g2 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r300 | 2c2t-g2 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r300 | 2c2t-g2 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r300 | 2c4t-g4 | baseline | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r300 | 2c4t-g4 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r300 | 2c4t-g4 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r600 | 1c1t-g1 | baseline | {"incomplete_batch": 5} | 0 | 66525 | 115 | 0 |
| A / ordinary-single-r600 | 1c1t-g1 | v000 | {"incomplete_batch": 4, "measured": 1} | 0 | 8944 | 0 | 0 |
| A / ordinary-single-r600 | 1c1t-g1 | v003 | {"incomplete_batch": 5} | 0 | 40582 | 16375 | 0 |
| A / ordinary-single-r600 | 2c2t-g2 | baseline | {"incomplete_batch": 5} | 0 | 62113 | 0 | 0 |
| A / ordinary-single-r600 | 2c2t-g2 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r600 | 2c2t-g2 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r600 | 2c4t-g4 | baseline | {"driver_incomplete": 1, "incomplete_batch": 4} | 5 | 62383 | 0 | 0 |
| A / ordinary-single-r600 | 2c4t-g4 | v000 | {"measured": 5} | 0 | 0 | 0 | 0 |
| A / ordinary-single-r600 | 2c4t-g4 | v003 | {"measured": 5} | 0 | 0 | 0 | 0 |

measured 表示取得测量，不能证明协议正确。incomplete_batch 表示该批未全部交付执行结果，driver_incomplete 表示计划负载未完整发出。拒绝不自动算安全性缺陷，观察超时不自动证明永久停滞。

发送延误见 send_lag_p99_ms；它不能混入客户端响应延迟。资源指标按发送期统计。逐请求时间在 jobs/*/measured/requests.jsonl，每秒完成量在 result.json 的 timeline。历史追赶曲线在 *-progress.json。原始历史实验保留原样，不与本方法合并。
