package mixepaxos

import (
	"context"
	"fmt"
	"runtime/trace"
	"time"
)

func (n *Node) validID(x ID) bool {
	return x.Replica >= 0 && x.Replica < len(n.cfg.Members) && x.Index > 0
}
func (n *Node) validValue(v Value, d *Descriptor) bool {
	if v.Command.Validate() != nil || len(v.Deps) != len(n.cfg.Members) || v.Seq == 0 {
		return false
	}
	if d != nil {
		if v.Command != d.Initial.Command || v.Seq < d.Initial.Seq {
			return false
		}
		for i, a := range d.Initial.Deps {
			if v.Deps[i] < a {
				return false
			}
		}
	}
	return true
}
func (n *Node) validDescriptor(d Descriptor) bool {
	if !n.validID(d.ID) || !n.validValue(d.Initial, nil) || len(d.Carry) >= n.cfg.K {
		return false
	}
	seen := map[ID]bool{}
	for _, x := range d.Carry {
		if !n.validID(x) || x.Replica != d.ID.Replica || x.Index >= d.ID.Index || seen[x] {
			return false
		}
		seen[x] = true
	}
	return true
}
func reps(v Vector) []ID {
	out := []ID{}
	for p, i := range v {
		if i > 0 {
			out = append(out, ID{p, i})
		}
	}
	return out
}
func (n *Node) wantLocked(x ID) {
	if !n.validID(x) {
		return
	}
	if r := n.records[x]; r != nil && r.ready {
		return
	}
	if _, ok := n.missing[x]; !ok {
		n.missing[x] = time.Time{}
	}
}

// completeLocked never interprets an unavailable position as an empty position.
func (n *Node) completeLocked(x ID, visiting map[ID]bool) bool {
	r := n.records[x]
	if r == nil {
		n.wantLocked(x)
		return false
	}
	if r.ready {
		return true
	}
	if visiting[x] {
		n.wantLocked(x)
		return false
	}
	visiting[x] = true
	ok := true
	required := append(reps(r.desc.Initial.Deps), r.desc.Carry...)
	for _, y := range required {
		if !n.completeLocked(y, visiting) {
			ok = false
		}
	}
	delete(visiting, x)
	if ok {
		r.ready = true
		n.newlyReady = append(n.newlyReady, r)
		delete(n.incomplete, x)
		delete(n.missing, x)
	}
	return ok
}
func messageKey(m Message) string {
	return fmt.Sprintf("%d/%s/%s/%d/%d/%d/%s", m.From, m.Kind, m.ID, m.Attempt, m.Phase, m.Nonce, m.Other)
}
func (n *Node) ingest(m Message) bool {
	if n.fastDataReady(m) {
		n.notePeer(m)
		return true
	}
	n.mu.Lock()
	defer n.mu.Unlock()
	for _, d := range m.Data {
		if !n.validDescriptor(d) {
			return false
		}
		// A saved command is enough to reject contradictory client reuse even when
		// its carry closure is still being retrieved; this is not registration.
		if old, ok := n.bindings[d.Initial.Command.RID]; ok && old != d.Initial.Command {
			n.fault = "contradictory rid discovered in cluster"
		} else {
			n.bindings[d.Initial.Command.RID] = d.Initial.Command
		}
		if old := n.records[d.ID]; old != nil {
			if !equalDescriptor(old.desc, d) {
				n.fault = "immutable initial value changed"
				return false
			}
		} else {
			n.records[d.ID] = newRecord(d, n.clock.Now())
			n.incomplete[d.ID] = true
		}
	}
	ready := n.completeLocked(m.ID, map[ID]bool{})
	vectors := []Vector{}
	if m.Value != nil {
		vectors = append(vectors, m.Value.Deps)
	}
	if m.First != nil {
		vectors = append(vectors, m.First.Initial.Deps, m.First.Deps)
	}
	if m.Accepted != nil {
		vectors = append(vectors, m.Accepted.Value.Deps)
	}
	if m.Scan != nil {
		vectors = append(vectors, m.Scan.Deps)
	}
	for _, v := range vectors {
		if len(v) != len(n.cfg.Members) {
			return false
		}
		for _, x := range reps(v) {
			if !n.completeLocked(x, map[ID]bool{}) {
				ready = false
			}
		}
	}
	if m.Kind == "Help" || m.Kind == "Strong" {
		if !n.completeLocked(m.Other, map[ID]bool{}) {
			ready = false
		}
	}
	// Every complete carried or representative instance participates in scans.
	for _, r := range n.newlyReady {
		if !(m.Kind == "PreAccept" && r.desc.ID == m.ID) {
			n.registerLocked(r)
		}
	}
	n.newlyReady = nil
	if m.Kind != "PreAccept" {
		if r := n.records[m.ID]; r != nil && r.ready {
			n.registerLocked(r)
		}
	}
	n.notePeer(m)
	if !ready {
		if len(n.deferred) < n.cfg.QueueLimit {
			n.deferred[messageKey(m)] = m
		} else {
			n.drops.Add(1)
		}
		return false
	}
	delete(n.deferred, messageKey(m))
	return true
}
func (n *Node) retryData() {
	n.mu.Lock()
	now := n.clock.Now()
	fetch := []ID{}
	for x, last := range n.missing {
		if now.Sub(last) >= n.cfg.W() {
			fetch = append(fetch, x)
			n.missing[x] = now
		}
	}
	for id := range n.incomplete {
		n.completeLocked(id, map[ID]bool{})
	}
	for _, r := range n.newlyReady {
		n.registerLocked(r)
	}
	n.newlyReady = nil
	retry := make([]Message, 0, len(n.deferred))
	for key, m := range n.deferred {
		retry = append(retry, m)
		delete(n.deferred, key)
	}
	n.mu.Unlock()
	for _, x := range fetch {
		n.broadcast(Message{Kind: "Fetch", ID: x})
	}
	for _, m := range retry {
		select {
		case n.jobs <- m:
		default:
			n.mu.Lock()
			if len(n.deferred) < n.cfg.QueueLimit {
				n.deferred[messageKey(m)] = m
			}
			n.mu.Unlock()
		}
	}
}
func (n *Node) fetch(x ID) { n.mu.Lock(); n.wantLocked(x); n.mu.Unlock() }
func (n *Node) attach(m Message) Message { // direct descriptors; recursive closure is fetched by ID
	n.mu.Lock()
	defer n.mu.Unlock()
	ids := map[ID]bool{m.ID: true}
	if n.validID(m.Other) {
		ids[m.Other] = true
	}
	vectors := []Vector{}
	if m.Value != nil {
		vectors = append(vectors, m.Value.Deps)
	}
	if m.Scan != nil {
		vectors = append(vectors, m.Scan.Deps)
	}
	if m.First != nil {
		vectors = append(vectors, m.First.Deps)
	}
	if m.Accepted != nil {
		vectors = append(vectors, m.Accepted.Value.Deps)
	}
	if r := n.records[m.ID]; r != nil {
		vectors = append(vectors, r.desc.Initial.Deps)
		for _, x := range r.desc.Carry {
			ids[x] = true
		}
	}
	for _, d := range vectors {
		for _, x := range reps(d) {
			ids[x] = true
		}
	}
	budget := 0
	add := func(x ID, required bool) {
		if r := n.records[x]; r != nil && r.ready {
			d := r.desc
			c := d.Initial.Command
			size := 512 + 6*(len(c.RID.Client)+len(c.Key)+len(c.Value)) + 24*len(d.Initial.Deps) + 64*len(d.Carry)
			if required || budget+size <= 4<<20 {
				m.Data = append(m.Data, d)
				budget += size
			}
		}
	}
	add(m.ID, true)
	delete(ids, m.ID)
	for x := range ids {
		add(x, false)
	}
	return m
}
func (n *Node) handle(m Message) {
	n.messages.Add(1)
	switch m.Kind {
	case "HB", "HBAck", "Complaint", "Bad":
		n.handleOmega(m)
		return
	case "Fetch":
		r := n.get(m.ID)
		if r == nil {
			return
		}
		r.mu.Lock()
		v := r.decided
		r.mu.Unlock()
		n.send(n.attach(Message{To: m.From, Kind: "FetchReply", ID: m.ID, Value: v}))
		return
	case "NeedRecover":
		r := n.get(m.ID)
		if r == nil {
			n.fetch(m.ID)
			return
		}
		r.mu.Lock()
		value := r.decided
		if value == nil {
			r.pending = true
		}
		r.mu.Unlock()
		if value != nil {
			n.send(n.attach(Message{To: m.From, Kind: "Done", ID: m.ID, Value: value}))
		}
		return
	}
	if !n.validID(m.ID) {
		return
	}
	if !n.ingest(m) {
		return
	}
	r := n.get(m.ID)
	if r == nil {
		return
	}
	if m.Value != nil && !n.validValue(*m.Value, &r.desc) {
		return
	}
	switch m.Kind {
	case "PreAccept", "Prepare", "Observe", "Validate", "Accept":
		n.handleRequest(r, m)
	case "PreAcceptReply", "PrepareReply", "ScanReply", "AcceptACK", "Nack":
		n.handleReply(r, m)
	case "Learn", "Done", "FetchReply":
		if m.Value != nil {
			n.learn(r, *m.Value)
		}
	case "Help":
		n.handleHelp(r, m)
	case "Strong":
		r.mu.Lock()
		if t := r.task; t != nil && !t.initial && t.id == m.Attempt && t.ballot == m.Ballot && t.branch == "validate" && t.unresolved[m.Other] {
			r.noFast = true
		}
		r.mu.Unlock()
	}
}
func (n *Node) raiseLocked(r *record, b Ballot) {
	if r.promise.Less(b) {
		r.promise = b
	}
	if r.highest.Less(b) {
		r.highest = b
	}
	if r.task != nil && r.task.ballot.Less(b) {
		r.task = nil
		r.pending = true
		r.retryAt = n.clock.Now().Add(n.cfg.W())
	}
}
func (n *Node) handleRequest(r *record, m Message) {
	if m.Kind == "PreAccept" {
		if m.From != m.ID.Replica || m.Ballot != ZeroBallot {
			return
		}
	} else if m.Ballot.Round == 0 {
		if m.Kind != "Accept" || m.From != m.ID.Replica {
			return
		}
	} else if m.Ballot.Replica != m.From {
		return
	}
	// Scan+registration+first observation is one atomic transition. Prepare and
	// Accept use only the instance lock, so different instances run on different cores.
	scanKind := m.Kind == "PreAccept" || m.Kind == "Observe" || m.Kind == "Validate"
	if scanKind {
		n.mu.Lock()
	}
	r.mu.Lock()
	region := trace.StartRegion(context.Background(), "protocol."+m.Kind)
	reply := Message{To: m.From, ID: m.ID, Ballot: m.Ballot, Attempt: m.Attempt, Phase: m.Phase, Nonce: m.Nonce}
	if r.decided != nil {
		reply.Kind = "Done"
		reply.Value = r.decided
	} else if m.Ballot.Less(r.promise) {
		reply.Kind = "Nack"
		reply.Promise = r.promise
		reply.Reason = "higher promise"
	} else {
		switch m.Kind {
		case "PreAccept":
			if r.first == nil {
				n.registerLocked(r)
				d, s := n.scanLocked(r.desc.Initial.Command, m.ID)
				d = Merge(r.desc.Initial.Deps, d)
				if s+1 < r.desc.Initial.Seq {
					s = r.desc.Initial.Seq - 1
				}
				v := r.desc.Initial
				r.first = &First{v, d, s + 1, EqualValue(v, Value{v.Command, d, s + 1})}
			}
			reply.Kind = "PreAcceptReply"
			reply.First = r.first
		case "Prepare":
			n.raiseLocked(r, m.Ballot)
			reply.Kind = "PrepareReply"
			reply.First = r.first
			reply.Accepted = r.accepted
		case "Observe", "Validate":
			n.raiseLocked(r, m.Ballot)
			n.registerLocked(r)
			d, s := n.scanLocked(r.desc.Initial.Command, m.ID)
			d = Merge(r.desc.Initial.Deps, d)
			if s+1 < r.desc.Initial.Seq {
				s = r.desc.Initial.Seq - 1
			}
			reply.Kind = "ScanReply"
			reply.Scan = &Scan{d, s + 1}
		case "Accept":
			if m.Value == nil {
				region.End()
				r.mu.Unlock()
				if scanKind {
					n.mu.Unlock()
				}
				return
			}
			a := n.acceptActive.Add(1)
			n.acceptCount.Add(1)
			for {
				v := n.acceptMax.Load()
				if a <= v || n.acceptMax.CompareAndSwap(v, a) {
					break
				}
			}
			if r.accepted != nil && r.accepted.Ballot == m.Ballot && !EqualValue(r.accepted.Value, *m.Value) {
				reply.Kind = "Nack"
				reply.Promise = r.promise
				reply.Reason = "different proposal in same ballot"
			} else {
				n.raiseLocked(r, m.Ballot)
				r.accepted = &Accepted{m.Ballot, *m.Value}
				reply.Kind = "AcceptACK"
				reply.Value = m.Value
			}
			n.acceptActive.Add(-1)
		}
	}
	region.End()
	r.mu.Unlock()
	if scanKind {
		n.mu.Unlock()
	}
	n.emit("protocol_"+m.Kind, m.ID, "")
	n.send(n.attach(reply))
}
func (n *Node) learn(r *record, v Value) { n.commit(r, v, nil) }
func (n *Node) commit(r *record, v Value, expected *task) {
	r.mu.Lock()
	if expected != nil && (r.task != expected || expected.ballot.Less(r.promise)) {
		r.mu.Unlock()
		return
	}
	if r.decided != nil {
		same := EqualValue(*r.decided, v)
		r.mu.Unlock()
		if !same {
			n.fail("contradictory decisions for " + r.desc.ID.String())
		}
		return
	}
	r.decided = &v
	r.task = nil
	r.pending = false
	helps := r.helps
	r.helps = map[string]Message{}
	r.mu.Unlock()
	n.emit("decide", r.desc.ID, "")
	n.broadcast(n.attach(Message{Kind: "Learn", ID: r.desc.ID, Value: &v}))
	for _, h := range helps {
		n.send(n.attach(Message{To: h.Requester, Kind: "Done", ID: r.desc.ID, Other: h.Other, Value: &v, Ballot: h.Ballot, Attempt: h.Attempt}))
	}
	n.wakeExecution()
}

func equalDescriptor(a, b Descriptor) bool {
	if a.ID != b.ID || !EqualValue(a.Initial, b.Initial) || len(a.Carry) != len(b.Carry) {
		return false
	}
	for i := range a.Carry {
		if a.Carry[i] != b.Carry[i] {
			return false
		}
	}
	return true
}

func (n *Node) notePeer(m Message) {
	n.peerMu.Lock()
	defer n.peerMu.Unlock()
	if n.peerKnown[m.From] == nil || len(n.peerKnown[m.From]) > 4096 {
		n.peerKnown[m.From] = map[ID]bool{}
	}
	for _, d := range m.Data {
		n.peerKnown[m.From][d.ID] = true
	}
	switch m.Kind {
	case "PreAcceptReply", "PrepareReply", "ScanReply", "AcceptACK", "FetchReply", "Done", "Learn":
		n.peerKnown[m.From][m.ID] = true
	}
}
func (n *Node) fastDataReady(m Message) bool {
	n.mu.RLock()
	defer n.mu.RUnlock()
	r := n.records[m.ID]
	if r == nil || !r.ready || (!r.registered && m.Kind != "PreAccept") {
		return false
	}
	if _, pending := n.deferred[messageKey(m)]; pending {
		return false
	}
	for _, d := range m.Data {
		other := n.records[d.ID]
		if other == nil || !other.ready || !other.registered || !equalDescriptor(other.desc, d) {
			return false
		}
	}
	vectors := []Vector{}
	if m.Value != nil {
		vectors = append(vectors, m.Value.Deps)
	}
	if m.First != nil {
		vectors = append(vectors, m.First.Initial.Deps, m.First.Deps)
	}
	if m.Accepted != nil {
		vectors = append(vectors, m.Accepted.Value.Deps)
	}
	if m.Scan != nil {
		vectors = append(vectors, m.Scan.Deps)
	}
	for _, v := range vectors {
		if len(v) != len(n.cfg.Members) {
			return false
		}
		for _, x := range reps(v) {
			other := n.records[x]
			if other == nil || !other.ready || !other.registered {
				return false
			}
		}
	}
	if m.Kind == "Help" || m.Kind == "Strong" {
		other := n.records[m.Other]
		if other == nil || !other.ready || !other.registered {
			return false
		}
	}
	return true
}
