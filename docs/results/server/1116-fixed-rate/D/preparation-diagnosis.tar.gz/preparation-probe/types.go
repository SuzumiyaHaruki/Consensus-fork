// Package mixepaxos implements the Mixed EPaxos protocol for a crash-stop cluster.
package mixepaxos

import (
	"encoding/json"
	"errors"
	"fmt"
	"time"
	"unicode/utf8"
)

type ID struct {
	Replica int    `json:"replica"`
	Index   uint64 `json:"index"`
}

func (x ID) String() string { return fmt.Sprintf("%d.%d", x.Replica, x.Index) }
func LessID(a, b ID) bool {
	if a.Replica != b.Replica {
		return a.Replica < b.Replica
	}
	return a.Index < b.Index
}

type RID struct {
	Client string `json:"client"`
	Seq    uint64 `json:"seq"`
}
type Command struct {
	RID   RID    `json:"rid"`
	Op    string `json:"op"`
	Key   string `json:"key"`
	Value string `json:"value,omitempty"`
}

func (c Command) Validate() error {
	if !utf8.ValidString(c.RID.Client) || !utf8.ValidString(c.Key) || !utf8.ValidString(c.Value) {
		return errors.New("strings must be valid UTF-8")
	}
	if len(c.RID.Client) < 1 || len(c.RID.Client) > 128 || c.RID.Seq == 0 {
		return errors.New("invalid request identity")
	}
	if len(c.Key) == 0 || len(c.Key) > 1024 || len(c.Value) > 1<<20 {
		return errors.New("invalid key or value length")
	}
	if c.Op != "put" && c.Op != "get" && c.Op != "delete" {
		return errors.New("unknown operation")
	}
	if c.Op != "put" && c.Value != "" {
		return errors.New("only put accepts a value")
	}
	return nil
}
func Conflict(a, b Command) bool {
	return a.RID == b.RID || a.Key == b.Key && (a.Op != "get" || b.Op != "get")
}

type Vector []uint64

func Merge(a, b Vector) Vector {
	d := append(Vector(nil), a...)
	for i, v := range b {
		if i < len(d) && v > d[i] {
			d[i] = v
		}
	}
	return d
}

type Value struct {
	Command Command `json:"command"`
	Deps    Vector  `json:"deps"`
	Seq     uint64  `json:"seq"`
}

func EqualValue(a, b Value) bool {
	if a.Command != b.Command || a.Seq != b.Seq || len(a.Deps) != len(b.Deps) {
		return false
	}
	for i := range a.Deps {
		if a.Deps[i] != b.Deps[i] {
			return false
		}
	}
	return true
}
func Covers(v Value, y ID, other Command, x ID) bool {
	return x != y && Conflict(v.Command, other) && y.Replica >= 0 && y.Replica < len(v.Deps) && y.Index > 0 && y.Index <= v.Deps[y.Replica]
}

type Ballot struct {
	Round   uint64 `json:"round"`
	Replica int    `json:"replica"`
}

func (b Ballot) Less(c Ballot) bool {
	if b.Round != c.Round {
		return b.Round < c.Round
	}
	return b.Replica < c.Replica
}

var ZeroBallot = Ballot{}

type Descriptor struct {
	ID      ID    `json:"id"`
	Initial Value `json:"initial"`
	Carry   []ID  `json:"carry,omitempty"`
}
type First struct {
	Initial Value  `json:"initial"`
	Deps    Vector `json:"deps"`
	Seq     uint64 `json:"seq"`
	Fast    bool   `json:"fast"`
}
type Accepted struct {
	Ballot Ballot `json:"ballot"`
	Value  Value  `json:"value"`
}
type Scan struct {
	Deps Vector `json:"deps"`
	Seq  uint64 `json:"seq"`
}
type Message struct {
	queuedAt  time.Time
	queueKey  string
	From      int          `json:"from"`
	To        int          `json:"to"`
	Kind      string       `json:"kind"`
	ID        ID           `json:"id"`
	Ballot    Ballot       `json:"ballot"`
	Attempt   uint64       `json:"attempt"`
	Phase     int          `json:"phase"`
	Nonce     uint64       `json:"nonce"`
	Data      []Descriptor `json:"data,omitempty"`
	Value     *Value       `json:"value,omitempty"`
	First     *First       `json:"first,omitempty"`
	Accepted  *Accepted    `json:"accepted,omitempty"`
	Scan      *Scan        `json:"scan,omitempty"`
	Promise   Ballot       `json:"promise"`
	Requester int          `json:"requester"`
	Other     ID           `json:"other"`
	Strong    bool         `json:"strong,omitempty"`
	HB        uint64       `json:"hb,omitempty"`
	Subject   int          `json:"subject,omitempty"`
	Observers []int        `json:"observers,omitempty"`
	Reason    string       `json:"reason,omitempty"`
}

type Member struct {
	ID      int    `json:"id"`
	Address string `json:"address"`
}
type Config struct {
	ID              int      `json:"id"`
	Members         []Member `json:"members"`
	F               int      `json:"f"`
	S               int      `json:"s"`
	E               int      `json:"e"`
	WMillis         int      `json:"w_ms"`
	K               int      `json:"k"`
	Parallelism     int      `json:"parallelism"`
	QueueLimit      int      `json:"queue_limit"`
	GraceMillis     int      `json:"grace_ms"`
	TickMillis      int      `json:"tick_ms"`
	HeartbeatMillis int      `json:"heartbeat_ms"`
	// Secret is supplied at runtime, never stored in example configuration.
	Secret string `json:"-"`
}

func (c *Config) Defaults() {
	if c.Parallelism == 0 {
		c.Parallelism = 4
	}
	if c.QueueLimit == 0 {
		c.QueueLimit = 1024
	}
	if c.TickMillis == 0 {
		c.TickMillis = 10
	}
	if c.HeartbeatMillis == 0 {
		c.HeartbeatMillis = c.WMillis
	}
	if c.GraceMillis == 0 {
		c.GraceMillis = 4 * c.WMillis
	}
}
func (c Config) Validate() error {
	n := len(c.Members)
	q := n - c.F
	if n == 0 || c.F < 0 || c.F >= n || c.S < 0 || c.S >= q || q > c.F+1 || c.E < 0 || c.E >= (q+1)/2 || c.K < 1 || c.WMillis < 1 {
		return errors.New("invalid protocol parameters: require 0<=s<n-f<=f+1, 2e<n-f, K>=1, W>0")
	}
	maxMillis := int64(^uint64(0)>>1) / int64(time.Millisecond)
	if int64(c.WMillis) > maxMillis || int64(c.GraceMillis) > maxMillis || int64(c.TickMillis) > maxMillis || int64(c.HeartbeatMillis) > maxMillis {
		return errors.New("timing duration exceeds representation")
	}
	if c.ID < 0 || c.ID >= n || c.Parallelism < 1 || c.QueueLimit < 1 || c.TickMillis < 1 || c.GraceMillis < 1 || c.HeartbeatMillis < 1 {
		return errors.New("invalid runtime limits")
	}
	for i, m := range c.Members {
		if m.ID != i || m.Address == "" {
			return errors.New("members must have consecutive IDs starting at 0 and addresses")
		}
		for j := 0; j < i; j++ {
			if c.Members[j].Address == m.Address {
				return errors.New("duplicate member address")
			}
		}
	}
	return nil
}
func (c Config) W() time.Duration { return time.Duration(c.WMillis) * time.Millisecond }
func DecodeConfig(data []byte) (Config, error) {
	var c Config
	err := json.Unmarshal(data, &c)
	if err != nil {
		return c, err
	}
	c.Defaults()
	return c, c.Validate()
}

type Result struct {
	Status   string `json:"status"`
	Value    string `json:"value,omitempty"`
	Found    bool   `json:"found,omitempty"`
	Error    string `json:"error,omitempty"`
	Instance *ID    `json:"instance,omitempty"`
}

const (
	Applied         = "APPLIED"
	AlreadyExecuted = "ALREADY_EXECUTED"
	Rejected        = "REJECTED"
	Incomplete      = "INCOMPLETE"
	Unknown         = "UNKNOWN"
	Overloaded      = "OVERLOADED"
)

func cloneValue(v Value) Value { v.Deps = append(Vector(nil), v.Deps...); return v }
func cloneDescriptor(d Descriptor) Descriptor {
	d.Initial = cloneValue(d.Initial)
	d.Carry = append([]ID(nil), d.Carry...)
	return d
}
