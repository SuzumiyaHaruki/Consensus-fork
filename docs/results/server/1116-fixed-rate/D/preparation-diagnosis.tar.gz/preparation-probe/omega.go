package mixepaxos

import (
	"fmt"
	"sort"
	"time"
)

func (n *Node) Omega() int            { n.omegaMu.Lock(); defer n.omegaMu.Unlock(); return n.omega }
func eventKey(p int, k uint64) string { return fmt.Sprintf("%d/%d", p, k) }
func (n *Node) chooseOmegaLocked() {
	best := 0
	for p := range n.cfg.Members {
		if n.badCounts[p] < n.badCounts[best] {
			best = p
		}
	}
	n.omega = best
}
func (n *Node) installBadLocked(m Message) bool {
	key := eventKey(m.Subject, m.HB)
	if _, ok := n.bad[key]; ok {
		return false
	}
	seen := map[int]bool{}
	for _, p := range m.Observers {
		if p < 0 || p >= len(n.cfg.Members) || p == m.Subject {
			return false
		}
		seen[p] = true
	}
	if len(seen) < len(n.cfg.Members)-n.cfg.F {
		return false
	}
	m.Kind = "Bad"
	m.To = -1
	n.bad[key] = m
	n.badCounts[m.Subject]++
	delete(n.complaints, key)
	n.chooseOmegaLocked()
	return true
}
func (n *Node) handleOmega(m Message) {
	out := []Message{}
	n.omegaMu.Lock()
	switch m.Kind {
	case "HB":
		if m.HB == 0 {
			break
		}
		if n.heartbeats[m.From] == nil {
			n.heartbeats[m.From] = map[uint64]bool{}
		}
		if m.HB >= n.checkK {
			n.heartbeats[m.From][m.HB] = true
		}
		out = append(out, Message{To: m.From, Kind: "HBAck", HB: m.HB})
	case "HBAck":
		p := m.From
		if m.HB >= n.hbOldest[p] && m.HB <= n.hb {
			n.hbAcked[p][m.HB] = true
			for n.hbAcked[p][n.hbOldest[p]] {
				delete(n.hbAcked[p], n.hbOldest[p])
				n.hbOldest[p]++
			}
		}
	case "Complaint":
		if m.Subject < 0 || m.Subject >= len(n.cfg.Members) || m.From == m.Subject || m.HB == 0 {
			break
		}
		key := eventKey(m.Subject, m.HB)
		if _, ok := n.bad[key]; ok {
			break
		}
		if n.complaints[key] == nil {
			n.complaints[key] = map[int]bool{}
		}
		n.complaints[key][m.From] = true
		if len(n.complaints[key]) >= len(n.cfg.Members)-n.cfg.F {
			m.Observers = nil
			for p := range n.complaints[key] {
				m.Observers = append(m.Observers, p)
			}
			if n.installBadLocked(m) {
				m.Kind = "Bad"
				m.To = -1
				out = append(out, m)
			}
		}
	case "Bad":
		if m.Subject >= 0 && m.Subject < len(n.cfg.Members) && m.HB > 0 {
			if n.installBadLocked(m) {
				m.To = -1
				out = append(out, m)
			}
		}
	}
	n.omegaMu.Unlock()
	for _, m := range out {
		if m.To < 0 {
			n.broadcast(m)
		} else {
			n.send(m)
		}
	}
}
func (n *Node) omegaTick() {
	now := n.clock.Now()
	out := []Message{}
	n.omegaMu.Lock()
	if !now.Before(n.nextHB) {
		n.hb++
		out = append(out, Message{To: -1, Kind: "HB", HB: n.hb})
		if n.heartbeats[n.cfg.ID] == nil {
			n.heartbeats[n.cfg.ID] = map[uint64]bool{}
		}
		n.heartbeats[n.cfg.ID][n.hb] = true
		n.nextHB = now.Add(time.Duration(n.cfg.HeartbeatMillis) * time.Millisecond)
	}
	if !now.Before(n.hbRetryAt) {
		for p, k := range n.hbOldest {
			if k <= n.hb {
				out = append(out, Message{To: p, Kind: "HB", HB: k})
			}
		}
		n.hbRetryAt = now.Add(n.cfg.W())
	}
	if !now.Before(n.checkAt) {
		k := n.checkK
		for p := range n.cfg.Members {
			if p != n.cfg.ID && !n.heartbeats[p][k] {
				key := eventKey(p, k)
				if _, bad := n.bad[key]; !bad {
					if n.complaints[key] == nil {
						n.complaints[key] = map[int]bool{}
					}
					n.complaints[key][n.cfg.ID] = true
				}
				out = append(out, Message{To: -1, Kind: "Complaint", Subject: p, HB: k})
			}
			for h := range n.heartbeats[p] {
				if h <= k {
					delete(n.heartbeats[p], h)
				}
			}
		}
		n.checkK++
		n.checkAt = now.Add(time.Duration(n.checkK+1) * n.cfg.W())
	}
	// Fair round-robin retransmission of complete conclusions. Complaints are also
	// retransmitted until complete; late heartbeats never withdraw them.
	for key, observers := range n.complaints {
		if observers[n.cfg.ID] {
			var p int
			var k uint64
			if _, err := fmt.Sscanf(key, "%d/%d", &p, &k); err == nil {
				key := eventKey(p, k)
				if _, bad := n.bad[key]; !bad {
					if n.complaints[key] == nil {
						n.complaints[key] = map[int]bool{}
					}
					n.complaints[key][n.cfg.ID] = true
				}
				out = append(out, Message{To: -1, Kind: "Complaint", Subject: p, HB: k})
			}
		}
	}
	keys := make([]string, 0, len(n.bad))
	for key := range n.bad {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	if len(keys) > 0 {
		m := n.bad[keys[n.badCursor%len(keys)]]
		m.To = -1
		out = append(out, m)
		n.badCursor++
	}
	n.omegaMu.Unlock()
	for _, m := range out {
		if m.To < 0 {
			n.broadcast(m)
		} else {
			n.send(m)
		}
	}
}
