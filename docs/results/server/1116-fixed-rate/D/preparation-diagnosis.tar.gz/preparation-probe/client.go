package mixepaxos

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sync/atomic"
	"time"
)

// Client supports concurrent NewCommand and Do calls. Retain the complete Command
// to retry an uncertain outcome; constructing a new command allocates a new rid.
type Client struct {
	Session  string
	sequence atomic.Uint64
	HTTP     *http.Client
}

func NewClient() (*Client, error) {
	b := make([]byte, 24)
	if _, err := rand.Read(b); err != nil {
		return nil, err
	}
	return &Client{Session: hex.EncodeToString(b), HTTP: &http.Client{}}, nil
}
func (c *Client) NewCommand(op, key, value string) Command {
	var seq uint64
	for {
		old := c.sequence.Load()
		if old == ^uint64(0) {
			panic("client sequence exhausted; create a new session")
		}
		if c.sequence.CompareAndSwap(old, old+1) {
			seq = old + 1
			break
		}
	}
	return Command{RID: RID{c.Session, seq}, Op: op, Key: key, Value: value}
}
func (c *Client) Do(ctx context.Context, address string, cmd Command) Result {
	if err := cmd.Validate(); err != nil {
		return Result{Status: Rejected, Error: err.Error()}
	}
	b, err := json.Marshal(cmd)
	if err != nil {
		return Result{Status: Rejected, Error: err.Error()}
	}
	req, err := http.NewRequestWithContext(ctx, "POST", "http://"+address+"/request", bytes.NewReader(b))
	if err != nil {
		return Result{Status: Rejected, Error: err.Error()}
	}
	req.Header.Set("Content-Type", "application/json")
	client := c.HTTP
	if client == nil {
		client = http.DefaultClient
	}
	resp, err := client.Do(req)
	if err != nil {
		return Result{Status: Unknown, Error: err.Error()}
	}
	defer resp.Body.Close()
	var result Result
	if err := json.NewDecoder(io.LimitReader(resp.Body, 8<<20)).Decode(&result); err != nil {
		return Result{Status: Unknown, Error: err.Error()}
	}
	return result
}

// Retry rotates entry replicas with a bounded per-attempt wait, preserving cmd.
// A terminal duplicate is success evidence but does not recover an old result.
func (c *Client) Retry(ctx context.Context, addresses []string, cmd Command, attemptWait time.Duration) Result {
	if len(addresses) == 0 {
		return Result{Status: Rejected, Error: "no addresses"}
	}
	if attemptWait <= 0 {
		attemptWait = 2 * time.Second
	}
	last := Result{Status: Unknown}
	for i := 0; ctx.Err() == nil; i++ {
		attempt, cancel := context.WithTimeout(ctx, attemptWait)
		last = c.Do(attempt, addresses[i%len(addresses)], cmd)
		cancel()
		switch last.Status {
		case Applied, AlreadyExecuted, Rejected:
			return last
		}
		timer := time.NewTimer(25 * time.Millisecond)
		select {
		case <-ctx.Done():
			timer.Stop()
			return Result{Status: Unknown, Error: ctx.Err().Error()}
		case <-timer.C:
		}
	}
	return Result{Status: Unknown, Error: fmt.Sprint(ctx.Err())}
}
