package mixepaxos_test

import (
    "context"
    "fmt"
    "sync"
    "sync/atomic"
    "testing"
    "time"
    mix "example.com/mixepaxos"
)

type delayedSend struct {
    next mix.Transport
    decided <-chan struct{}
    preToG *atomic.Int64
}

func (d delayedSend) Send(ctx context.Context, to int, m mix.Message) error {
    if m.Kind == "PreAccept" && to == 6 { d.preToG.Add(1) }
    if err := d.next.Send(ctx, to, m); err != nil { return err }
    // Deliver the messages, but delay these four send completions so the
    // initial message for G remains queued until six votes have decided.
    if m.Kind == "PreAccept" && to >= 2 && to <= 5 {
        select {
        case <-d.decided:
        case <-ctx.Done(): return ctx.Err()
        }
    }
    return nil
}

func TestDecidedBeforeLastPreAcceptSend(t *testing.T) {
    net := mix.NewMemoryNetwork(nil)
    var decisionDrops atomic.Int64
    net.SetRule(func(m mix.Message) (int, time.Duration) {
        if m.To == 6 && m.ID == (mix.ID{Replica:0, Index:1}) &&
            (m.Kind == "Learn" || m.Kind == "Done" || m.Kind == "FetchReply" && m.Value != nil) {
            decisionDrops.Add(1)
            return 0, 0
        }
        return 1, 0
    })
    decided := make(chan struct{})
    var once sync.Once
    var preToG atomic.Int64
    nodes := make([]*mix.Node,7)
    for i := range nodes {
        cfg := mix.Config{ID:i, F:4, S:1, E:1, WMillis:1000, K:64, Parallelism:4, QueueLimit:4096, TickMillis:10}
        for j:=0; j<7; j++ { cfg.Members=append(cfg.Members,mix.Member{ID:j,Address:fmt.Sprint("node-",j)}) }
        var transport mix.Transport=net.Endpoint(i)
        if i==0 { transport=delayedSend{transport,decided,&preToG} }
        n,err:=mix.NewNode(cfg,transport,mix.Options{Event:func(e mix.Event){
            if e.Replica==0 && e.Kind=="decide" { once.Do(func(){close(decided)}) }
        }})
        if err!=nil {t.Fatal(err)}
        nodes[i]=n;net.Add(i,n)
    }
    for _,n:=range nodes { n.Start();defer n.Close() }
    ctx,cancel:=context.WithTimeout(context.Background(),3*time.Second);defer cancel()
    result:=nodes[0].Submit(ctx,mix.Command{RID:mix.RID{Client:"preparation-probe",Seq:1},Op:"put",Key:"k",Value:"v"})
    if result.Status!=mix.Applied {t.Fatalf("request: %+v",result)}
    time.Sleep(1500*time.Millisecond)
    for i:=0;i<6;i++ { if s:=nodes[i].Stats();s.Executed!=1 {t.Fatalf("node %d: %+v",i,s)} }
    g:=nodes[6].Stats()
    t.Logf("six replicas executed; G registered=%d executed=%d; PreAccept sends to G=%d; blocked decision frames=%d",g.Registered,g.Executed,preToG.Load(),decisionDrops.Load())
    if g.Registered!=0 || preToG.Load()!=0 || decisionDrops.Load()==0 {t.Fatal("target scenario not reproduced")}
}
