module example.com/mixepaxos

go 1.23
