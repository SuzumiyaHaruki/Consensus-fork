package mixepaxos

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"strconv"
	"time"
	"unicode/utf8"
)

// HTTPTransport uses per-source HMAC keys derived from one runtime cluster
// secret. This authenticates messages against outsiders within a trusted cluster;
// it is not Byzantine protection against a member holding the cluster secret.
type HTTPTransport struct {
	Config Config
	Client *http.Client
}

func NewHTTPTransport(c Config) *HTTPTransport {
	return &HTTPTransport{Config: c, Client: &http.Client{Transport: &http.Transport{MaxIdleConns: 256, MaxIdleConnsPerHost: 32, IdleConnTimeout: 30 * time.Second}}}
}
func sourceKey(secret string, source int) []byte {
	h := hmac.New(sha256.New, []byte(secret))
	fmt.Fprintf(h, "mixepaxos/source/%d", source)
	return h.Sum(nil)
}
func sign(secret string, source int, body []byte) string {
	h := hmac.New(sha256.New, sourceKey(secret, source))
	h.Write(body)
	return hex.EncodeToString(h.Sum(nil))
}
func (t *HTTPTransport) Send(ctx context.Context, to int, m Message) error {
	if to < 0 || to >= len(t.Config.Members) {
		return fmt.Errorf("unknown destination")
	}
	b, err := json.Marshal(m)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, "POST", "http://"+t.Config.Members[to].Address+"/internal/message", bytes.NewReader(b))
	if err != nil {
		return err
	}
	req.Header.Set("X-Mix-Source", strconv.Itoa(t.Config.ID))
	req.Header.Set("X-Mix-MAC", sign(t.Config.Secret, t.Config.ID, b))
	resp, err := t.Client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)
	if resp.StatusCode != http.StatusAccepted {
		return fmt.Errorf("peer response %d", resp.StatusCode)
	}
	return nil
}
func (t *HTTPTransport) Close() { t.Client.CloseIdleConnections() }

// HTTPHandler serves the replica and client endpoints. A nonempty runtime secret
// is mandatory for real sockets. Client endpoints are intended for loopback or a
// separately access-controlled trusted network.
func HTTPHandler(n *Node, secret string) (http.Handler, error) {
	if len(secret) < 16 {
		return nil, fmt.Errorf("cluster secret must have at least 16 bytes")
	}
	mux := http.NewServeMux()
	clientPermits := make(chan struct{}, n.cfg.QueueLimit)
	mux.HandleFunc("/internal/message", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "POST required", 405)
			return
		}
		body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, 64<<20))
		if err != nil {
			http.Error(w, "message too large", 413)
			return
		}
		source, err := strconv.Atoi(r.Header.Get("X-Mix-Source"))
		if err != nil || source < 0 || source >= len(n.cfg.Members) {
			http.Error(w, "source", 401)
			return
		}
		mac, err := hex.DecodeString(r.Header.Get("X-Mix-MAC"))
		expected, _ := hex.DecodeString(sign(secret, source, body))
		if err != nil || !hmac.Equal(mac, expected) {
			http.Error(w, "authentication", 401)
			return
		}
		var m Message
		if json.Unmarshal(body, &m) != nil {
			http.Error(w, "encoding", 400)
			return
		}
		if err := n.Receive(source, m); err != nil {
			http.Error(w, err.Error(), 503)
			return
		}
		w.WriteHeader(202)
	})
	mux.HandleFunc("/request", func(w http.ResponseWriter, r *http.Request) {
		select {
		case clientPermits <- struct{}{}:
			defer func() { <-clientPermits }()
		default:
			writeJSON(w, 429, Result{Status: Overloaded, Error: "HTTP request limit; rejected before admission"})
			return
		}
		if r.Method != "POST" {
			http.Error(w, "POST required", 405)
			return
		}
		var c Command
		body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, 8<<20))
		if err != nil || !utf8.Valid(body) {
			writeJSON(w, 400, Result{Status: Rejected, Error: "invalid or oversized UTF-8 body"})
			return
		}
		dec := json.NewDecoder(bytes.NewReader(body))
		dec.DisallowUnknownFields()
		if err := dec.Decode(&c); err != nil {
			writeJSON(w, 400, Result{Status: Rejected, Error: err.Error()})
			return
		}
		var extra any
		if dec.Decode(&extra) != io.EOF {
			writeJSON(w, 400, Result{Status: Rejected, Error: "trailing JSON"})
			return
		}
		ctx := r.Context()
		wait := 30 * time.Second
		if v := r.URL.Query().Get("wait_ms"); v != "" {
			ms, err := strconv.Atoi(v)
			if err != nil || ms < 1 || ms > 120000 {
				writeJSON(w, 400, Result{Status: Rejected, Error: "invalid wait_ms"})
				return
			}
			wait = time.Duration(ms) * time.Millisecond
		}
		ctx, cancel := context.WithTimeout(ctx, wait)
		defer cancel()
		result := n.Submit(ctx, c)
		code := 200
		if result.Status == Rejected {
			code = 400
		}
		if result.Status == Overloaded {
			code = 429
		}
		if result.Status == Incomplete || result.Status == Unknown {
			code = 202
		}
		writeJSON(w, code, result)
	})
	mux.HandleFunc("/stats", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, 200, n.Stats()) })
	mux.HandleFunc("/kv", func(w http.ResponseWriter, r *http.Request) { writeJSON(w, 200, n.Snapshot()) })
	return mux, nil
}
func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

// Listen only accepts explicit host:port addresses. Examples use loopback.
func Listen(c Config) (net.Listener, error) { return net.Listen("tcp", c.Members[c.ID].Address) }
