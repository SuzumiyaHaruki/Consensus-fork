package mixepaxos

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"
)

// DeliveryRule may drop, duplicate or delay a message. It must not alter sender
// identity or protocol payloads. Rules run concurrently and must synchronize state.
type DeliveryRule func(Message) (copies int, delay time.Duration)
type scheduled struct {
	message Message
	at      time.Time
}

// MemoryNetwork is a socket-free transport using exactly the same Node handlers.
// Delayed messages are retained until Pump, which also allows deterministic order.
type MemoryNetwork struct {
	mu     sync.Mutex
	nodes  map[int]*Node
	rule   DeliveryRule
	queued []scheduled
	clock  Clock
}

func NewMemoryNetwork(clock Clock) *MemoryNetwork {
	if clock == nil {
		clock = RealClock{}
	}
	return &MemoryNetwork{nodes: map[int]*Node{}, clock: clock}
}
func (m *MemoryNetwork) Add(id int, n *Node)       { m.mu.Lock(); m.nodes[id] = n; m.mu.Unlock() }
func (m *MemoryNetwork) Remove(id int)             { m.mu.Lock(); delete(m.nodes, id); m.mu.Unlock() }
func (m *MemoryNetwork) SetRule(rule DeliveryRule) { m.mu.Lock(); m.rule = rule; m.mu.Unlock() }
func (m *MemoryNetwork) Endpoint(id int) Transport { return memoryEndpoint{m, id} }

type memoryEndpoint struct {
	network *MemoryNetwork
	source  int
}

func (e memoryEndpoint) Send(ctx context.Context, to int, msg Message) error {
	if msg.From != e.source || msg.To != to {
		return fmt.Errorf("endpoint identity mismatch")
	}
	select {
	case <-ctx.Done():
		return ctx.Err()
	default:
	}
	// Encoding copies payloads just as the socket transport does.
	b, err := json.Marshal(msg)
	if err != nil {
		return err
	}
	var copyMsg Message
	if err = json.Unmarshal(b, &copyMsg); err != nil {
		return err
	}
	m := e.network
	m.mu.Lock()
	rule := m.rule
	target := m.nodes[to]
	m.mu.Unlock()
	if target == nil {
		return fmt.Errorf("member unavailable")
	}
	copies, delay := 1, time.Duration(0)
	if rule != nil {
		copies, delay = rule(copyMsg)
	}
	for i := 0; i < copies; i++ {
		if delay > 0 {
			m.mu.Lock()
			m.queued = append(m.queued, scheduled{copyMsg, m.clock.Now().Add(delay)})
			m.mu.Unlock()
		} else if err := target.Receive(e.source, copyMsg); err != nil {
			return err
		}
	}
	return nil
}

// Pump delivers ready delayed messages. reverse permits deterministic reordering.
func (m *MemoryNetwork) Pump(reverse bool) int {
	m.mu.Lock()
	now := m.clock.Now()
	due := []Message{}
	keep := m.queued[:0]
	for _, s := range m.queued {
		if !now.Before(s.at) {
			due = append(due, s.message)
		} else {
			keep = append(keep, s)
		}
	}
	m.queued = keep
	nodes := map[int]*Node{}
	for id, n := range m.nodes {
		nodes[id] = n
	}
	m.mu.Unlock()
	for i := range due {
		j := i
		if reverse {
			j = len(due) - 1 - i
		}
		msg := due[j]
		if n := nodes[msg.To]; n != nil {
			_ = n.Receive(msg.From, msg)
		}
	}
	return len(due)
}

type ManualClock struct {
	mu  sync.Mutex
	now time.Time
}

func NewManualClock(t time.Time) *ManualClock { return &ManualClock{now: t} }
func (c *ManualClock) Now() time.Time         { c.mu.Lock(); defer c.mu.Unlock(); return c.now }
func (c *ManualClock) Advance(d time.Duration) {
	if d < 0 {
		panic("negative clock advance")
	}
	c.mu.Lock()
	c.now = c.now.Add(d)
	c.mu.Unlock()
}
