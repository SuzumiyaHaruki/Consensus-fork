package mixepaxos

import (
	"sort"
)

func (n *Node) wakeExecution() {
	select {
	case n.executeWake <- struct{}{}:
	default:
	}
}
func (n *Node) executor() {
	defer n.wg.Done()
	for {
		select {
		case <-n.ctx.Done():
			return
		case <-n.executeWake:
			n.execute()
		}
	}
}

type vertex struct {
	r     *record
	value Value
	deps  []ID
}

// Each attempted closure checks every unexecuted position in each component.
// Get/Get commutes but conflicts induced by rid do not make this relation transitive.
func (n *Node) closure(root *record, seen map[ID]*vertex, visiting map[ID]bool) bool {
	id := root.desc.ID
	if _, ok := seen[id]; ok {
		return true
	}
	if visiting[id] {
		return true
	}
	root.mu.Lock()
	if root.executed {
		root.mu.Unlock()
		return true
	}
	v := root.decided
	root.mu.Unlock()
	if v == nil {
		return false
	}
	visiting[id] = true
	vert := &vertex{r: root, value: *v}
	seen[id] = vert
	ready := true
	for p, hi := range v.Deps {
		for j := n.execHi[p] + 1; j <= hi; j++ {
			y := ID{p, j}
			if y == id {
				continue
			}
			other := n.get(y)
			if other == nil {
				n.fetch(y)
				ready = false
				continue
			}
			other.mu.Lock()
			done := other.executed
			decision := other.decided
			other.mu.Unlock()
			if done {
				continue
			}
			if !Conflict(v.Command, other.desc.Initial.Command) {
				continue
			}
			vert.deps = append(vert.deps, y)
			if decision == nil {
				other.mu.Lock()
				other.pending = true
				other.mu.Unlock()
				ready = false
				continue
			}
			if !n.closure(other, seen, visiting) {
				ready = false
			}
		}
	}
	delete(visiting, id)
	return ready
}
func components(graph map[ID]*vertex) [][]ID {
	next := 0
	index := map[ID]int{}
	low := map[ID]int{}
	on := map[ID]bool{}
	stack := []ID{}
	out := [][]ID{}
	var visit func(ID)
	visit = func(x ID) {
		next++
		index[x] = next
		low[x] = next
		stack = append(stack, x)
		on[x] = true
		for _, y := range graph[x].deps {
			if graph[y] == nil {
				continue
			}
			if index[y] == 0 {
				visit(y)
				if low[y] < low[x] {
					low[x] = low[y]
				}
			} else if on[y] && index[y] < low[x] {
				low[x] = index[y]
			}
		}
		if low[x] == index[x] {
			c := []ID{}
			for {
				y := stack[len(stack)-1]
				stack = stack[:len(stack)-1]
				on[y] = false
				c = append(c, y)
				if y == x {
					break
				}
			}
			out = append(out, c)
		}
	}
	ids := make([]ID, 0, len(graph))
	for x := range graph {
		ids = append(ids, x)
	}
	sort.Slice(ids, func(i, j int) bool { return LessID(ids[i], ids[j]) })
	for _, x := range ids {
		if index[x] == 0 {
			visit(x)
		}
	}
	return out
}
func (n *Node) execute() {
	// A single application executor serializes independent SCCs. Message handlers
	// and coordination remain concurrent; application locks protect public reads.
	for _, root := range n.allRecords() {
		root.mu.Lock()
		eligible := root.decided != nil && !root.executed
		root.mu.Unlock()
		if !eligible {
			continue
		}
		graph := map[ID]*vertex{}
		if !n.closure(root, graph, map[ID]bool{}) {
			continue
		}
		for _, c := range components(graph) {
			sort.Slice(c, func(i, j int) bool {
				a, b := graph[c[i]].value.Seq, graph[c[j]].value.Seq
				if a != b {
					return a < b
				}
				return LessID(c[i], c[j])
			})
			ready := true
			inside := map[ID]bool{}
			for _, x := range c {
				inside[x] = true
			}
			for _, x := range c {
				r := graph[x].r
				r.mu.Lock()
				done := r.executed
				r.mu.Unlock()
				if done {
					ready = false
					break
				}
				for _, y := range graph[x].deps {
					if inside[y] {
						continue
					}
					other := graph[y]
					if other == nil {
						ready = false
						break
					}
					other.r.mu.Lock()
					done := other.r.executed
					other.r.mu.Unlock()
					if !done {
						ready = false
					}
				}
			}
			if !ready {
				continue
			}
			n.applySCC(c, graph)
		}
	}
}
func (n *Node) applySCC(c []ID, graph map[ID]*vertex) {
	// Node.mu -> appMu is the same lock order as admission and Submit. Execution
	// flags and slot release become visible together after all SCC applications.
	n.mu.Lock()
	n.appMu.Lock()
	prepared := map[RID]Result{}
	commands := map[RID]Command{}
	for _, x := range c {
		cmd := graph[x].value.Command
		if old, ok := n.bindings[cmd.RID]; ok && old != cmd {
			n.fault = "contradictory rid at execution"
			n.appMu.Unlock()
			n.mu.Unlock()
			return
		}
		commands[cmd.RID] = cmd
		if _, ok := n.executedRequests[cmd.RID]; ok {
			if _, exists := prepared[cmd.RID]; !exists {
				prepared[cmd.RID] = Result{Status: AlreadyExecuted}
			}
			continue
		}
		old, found := n.kv[cmd.Key]
		result := Result{Status: Applied, Value: old, Found: found}
		switch cmd.Op {
		case "put":
			n.kv[cmd.Key] = cmd.Value
		case "delete":
			delete(n.kv, cmd.Key)
		case "get":
		}
		n.executedRequests[cmd.RID] = cmd
		prepared[cmd.RID] = result
	}
	for _, x := range c {
		r := graph[x].r
		r.mu.Lock()
		r.executed = true
		r.mu.Unlock()
		delete(n.slots, x)
		delete(n.live, x)
	}
	for p := range n.execHi {
		for {
			r := n.records[ID{p, n.execHi[p] + 1}]
			if r == nil {
				break
			}
			r.mu.Lock()
			done := r.executed
			r.mu.Unlock()
			if !done {
				break
			}
			n.execHi[p]++
		}
	}
	type delivery struct {
		ch     chan Result
		result Result
	}
	deliveries := []delivery{}
	for rid, result := range prepared {
		if e := n.entries[rid]; e != nil {
			for _, ch := range e.waiters {
				deliveries = append(deliveries, delivery{ch, result})
			}
			e.waiters = map[uint64]chan Result{}
			delete(n.entries, rid)
		}
		_ = commands[rid]
	}
	queue := n.queue[:0]
	for _, e := range n.queue {
		if n.entries[e.cmd.RID] == e {
			queue = append(queue, e)
		}
	}
	for i := len(queue); i < len(n.queue); i++ {
		n.queue[i] = nil
	}
	n.queue = queue
	n.appMu.Unlock()
	n.mu.Unlock()
	for _, d := range deliveries {
		d.ch <- d.result
	}
	for _, x := range c {
		n.emit("execute", x, "")
	}
}
