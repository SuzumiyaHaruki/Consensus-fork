package mixepaxos

import (
	"context"
	"fmt"
	"sort"
	"sync"
	"sync/atomic"
	"time"
)

type Clock interface{ Now() time.Time }
type RealClock struct{}

func (RealClock) Now() time.Time { return time.Now() }

// Send must return when ctx expires. Implementations must authenticate the source
// independently of Message.From. Receive checks both identities again.
type Transport interface {
	Send(context.Context, int, Message) error
}
type Event struct {
	Time    time.Time
	Replica int
	Kind    string
	ID      ID
	Detail  string
}
type Options struct {
	Clock Clock
	Event func(Event)
}
type record struct {
	mu                       sync.Mutex
	desc                     Descriptor // immutable after construction
	ready, registered        bool       // protected by Node.mu
	first                    *First
	promise, highest         Ballot
	accepted                 *Accepted
	decided                  *Value
	executed                 bool
	task                     *task
	lastRejection            string
	noFast                   bool
	mismatches               map[int]bool
	forced                   map[ID]bool
	pending                  bool
	created, retryAt, needAt time.Time
	helpForwardAt            time.Time
	helps                    map[string]Message
}
type entry struct {
	cmd     Command
	id      *ID
	waiters map[uint64]chan Result
}
type Stats struct {
	Registered     int    `json:"registered"`
	Active         int    `json:"active"`
	OwnedActive    int    `json:"owned_active"`
	AcceptMax      int64  `json:"accept_max"`
	AcceptCount    uint64 `json:"accept_count"`
	Executed       int    `json:"executed"`
	Slots          int    `json:"slots"`
	Queued         int    `json:"queued"`
	PendingData    int    `json:"pending_data"`
	Omega          int    `json:"omega"`
	Messages       uint64 `json:"messages"`
	Drops          uint64 `json:"drops"`
	SendErrors     uint64 `json:"send_errors"`
	WindowOverruns uint64 `json:"window_overruns"`
	HandlerActive  int64  `json:"handler_active"`
	HandlerMax     int64  `json:"handler_max"`
	Fault          string `json:"fault,omitempty"`
}
type Node struct {
	cfg              Config
	transport        Transport
	clock            Clock
	event            func(Event)
	ctx              context.Context
	cancel           context.CancelFunc
	wg               sync.WaitGroup
	start            sync.Once
	stop             sync.Once
	pulseMu          sync.Mutex
	cursor           int
	mu               sync.RWMutex
	records          map[ID]*record
	live             map[ID]*record
	incomplete       map[ID]bool
	newlyReady       []*record
	peerMu           sync.RWMutex
	peerKnown        map[int]map[ID]bool
	keyIndex         map[string]map[ID]*record
	ridIndex         map[RID]map[ID]*record
	bindings         map[RID]Command
	entries          map[RID]*entry
	queue            []*entry
	slots            map[ID]bool
	next             uint64
	missing          map[ID]time.Time
	deferred         map[string]Message
	fault            string
	jobs             chan Message
	sendMu           sync.Mutex
	outgoing         map[string]bool
	sends            chan Message
	uid              atomic.Uint64
	messages         atomic.Uint64
	drops            atomic.Uint64
	sendErrors       atomic.Uint64
	overruns         atomic.Uint64
	handlerActive    atomic.Int64
	handlerMax       atomic.Int64
	acceptActive     atomic.Int64
	acceptMax        atomic.Int64
	acceptCount      atomic.Uint64
	appMu            sync.Mutex
	kv               map[string]string
	executedRequests map[RID]Command
	execHi           []uint64
	executeWake      chan struct{}
	omegaMu          sync.Mutex
	omega            int
	hb               uint64
	nextHB           time.Time
	checkK           uint64
	checkAt          time.Time
	hbAcked          []map[uint64]bool
	hbOldest         []uint64
	hbRetryAt        time.Time
	heartbeats       map[int]map[uint64]bool
	complaints       map[string]map[int]bool
	bad              map[string]Message
	badCounts        []uint64
	badCursor        int
}

func NewNode(cfg Config, t Transport, opts Options) (*Node, error) {
	cfg.Defaults()
	cfg.Members = append([]Member(nil), cfg.Members...)
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	if t == nil {
		return nil, fmt.Errorf("transport is required")
	}
	if opts.Clock == nil {
		opts.Clock = RealClock{}
	}
	ctx, cancel := context.WithCancel(context.Background())
	n := &Node{cfg: cfg, transport: t, clock: opts.Clock, event: opts.Event, ctx: ctx, cancel: cancel, records: map[ID]*record{}, live: map[ID]*record{}, incomplete: map[ID]bool{}, peerKnown: map[int]map[ID]bool{}, keyIndex: map[string]map[ID]*record{}, ridIndex: map[RID]map[ID]*record{}, bindings: map[RID]Command{}, entries: map[RID]*entry{}, slots: map[ID]bool{}, missing: map[ID]time.Time{}, deferred: map[string]Message{}, jobs: make(chan Message, cfg.QueueLimit), sends: make(chan Message, cfg.QueueLimit), outgoing: map[string]bool{}, kv: map[string]string{}, executedRequests: map[RID]Command{}, execHi: make([]uint64, len(cfg.Members)), executeWake: make(chan struct{}, 1), heartbeats: map[int]map[uint64]bool{}, complaints: map[string]map[int]bool{}, bad: map[string]Message{}, badCounts: make([]uint64, len(cfg.Members)), checkK: 1}
	n.hbAcked = make([]map[uint64]bool, len(cfg.Members))
	n.hbOldest = make([]uint64, len(cfg.Members))
	for p := range cfg.Members {
		n.hbAcked[p] = map[uint64]bool{}
		n.hbOldest[p] = 1
	}
	now := n.clock.Now()
	n.checkAt = now.Add(2 * cfg.W())
	return n, nil
}
func (n *Node) Config() Config { c := n.cfg; c.Members = append([]Member(nil), c.Members...); return c }
func (n *Node) emit(kind string, id ID, detail string) {
	if n.event != nil {
		n.event(Event{n.clock.Now(), n.cfg.ID, kind, id, detail})
	}
}
func (n *Node) Start() {
	n.start.Do(func() {
		for i := 0; i < n.cfg.Parallelism; i++ {
			n.wg.Add(1)
			go n.worker()
		}
		for i := 0; i < n.cfg.Parallelism; i++ {
			n.wg.Add(1)
			go n.sender()
		}
		n.wg.Add(2)
		go n.run()
		go n.executor()
	})
}
func (n *Node) Close() { n.stop.Do(func() { n.cancel(); n.wg.Wait() }) }
func (n *Node) Receive(source int, m Message) error {
	if source < 0 || source >= len(n.cfg.Members) || m.From != source || m.To != n.cfg.ID {
		return fmt.Errorf("unauthenticated source or wrong destination")
	}
	select {
	case <-n.ctx.Done():
		return fmt.Errorf("node stopped")
	case n.jobs <- m:
		return nil
	default:
		n.drops.Add(1)
		return fmt.Errorf("receive queue full")
	}
}
func (n *Node) worker() {
	defer n.wg.Done()
	for {
		select {
		case <-n.ctx.Done():
			return
		case m := <-n.jobs:
			a := n.handlerActive.Add(1)
			for {
				v := n.handlerMax.Load()
				if a <= v || n.handlerMax.CompareAndSwap(v, a) {
					break
				}
			}
			n.emit("handler_start", m.ID, m.Kind)
			n.handle(m)
			n.emit("handler_end", m.ID, m.Kind)
			n.handlerActive.Add(-1)
		}
	}
}
func (n *Node) sender() {
	defer n.wg.Done()
	for {
		select {
		case <-n.ctx.Done():
			return
		case m := <-n.sends:
			n.deliver(m)
		}
	}
}
func (n *Node) deliver(m Message) {
	defer func() { n.sendMu.Lock(); delete(n.outgoing, m.queueKey); n.sendMu.Unlock() }()
	if !n.outboundCurrent(m) {
		return
	}
	ctx, cancel := context.WithTimeout(n.ctx, n.cfg.W())
	err := n.transport.Send(ctx, m.To, m)
	cancel()
	if err != nil {
		n.sendErrors.Add(1)
	}
	if n.clock.Now().Sub(m.queuedAt) > n.cfg.W() {
		n.overruns.Add(1)
	}
}

func (n *Node) send(m Message) {
	m.From = n.cfg.ID
	if m.Kind != "FetchReply" && len(m.Data) > 0 {
		n.peerMu.RLock()
		filtered := make([]Descriptor, 0, len(m.Data))
		for _, d := range m.Data {
			if !n.peerKnown[m.To][d.ID] {
				filtered = append(filtered, d)
			}
		}
		m.Data = filtered
		n.peerMu.RUnlock()
	}
	key := fmt.Sprintf("%d/%s/%d/%d", m.To, messageKey(m), m.Subject, m.HB)
	n.sendMu.Lock()
	if n.outgoing[key] {
		n.sendMu.Unlock()
		return
	}
	n.outgoing[key] = true
	n.sendMu.Unlock()
	m.queuedAt = n.clock.Now()
	m.queueKey = key

	select {
	case n.sends <- m:
	default:
		n.sendMu.Lock()
		delete(n.outgoing, key)
		n.sendMu.Unlock()
		n.drops.Add(1)
	}
}
func (n *Node) broadcast(m Message) {
	for i := range n.cfg.Members {
		m.To = i
		n.send(m)
	}
}
func (n *Node) run() {
	defer n.wg.Done()
	ticker := time.NewTicker(time.Duration(n.cfg.TickMillis) * time.Millisecond)
	defer ticker.Stop()
	for {
		select {
		case <-n.ctx.Done():
			return
		case <-ticker.C:
			n.Pulse()
		}
	}
}

// Pulse performs timer work using the injected clock. It is also safe with Start;
// callers should serialize controlled pulses with each other.
func (n *Node) Pulse() {
	n.pulseMu.Lock()
	defer n.pulseMu.Unlock()
	n.admit()
	n.retryData()
	n.omegaTick()
	records := n.allRecords()
	if len(records) > 0 {
		start := n.cursor % len(records)
		for i := range records {
			n.advance(records[(start+i)%len(records)])
		}
		n.cursor = (start + 1) % len(records)
	}
	n.wakeExecution()
}
func (n *Node) allRecords() []*record {
	n.mu.RLock()
	defer n.mu.RUnlock()
	out := make([]*record, 0, len(n.records))
	for _, r := range n.live {
		if r.ready {
			out = append(out, r)
		}
	}
	sort.Slice(out, func(i, j int) bool { return LessID(out[i].desc.ID, out[j].desc.ID) })
	return out
}
func (n *Node) get(x ID) *record {
	n.mu.RLock()
	defer n.mu.RUnlock()
	r := n.records[x]
	if r != nil && !r.ready {
		return nil
	}
	return r
}
func (n *Node) fail(s string) {
	n.mu.Lock()
	if n.fault == "" {
		n.fault = s
	}
	n.mu.Unlock()
	n.emit("fault", ID{}, s)
}
func (n *Node) Submit(ctx context.Context, c Command) Result {
	if err := c.Validate(); err != nil {
		return Result{Status: Rejected, Error: err.Error()}
	}
	n.mu.Lock()
	if n.ctx.Err() != nil || n.fault != "" {
		n.mu.Unlock()
		return Result{Status: Unknown, Error: "node unavailable"}
	}
	if old, ok := n.bindings[c.RID]; ok && old != c {
		n.mu.Unlock()
		return Result{Status: Rejected, Error: "contradictory request identity"}
	}
	n.appMu.Lock()
	_, done := n.executedRequests[c.RID]
	n.appMu.Unlock()
	if done {
		n.mu.Unlock()
		return Result{Status: AlreadyExecuted}
	}
	e := n.entries[c.RID]
	if e == nil {
		if len(n.queue) >= n.cfg.QueueLimit {
			n.mu.Unlock()
			return Result{Status: Overloaded, Error: "rejected before admission"}
		}
		e = &entry{cmd: c, waiters: map[uint64]chan Result{}}
		n.entries[c.RID] = e
		n.queue = append(n.queue, e)
		n.bindings[c.RID] = c
		// Reuse an instance learned from another entry replica, when one is known.
		if ids := n.ridIndex[c.RID]; len(ids) > 0 {
			var best *ID
			for id := range ids {
				z := id
				if best == nil || LessID(z, *best) {
					best = &z
				}
			}
			e.id = best
			n.queue = n.queue[:len(n.queue)-1]
		}
	}
	if len(e.waiters) >= n.cfg.QueueLimit {
		id := e.id
		status := Incomplete
		if id != nil {
			status = Unknown
		}
		n.mu.Unlock()
		return Result{Status: status, Instance: id, Error: "too many waiters; existing work continues"}
	}
	w := n.fresh()
	ch := make(chan Result, 1)
	e.waiters[w] = ch
	n.mu.Unlock()
	select {
	case result := <-ch:
		return result
	case <-ctx.Done():
		n.mu.Lock()
		delete(e.waiters, w)
		id := e.id
		n.mu.Unlock()
		status := Incomplete
		if id != nil {
			status = Unknown
		}
		return Result{Status: status, Error: ctx.Err().Error(), Instance: id}
	case <-n.ctx.Done():
		return Result{Status: Unknown, Error: "node stopped"}
	}
}
func (n *Node) scanLocked(c Command, x ID) (Vector, uint64) {
	d := make(Vector, len(n.cfg.Members))
	seq := uint64(0)
	visit := func(r *record) {
		if r.desc.ID != x && Conflict(c, r.desc.Initial.Command) {
			id := r.desc.ID
			if id.Index > d[id.Replica] {
				d[id.Replica] = id.Index
			}
			if r.desc.Initial.Seq > seq {
				seq = r.desc.Initial.Seq
			}
		}
	}
	for _, r := range n.keyIndex[c.Key] {
		visit(r)
	}
	for _, r := range n.ridIndex[c.RID] {
		if r.desc.Initial.Command.Key != c.Key {
			visit(r)
		}
	}
	return d, seq
}
func (n *Node) registerLocked(r *record) {
	if r.registered {
		return
	}
	r.registered = true
	n.live[r.desc.ID] = r
	c := r.desc.Initial.Command
	if n.keyIndex[c.Key] == nil {
		n.keyIndex[c.Key] = map[ID]*record{}
	}
	n.keyIndex[c.Key][r.desc.ID] = r
	if n.ridIndex[c.RID] == nil {
		n.ridIndex[c.RID] = map[ID]*record{}
	}
	n.ridIndex[c.RID][r.desc.ID] = r
	if old, ok := n.bindings[c.RID]; ok && old != c {
		n.fault = "contradictory rid discovered in cluster"
	} else {
		n.bindings[c.RID] = c
	}
}
func newRecord(d Descriptor, now time.Time) *record {
	return &record{desc: d, created: now, pending: true, mismatches: map[int]bool{}, forced: map[ID]bool{}, helps: map[string]Message{}}
}
func (n *Node) admit() {
	n.mu.Lock()
	defer n.mu.Unlock()
	if n.fault != "" {
		return
	}
	for len(n.queue) > 0 && len(n.slots) < n.cfg.K {
		e := n.queue[0]
		n.queue[0] = nil
		n.queue = n.queue[1:]
		if e.id != nil {
			continue
		}
		if ids := n.ridIndex[e.cmd.RID]; len(ids) > 0 {
			var best *ID
			for id := range ids {
				copy := id
				if best == nil || LessID(copy, *best) {
					best = &copy
				}
			}
			e.id = best
			continue
		}
		n.appMu.Lock()
		_, done := n.executedRequests[e.cmd.RID]
		n.appMu.Unlock()
		if done {
			for _, ch := range e.waiters {
				ch <- Result{Status: AlreadyExecuted}
			}
			delete(n.entries, e.cmd.RID)
			continue
		}
		if n.next >= ^uint64(0)-1 {
			n.fault = "instance number space exhausted"
			return
		}
		n.next++
		id := ID{n.cfg.ID, n.next}
		d, s := n.scanLocked(e.cmd, id)
		carry := make([]ID, 0, len(n.slots))
		for old := range n.slots {
			carry = append(carry, old)
		}
		sort.Slice(carry, func(i, j int) bool { return LessID(carry[i], carry[j]) })
		v := Value{e.cmd, d, s + 1}
		r := newRecord(Descriptor{id, v, carry}, n.clock.Now())
		r.ready = true
		r.first = &First{v, d, s + 1, true}
		n.records[id] = r
		n.registerLocked(r)
		n.slots[id] = true
		e.id = &id
		r.task = n.initialTask(r)
		n.emit("admit", id, "")
	}
}
func (n *Node) Stats() Stats {
	s := Stats{Messages: n.messages.Load(), Drops: n.drops.Load(), SendErrors: n.sendErrors.Load(), WindowOverruns: n.overruns.Load(), HandlerActive: n.handlerActive.Load(), HandlerMax: n.handlerMax.Load(), AcceptMax: n.acceptMax.Load(), AcceptCount: n.acceptCount.Load()}
	n.mu.Lock()
	s.Slots = len(n.slots)
	s.Queued = len(n.queue)
	s.PendingData = len(n.missing)
	s.Fault = n.fault
	for _, r := range n.records {
		if r.registered {
			s.Registered++
		}
		r.mu.Lock()
		if r.executed {
			s.Executed++
		} else if r.registered && r.decided == nil {
			s.Active++
			if r.desc.ID.Replica == n.cfg.ID {
				s.OwnedActive++
			}
		}
		r.mu.Unlock()
	}
	n.mu.Unlock()
	s.Omega = n.Omega()
	return s
}
func (n *Node) Snapshot() map[string]string {
	n.appMu.Lock()
	defer n.appMu.Unlock()
	m := map[string]string{}
	for k, v := range n.kv {
		m[k] = v
	}
	return m
}

// Inspect returns retained protocol state for diagnostics and controlled tests.
func (n *Node) Inspect(x ID) (Descriptor, *First, *Accepted, *Value, Ballot, bool) {
	r := n.get(x)
	if r == nil {
		return Descriptor{}, nil, nil, nil, Ballot{}, false
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	d := cloneDescriptor(r.desc)
	var f *First
	var a *Accepted
	var v *Value
	if r.first != nil {
		copy := *r.first
		copy.Initial = cloneValue(copy.Initial)
		copy.Deps = append(Vector(nil), copy.Deps...)
		f = &copy
	}
	if r.accepted != nil {
		copy := *r.accepted
		copy.Value = cloneValue(copy.Value)
		a = &copy
	}
	if r.decided != nil {
		copy := cloneValue(*r.decided)
		v = &copy
	}
	return d, f, a, v, r.promise, r.executed
}

func (n *Node) outboundCurrent(m Message) bool {
	switch m.Kind {
	case "PreAccept", "Prepare", "Observe", "Validate", "Accept":
		r := n.get(m.ID)
		if r == nil {
			return false
		}
		r.mu.Lock()
		defer r.mu.Unlock()
		return r.task != nil && r.task.ballot == m.Ballot && !m.Ballot.Less(r.promise) && r.decided == nil
	}
	return true
}

func (n *Node) fresh() uint64 {
	for {
		old := n.uid.Load()
		if old == ^uint64(0) {
			panic("invocation identity space exhausted")
		}
		if n.uid.CompareAndSwap(old, old+1) {
			return old + 1
		}
	}
}
