package mixepaxos

import (
	"fmt"
	"time"
)

type collection struct {
	kind                  string
	attempt               uint64
	phase                 int
	nonce1, nonce2        uint64
	a, b                  map[int]Message
	start, last           time.Time
	windowChecked         bool
	done, handled, failed bool
	value                 Value
}
type task struct {
	id           uint64
	ballot       Ballot
	initial      bool
	branch       string
	c            *collection
	selected     *Value
	preAttempt   uint64
	preStart     time.Time
	preRequests  []Message
	preLast      time.Time
	observations []Message
	firstSeen    map[int]bool
	voters       map[int]bool
	mismatch     bool
	strong       bool
	upper        Vector
	unresolved   map[ID]bool
	helpAt       time.Time
}

func (n *Node) newCollect(kind string, b Ballot, v Value) *collection {
	return &collection{kind: kind, attempt: n.fresh(), phase: 1, nonce1: n.fresh(), a: map[int]Message{}, b: map[int]Message{}, value: v}
}
func (n *Node) initialTask(r *record) *task {
	c := n.newCollect("PreAccept", ZeroBallot, r.desc.Initial)
	return &task{id: n.fresh(), ballot: ZeroBallot, initial: true, branch: "initial", c: c, preAttempt: c.attempt, preStart: c.start, voters: map[int]bool{n.cfg.ID: true}, firstSeen: map[int]bool{}}
}
func (n *Node) collectMessage(r *record, t *task, c *collection) Message {
	nonce := c.nonce1
	if c.phase == 2 {
		nonce = c.nonce2
	}
	v := c.value
	return Message{To: -1, Kind: c.kind, ID: r.desc.ID, Ballot: t.ballot, Value: &v, Attempt: c.attempt, Phase: c.phase, Nonce: nonce}
}
func (n *Node) startBranch(r *record, t *task, branch, kind string) {
	t.branch = branch
	t.c = n.newCollect(kind, t.ballot, r.desc.Initial)
}
func (n *Node) runAcceptLocked(r *record, t *task, v Value) {
	if t.selected != nil {
		return
	}
	t.selected = &v
	t.observations = nil
	t.branch = "accept"
	t.c = n.newCollect("Accept", t.ballot, v)
}
func results(c *collection) []Message {
	out := make([]Message, 0, len(c.a)+len(c.b))
	for _, m := range c.a {
		out = append(out, m)
	}
	for _, m := range c.b {
		out = append(out, m)
	}
	return out
}
func unionSize(c *collection) int {
	u := map[int]bool{}
	for p := range c.a {
		u[p] = true
	}
	for p := range c.b {
		u[p] = true
	}
	return len(u)
}
func (n *Node) handleReply(r *record, m Message) {
	var decision *Value
	r.mu.Lock()
	t := r.task
	if m.Kind == "Nack" {
		r.lastRejection = m.Reason
		if r.highest.Less(m.Promise) {
			r.highest = m.Promise
		}
		if t != nil && (t.ballot.Less(m.Promise) || t.c != nil && m.Attempt == t.c.attempt) {
			r.task = nil
			r.pending = true
			r.retryAt = n.clock.Now().Add(n.cfg.W())
		}
		r.mu.Unlock()
		return
	}
	if t == nil || r.decided != nil {
		r.mu.Unlock()
		return
	}
	if m.Kind == "PreAcceptReply" && t.initial && m.Attempt == t.preAttempt && m.First != nil {
		t.firstSeen[m.From] = true
		f := m.First
		if !EqualValue(f.Initial, r.desc.Initial) {
			r.mu.Unlock()
			return
		}
		if !f.Fast {
			t.mismatch = true
			r.mismatches[m.From] = true
		} else {
			t.voters[m.From] = true
		}
		if len(r.mismatches) > n.cfg.E {
			r.noFast = true
		}
		if !t.mismatch && len(t.voters) >= len(n.cfg.Members)-n.cfg.E {
			v := r.desc.Initial
			decision = &v
		}
	}
	c := t.c
	if c != nil && !c.done && !c.failed && m.Attempt == c.attempt && m.Ballot == t.ballot {
		expected := map[string]string{"PreAccept": "PreAcceptReply", "Prepare": "PrepareReply", "Observe": "ScanReply", "Validate": "ScanReply", "Accept": "AcceptACK"}[c.kind]
		valid := m.Kind == expected
		if c.kind == "PreAccept" && m.First == nil {
			valid = false
		}
		if (c.kind == "Observe" || c.kind == "Validate") && m.Scan == nil {
			valid = false
		}
		if c.kind == "Accept" && (m.Value == nil || !EqualValue(*m.Value, c.value)) {
			valid = false
		}
		if valid {
			if c.phase == 1 && m.Phase == 1 && m.Nonce == c.nonce1 {
				c.a[m.From] = m
			} else if c.phase == 2 && m.Phase == 2 && m.Nonce == c.nonce2 {
				c.b[m.From] = m
			}
			n.thresholdLocked(c)
		}
	}
	r.mu.Unlock()
	if decision != nil {
		n.commit(r, *decision, t)
	}
}
func (n *Node) thresholdLocked(c *collection) {
	if c.done {
		return
	}
	if c.phase == 1 && len(c.a) >= n.cfg.F+1 {
		c.done = true
	}
	if c.phase == 2 && (len(c.b) >= len(n.cfg.Members)-n.cfg.F || unionSize(c) >= n.cfg.F+1) {
		c.done = true
	}
}

type knownInstance struct {
	desc    Descriptor
	decided *Value
}

func (n *Node) related(r *record) map[ID]knownInstance {
	r.mu.Lock()
	ids := map[ID]bool{}
	for x := range r.forced {
		ids[x] = true
	}
	if r.task != nil {
		for x := range r.task.unresolved {
			ids[x] = true
		}
	}
	r.mu.Unlock()
	out := map[ID]knownInstance{}
	for id := range ids {
		other := n.get(id)
		if other == nil {
			n.fetch(id)
			continue
		}
		other.mu.Lock()
		out[id] = knownInstance{other.desc, other.decided}
		other.mu.Unlock()
	}
	return out
}
func (n *Node) advance(r *record) {
	known := n.related(r)
	omega := n.Omega()
	now := n.clock.Now()
	actions := []Message{}
	var decision *Value
	r.mu.Lock()
	if r.decided != nil {
		r.mu.Unlock()
		return
	}
	if now.Sub(r.created) >= time.Duration(n.cfg.GraceMillis)*time.Millisecond {
		r.pending = true
		if now.Sub(r.needAt) >= n.cfg.W() {
			actions = append(actions, Message{To: -1, Kind: "NeedRecover", ID: r.desc.ID})
			r.needAt = now
		}
	}
	if t := r.task; t != nil && !t.initial && omega != n.cfg.ID {
		r.task = nil
		r.pending = true
	}
	if r.pending && omega == n.cfg.ID && !now.Before(r.retryAt) && now.Sub(r.created) >= time.Duration(n.cfg.GraceMillis)*time.Millisecond && (r.task == nil || r.task.initial) {
		round := r.highest.Round + 1
		if round <= r.promise.Round {
			round = r.promise.Round + 1
		}
		b := Ballot{round, n.cfg.ID}
		r.highest = b
		r.promise = b
		t := &task{id: n.fresh(), ballot: b, branch: "prepare"}
		t.c = n.newCollect("Prepare", b, r.desc.Initial)
		r.task = t
	}
	if omega != n.cfg.ID && now.Sub(r.helpForwardAt) >= n.cfg.W() {
		for _, h := range r.helps {
			h.To = omega
			actions = append(actions, h)
		}
		r.helpForwardAt = now
	}
	t := r.task
	if t != nil {
		c := t.c
		if c != nil && !c.done {
			if c.start.IsZero() {
				c.start = now
				if t.initial && c.kind == "PreAccept" {
					t.preStart = now
				}
			}
			if !c.windowChecked && !now.Before(c.start.Add(n.cfg.W())) {
				c.windowChecked = true
				if len(c.a) < len(n.cfg.Members)-n.cfg.F-n.cfg.S {
					n.overruns.Add(1)
				}
			}
			if c.phase == 1 && !now.Before(c.start.Add(n.cfg.W())) && len(c.a) >= len(n.cfg.Members)-n.cfg.F && len(c.a) < n.cfg.F+1 {
				c.phase = 2
				c.nonce2 = n.fresh()
				c.last = time.Time{}
			}
			n.thresholdLocked(c)
			retry := n.cfg.W()
			if retry < 10*time.Millisecond {
				retry = 10 * time.Millisecond
			}
			if !c.done && now.Sub(c.last) >= retry {
				m := n.collectMessage(r, t, c)
				for p := range n.cfg.Members {
					_, replied := c.a[p]
					if c.phase == 2 {
						_, replied = c.b[p]
					}
					if !replied {
						copy := m
						copy.To = p
						actions = append(actions, copy)
					}
				}
				c.last = now
				if t.initial && c.kind == "PreAccept" {
					found := false
					for _, p := range t.preRequests {
						if p.Nonce == m.Nonce {
							found = true
						}
					}
					if !found {
						t.preRequests = append(t.preRequests, m)
					}
				}
			}
		}
		if c != nil && c.done && !c.handled {
			c.handled = true
			obs := results(c)
			switch c.kind {
			case "PreAccept":
				t.observations = obs
			case "Prepare":
				var highest *Accepted
				members := map[int]bool{}
				fast := map[int]bool{}
				for _, m := range obs {
					members[m.From] = true
					if m.First != nil && m.First.Fast && EqualValue(m.First.Initial, r.desc.Initial) {
						fast[m.From] = true
					}
					if m.First != nil && !m.First.Fast {
						r.mismatches[m.From] = true
					}
					if m.Accepted != nil && (highest == nil || highest.Ballot.Less(m.Accepted.Ballot)) {
						highest = m.Accepted
					}
				}
				if len(r.mismatches) > n.cfg.E {
					r.noFast = true
				}
				if highest != nil {
					n.runAcceptLocked(r, t, highest.Value)
				} else if r.noFast || len(members)-len(fast) > n.cfg.E {
					r.noFast = true
					n.startBranch(r, t, "rebuild", "Observe")
				} else {
					t.strong = len(fast) > n.cfg.E
					n.startBranch(r, t, "validate", "Validate")
				}
			case "Observe":
				all := true
				for id := range r.forced {
					if _, ok := known[id]; !ok {
						all = false
					}
				}
				if !all {
					c.handled = false
					break
				}
				d := append(Vector(nil), r.desc.Initial.Deps...)
				seq := r.desc.Initial.Seq
				for _, m := range obs {
					d = Merge(d, m.Scan.Deps)
					if m.Scan.Seq > seq {
						seq = m.Scan.Seq
					}
				}
				for id := range r.forced {
					y := known[id]
					if id != r.desc.ID && Conflict(r.desc.Initial.Command, y.desc.Initial.Command) {
						if id.Index > d[id.Replica] {
							d[id.Replica] = id.Index
						}
						if y.desc.Initial.Seq+1 > seq {
							seq = y.desc.Initial.Seq + 1
						}
					}
				}
				n.runAcceptLocked(r, t, Value{r.desc.Initial.Command, d, seq})
			case "Validate":
				d := append(Vector(nil), r.desc.Initial.Deps...)
				for _, m := range obs {
					d = Merge(d, m.Scan.Deps)
				}
				t.upper = d
				t.unresolved = map[ID]bool{}
				for p, hi := range d {
					for j := r.desc.Initial.Deps[p] + 1; j <= hi; j++ {
						t.unresolved[ID{p, j}] = true
					}
				}
			case "Accept":
				v := c.value
				decision = &v
			}
		}
		if t.initial && t.selected == nil && t.observations != nil && !now.Before(t.preStart.Add(n.cfg.W())) {
			d := append(Vector(nil), r.desc.Initial.Deps...)
			seq := r.desc.Initial.Seq
			for _, m := range t.observations {
				d = Merge(d, m.First.Deps)
				if m.First.Seq > seq {
					seq = m.First.Seq
				}
			}
			n.runAcceptLocked(r, t, Value{r.desc.Initial.Command, d, seq})
		}
		// Late initial votes remain live during formal Accept, including Accept(V0).
		if t.initial && now.Sub(t.preLast) >= n.cfg.W() {
			for _, m := range t.preRequests {
				for p := range n.cfg.Members {
					if !t.firstSeen[p] {
						copy := m
						copy.To = p
						actions = append(actions, copy)
					}
				}
			}
			t.preLast = now
		}
		if !t.initial && t.branch == "validate" && t.upper != nil && t.selected == nil {
			helpDue := now.Sub(t.helpAt) >= n.cfg.W()
			for id := range t.unresolved {
				y, ok := known[id]
				if !ok {
					continue
				}
				x := r.desc.ID
				if id == x || !Conflict(r.desc.Initial.Command, y.desc.Initial.Command) || Covers(y.desc.Initial, x, r.desc.Initial.Command, id) {
					delete(t.unresolved, id)
					continue
				}
				if y.decided != nil {
					if Covers(*y.decided, x, r.desc.Initial.Command, id) {
						delete(t.unresolved, id)
					} else {
						r.noFast = true
						r.forced[id] = true
					}
					continue
				}
				if helpDue {
					actions = append(actions, Message{To: omega, Kind: "Help", ID: id, Other: x, Ballot: t.ballot, Attempt: t.id, Strong: t.strong, Requester: n.cfg.ID}, Message{To: -1, Kind: "NeedRecover", ID: id})
				}
			}
			if helpDue {
				t.helpAt = now
			}
			if r.noFast {
				n.startBranch(r, t, "rebuild", "Observe")
			} else if len(t.unresolved) == 0 {
				n.runAcceptLocked(r, t, r.desc.Initial)
			}
		}
		// NoFast may arrive through HELP while validation is still collecting scans.
		if !t.initial && t.branch == "validate" && r.noFast && t.selected == nil {
			n.startBranch(r, t, "rebuild", "Observe")
		}
	}
	r.mu.Unlock()
	for _, m := range actions {
		m = n.attach(m)
		if m.To < 0 {
			n.broadcast(m)
		} else {
			n.send(m)
		}
	}
	if decision != nil {
		n.commit(r, *decision, t)
	}
}
func (n *Node) handleHelp(r *record, m Message) {
	x := n.get(m.Other)
	if x == nil {
		return
	}
	xd := x.desc
	yd := r.desc
	omega := n.Omega()
	reply := Message{}
	forward := false
	if m.Requester < 0 || m.Requester >= len(n.cfg.Members) {
		return
	}
	r.mu.Lock()
	if r.decided != nil {
		reply = Message{To: m.Requester, Kind: "Done", ID: yd.ID, Other: xd.ID, Value: r.decided, Ballot: m.Ballot, Attempt: m.Attempt}
	} else if Covers(yd.Initial, xd.ID, xd.Initial.Command, yd.ID) { // Initial data already travels with this reply; it is not Done.
		reply = Message{To: m.Requester, Kind: "FetchReply", ID: yd.ID, Other: xd.ID}
	} else if Conflict(xd.Initial.Command, yd.Initial.Command) && !Covers(xd.Initial, yd.ID, yd.Initial.Command, xd.ID) {
		if r.task != nil && r.task.strong && !r.noFast && r.task.branch == "validate" {
			reply = Message{To: m.Requester, Kind: "Strong", ID: xd.ID, Other: yd.ID, Ballot: m.Ballot, Attempt: m.Attempt, Strong: true}
		} else if m.Strong {
			r.noFast = true
			r.pending = true
			key := fmt.Sprintf("%d/%s", m.Requester, m.Other)
			old, exists := r.helps[key]
			if !exists || old.Ballot.Less(m.Ballot) || old.Ballot == m.Ballot && old.Attempt <= m.Attempt {
				r.helps[key] = m
			}
			if r.task == nil || r.task.selected == nil {
				r.forced[xd.ID] = true
			}
			forward = omega != n.cfg.ID
		}
	}
	r.mu.Unlock()
	if reply.Kind != "" {
		n.send(n.attach(reply))
	}
	if forward {
		m.To = omega
		n.send(n.attach(m))
	}
}
