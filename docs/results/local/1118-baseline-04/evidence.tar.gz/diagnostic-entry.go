package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"runtime"
	"runtime/trace"
	"syscall"
	"time"

	"example.com/mixepaxos/consensus"
	"example.com/mixepaxos/tcp"
)

func main() {
	id := flag.Int("id", 1, "member ID")
	path := flag.String("config", "config/cluster.json", "cluster configuration")
	workers := flag.Int("workers", 0, "protocol workers (0 uses configuration)")
	procs := flag.Int("procs", 0, "GOMAXPROCS (0 uses runtime default)")
	tracePath := flag.String("trace", "", "write a Go runtime trace")
	flag.Parse()
	if err := run(*id, *path, *workers, *procs, *tracePath); err != nil {
		log.Fatal(err)
	}
}

func run(id int, path string, workers, procs int, tracePath string) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	var cfg consensus.Config
	dec := json.NewDecoder(f)
	dec.DisallowUnknownFields()
	err = dec.Decode(&cfg)
	f.Close()
	if err != nil {
		return err
	}
	if workers != 0 {
		cfg.Workers = workers
	}
	cfg, err = cfg.Normalized()
	if err != nil {
		return err
	}
	if procs < 0 {
		return errors.New("procs must be nonnegative")
	}
	if procs > 0 {
		runtime.GOMAXPROCS(procs)
	}
	if id < 1 || id > len(cfg.Members) {
		return errors.New("invalid member ID")
	}
	if tracePath != "" {
		tf, err := os.Create(tracePath)
		if err != nil {
			return err
		}
		defer tf.Close()
		if err := trace.Start(tf); err != nil {
			return err
		}
		defer trace.Stop()
	}
	w, err := tcp.New(cfg, id, os.Getenv("MIXEPAXOS_CLUSTER_KEY"))
	if err != nil {
		return err
	}
	defer w.Close()
	ln, err := net.Listen("tcp", cfg.Members[id-1].Address)
	if err != nil {
		return err
	}
	defer ln.Close()
	n, err := consensus.New(cfg, id, w, consensus.Options{Report: func(err error) { log.Printf("protocol invariant: %v", err) }})
	if err != nil {
		return err
	}
	defer n.Close()
	mux := http.NewServeMux()
	mux.Handle("/replica", w.Handler(n))
	mux.Handle("/request", requestHandler(n, min(512, cfg.Queue)))
	mux.HandleFunc("GET /stats", func(wr http.ResponseWriter, _ *http.Request) {
		wr.Header().Set("Content-Type", "application/json")
		var m runtime.MemStats
		runtime.ReadMemStats(&m)
		_ = json.NewEncoder(wr).Encode(struct {
			Node                       consensus.Stats
			TCP                        tcp.Stats
			HeapBytes                  uint64
			Goroutines, Workers, Procs int
		}{n.Stats(), w.Stats(), m.HeapAlloc, runtime.NumGoroutine(), cfg.Workers, runtime.GOMAXPROCS(0)})
	})
	server := &http.Server{Handler: mux, ReadHeaderTimeout: 3 * time.Second, ReadTimeout: 6 * time.Second, IdleTimeout: 45 * time.Second, MaxHeaderBytes: 8 << 10}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	result := make(chan error, 1)
	go func() { result <- server.Serve(ln) }()
	log.Printf("member %d listening on %s with workers=%d GOMAXPROCS=%d", id, ln.Addr(), cfg.Workers, runtime.GOMAXPROCS(0))
	select {
	case <-ctx.Done():
		n.Close()
		deadline, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()
		if err := server.Shutdown(deadline); err != nil {
			return server.Close()
		}
		return nil
	case err := <-result:
		if errors.Is(err, http.ErrServerClosed) {
			return nil
		}
		return err
	}
}

func requestHandler(n *consensus.Node, limit int) http.Handler {
	slots := make(chan struct{}, limit)
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		reply := func(rep consensus.Reply) {
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(rep)
		}
		select {
		case slots <- struct{}{}:
			defer func() { <-slots }()
		default:
			reply(consensus.Reply{Status: consensus.Rejected, Reason: "entry_busy"})
			return
		}
		var c consensus.Command
		d := json.NewDecoder(http.MaxBytesReader(w, r.Body, 512<<10))
		d.DisallowUnknownFields()
		if err := d.Decode(&c); err != nil || d.Decode(new(any)) != io.EOF {
			reply(consensus.Reply{Status: consensus.Rejected, Reason: "malformed_json"})
			return
		}
		wait := 5 * time.Second
		if v := r.Header.Get("X-Wait"); v != "" {
			t, err := time.ParseDuration(v)
			if err != nil || t <= 0 || t > time.Minute {
				reply(consensus.Reply{Status: consensus.Rejected, Reason: "invalid_wait"})
				return
			}
			wait = t
		}
		ctx, cancel := context.WithTimeout(r.Context(), wait)
		defer cancel()
		reply(n.Submit(ctx, c))
	})
}
