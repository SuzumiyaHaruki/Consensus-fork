import csv,json,collections,statistics,math
from pathlib import Path
root=Path(__file__).resolve().parent
def table(path,rows):
    if rows:
        with path.open('w') as f:
            w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
def summarize(folder):
    rows=[]; trend=[]
    for f in sorted((root/folder).glob('*/after.json')):
        p=f.parent
        load=json.loads((p/'load.json').read_text()); start,end=load['start_ns'],load['end_ns']
        before=json.loads((p/'before.json').read_text());after=json.loads(f.read_text())
        def diff(member,k):
            return sum(y[member][k]-x[member][k] for x,y in zip(before,after))
        dt=(end-start)/1e9; counts=collections.Counter();sent=0;pending=0;bins=[0]*6;lat=[]
        with (p/'requests.csv').open() as stream:
            for r in csv.DictReader(stream):
                t0=int(r['sent_ns']);t=int(r['reply_ns'])
                counts[r['status']]+=1;sent+=bool(t0);pending+=bool(t0 and t0<=end<t)
                if r['status']=='RESULT':
                    lat.append((t-t0)/1e6)
                    if start<=t<=end:bins[min(5,(t-start)*6//(end-start))]+=1
        assert counts==load['counts'] and sent==load['issued'] and sum(bins)==load['window_completed'] and len(lat)==load['completed']
        samples=[json.loads(line) for line in (p/'samples.jsonl').read_text().splitlines() if line.strip()]
        s=[a for a in samples if start<=a['ns']<=end]
        cores=sum(b['cpu']-a['cpu'] for a,b in zip(s[0]['replicas'],s[-1]['replicas']))/((s[-1]['ns']-s[0]['ns'])/1e9)
        adm=diff('Node','Admitted');applied=[y['Node']['Applied']-x['Node']['Applied'] for x,y in zip(before,after)]
        assert adm>0
        lat.sort()
        row=dict(case=p.name,rate=load['target_rate'],issued=sent,not_sent=load['planned']-sent,result=len(lat),rejected=counts['REJECTED'],incomplete=counts['INCOMPLETE'],unknown=counts['UNKNOWN'],transport_error=counts['TRANSPORT_ERROR'],invalid=counts['INVALID_RESULT'],window_tps=round(sum(bins)/dt,1),first5_tps=bins[0]/5,last5_tps=bins[-1]/5,mean_ms=round(statistics.mean(lat),2) if len(lat)==sent else '',p99_ms=round(lat[math.ceil(.99*len(lat))-1],2) if len(lat)==sent else '',waiting_at_input_end=pending,admitted=adm,origin_executed=diff('Node','LocalExecuted'),min_applied_replica=min(applied),max_applied_replica=max(applied),fast=diff('Node','Fast'),slow=diff('Node','Slow'),recoveries=diff('Node','Recoveries'),fetch_sends=diff('Node','Fetches'),window_short=diff('Node','WindowShort'),queue_full=diff('TCP','QueueFull'),frame_errors=diff('TCP','Errors'),body_kB_per_admit=round(diff('TCP','Bytes')/adm/1000,2),frames_per_admit=round(diff('TCP','Frames')/adm,2),core_equiv=round(cores,2),driver_lag_p99_ms=round(load['send_lag_ms']['p99'],2))
        rows.append(row)
        for k,n in enumerate(bins):trend.append(dict(case=p.name,start_s=k*5,end_s=(k+1)*5,executed_replies_per_s=n/5))
    table(root/(folder+'-summary.csv'),rows);table(root/(folder+'-windows.csv'),trend)
if __name__=='__main__':
    for folder in ('jobs','diag-jobs','entry-jobs'):summarize(folder)
