package main

import (
    "bytes"
    "encoding/gob"
    "fmt"
    "example.com/mixepaxos/consensus"
)

func main() {
    vote := consensus.Message{
        Kind: consensus.PreAcceptReply,
        X: consensus.ID{Replica:1,Number:12345},
        Key: "load/000012345",
        Ticket: consensus.Ticket{Kind:consensus.PreAccept,Phase:1},
        Vote: consensus.Vote{Kind:consensus.FastOK},
    }
    fmt.Println("messages,fresh_body_bytes,warmed_body_bytes")
    for _, size := range []int{1,8,24} {
        batch:=make([]consensus.Message,size)
        for i:=range batch { batch[i]=vote; batch[i].X.Number+=uint64(i);batch[i].Key=fmt.Sprintf("load/%09d",12345+i) }
        var buf bytes.Buffer
        enc:=gob.NewEncoder(&buf)
        if err:=enc.Encode(batch); err!=nil{panic(err)}
        first:=buf.Len()
        buf.Reset()
        if err:=enc.Encode(batch); err!=nil{panic(err)}
        fmt.Printf("%d,%d,%d\n",size,first,buf.Len())
    }
}
