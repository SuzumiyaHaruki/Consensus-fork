package main

import (
    "bytes"
    "encoding/gob"
    "fmt"
    "strings"
    c "example.com/mixepaxos/consensus"
)

func main() {
    fmt.Println("messages,fresh_body_bytes,warmed_body_bytes")
    for _, size:=range []int{1,8,24}{
        batch:=make([]c.Message,size)
        for i:=range batch{
            key:=fmt.Sprintf("load/%09d",12345+i)
            v:=&c.Value{Command:c.Command{RID:c.RID{Client:strings.Repeat("cafe1234",8),Seq:uint64(12346+i)},Op:"put",Key:key,Value:strings.Repeat("v",16)},Deps:make([]uint64,7),Seq:1}
            batch[i]=c.Message{Kind:c.Vote,Request:c.PreAccept,X:c.ID{Replica:1,Number:uint64(12345+i)},Key:key,Attempt:1,Phase:1,Nonce:1,First:&c.First{Suggestion:v,Fast:true}}
        }
        var buf bytes.Buffer
        enc:=gob.NewEncoder(&buf)
        if err:=enc.Encode(batch);err!=nil{panic(err)};first:=buf.Len()
        buf.Reset()
        if err:=enc.Encode(batch);err!=nil{panic(err)}
        fmt.Printf("%d,%d,%d\n",size,first,buf.Len())
    }
}
