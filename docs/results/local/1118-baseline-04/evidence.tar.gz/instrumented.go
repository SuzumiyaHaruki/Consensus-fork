// Package tcp binds consensus messages to authenticated cluster members over
// bounded, reusable HTTP/TCP connections.
package tcp

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/gob"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"strconv"
	"sync"
	"sync/atomic"
	"time"

	"example.com/mixepaxos/consensus"
)

const maxFrame = 4 << 20
const frameMessages = 24

type lane struct {
	addr string
	to   int
	send chan consensus.Message
}
type Transport struct {
	self                        int
	key                         []byte
	lanes                       [][3]*lane
	http                        *http.Client
	ctx                         context.Context
	cancel                      context.CancelFunc
	wg                          sync.WaitGroup
	bytes, frames, errors, posted atomic.Uint64
    queueFullByKind [256]atomic.Uint64
}
type Stats struct{ Bytes, Frames, Errors, QueueFull, Posted uint64; QueueFullByKind [25]uint64 }

func New(c consensus.Config, self int, keyHex string) (*Transport, error) {
	c, err := c.Normalized()
	if err != nil {
		return nil, err
	}
	if self < 1 || self > len(c.Members) {
		return nil, errors.New("invalid replica ID")
	}
	key, err := hex.DecodeString(keyHex)
	if err != nil || len(key) != 32 {
		return nil, errors.New("MIXEPAXOS_CLUSTER_KEY must encode 32 bytes in hex")
	}
	for _, m := range c.Members {
		_, port, err := net.SplitHostPort(m.Address)
		p, e := strconv.Atoi(port)
		if err != nil || e != nil || p < 1 || p > 65535 {
			return nil, fmt.Errorf("invalid TCP address for member %d", m.ID)
		}
	}
	ctx, cancel := context.WithCancel(context.Background())
	d := max(time.Second, 4*c.W)
	tr := &http.Transport{MaxIdleConns: 3 * len(c.Members), MaxIdleConnsPerHost: 3, IdleConnTimeout: 45 * time.Second,
		DialContext: (&net.Dialer{Timeout: min(d, 2*time.Second), KeepAlive: 30 * time.Second}).DialContext}
	t := &Transport{self: self, key: key, ctx: ctx, cancel: cancel, http: &http.Client{Timeout: d, Transport: tr},
		lanes: make([][3]*lane, len(c.Members)+1)}
	for _, m := range c.Members {
		if m.ID == self {
			continue
		}
		for k := range t.lanes[m.ID] {
			l := &lane{addr: "http://" + m.Address + "/replica", to: m.ID, send: make(chan consensus.Message, c.Queue)}
			t.lanes[m.ID][k] = l
			t.wg.Add(1)
			go func() { defer t.wg.Done(); t.run(l) }()
		}
	}
	return t, nil
}
func (t *Transport) Close() { t.cancel(); t.wg.Wait(); t.http.CloseIdleConnections() }
func (t *Transport) Stats() Stats {
	s := Stats{Bytes:t.bytes.Load(), Frames:t.frames.Load(), Errors:t.errors.Load(), Posted:t.posted.Load()}
    for k:=range s.QueueFullByKind { s.QueueFullByKind[k]=t.queueFullByKind[k].Load(); s.QueueFull+=s.QueueFullByKind[k] }
    return s
}
func (t *Transport) Send(to int, m consensus.Message) bool {
	if to < 1 || to >= len(t.lanes) || to == t.self || t.ctx.Err() != nil {
		return false
	}
	k := 0
	switch m.Kind {
	case consensus.Fetch, consensus.Data, consensus.NeedRecover:
		k = 1
	case consensus.Heartbeat, consensus.HeartbeatACK, consensus.Complaint, consensus.Bad, consensus.Gossip, consensus.GossipACK:
		k = 2
	}
	select {
	case t.lanes[to][k].send <- m:
		return true
	default:
		t.queueFullByKind[m.Kind].Add(1)
		return false
	}
}
func (t *Transport) mac(from, to int, body []byte) []byte {
	m := hmac.New(sha256.New, t.key)
	fmt.Fprintf(m, "mixepaxos/v1\n%d\n%d\n", from, to)
	m.Write(body)
	return m.Sum(nil)
}
func (t *Transport) run(l *lane) {
	batch := make([]consensus.Message, 0, frameMessages)
	for t.ctx.Err() == nil {
		select {
		case <-t.ctx.Done():
			return
		case m := <-l.send:
			batch = append(batch, m)
		}
	drain:
		for len(batch) < cap(batch) {
			select {
			case m := <-l.send:
				batch = append(batch, m)
			default:
				break drain
			}
		}
		if !t.post(l, batch) {
			t.errors.Add(1)
		}
		clear(batch)
		batch = batch[:0]
	}
}
func (t *Transport) post(l *lane, batch []consensus.Message) bool {
	var body bytes.Buffer
	if err := gob.NewEncoder(&body).Encode(batch); err != nil || body.Len() > maxFrame {
		return false
	}
	req, err := http.NewRequestWithContext(t.ctx, http.MethodPost, l.addr, &body)
	if err != nil {
		return false
	}
	req.Header.Set("X-Mixed-Sender", strconv.Itoa(t.self))
	req.Header.Set("X-Mixed-MAC", hex.EncodeToString(t.mac(t.self, l.to, body.Bytes())))
	t.bytes.Add(uint64(body.Len()))
	t.frames.Add(1)
 t.posted.Add(uint64(len(batch)))
	res, err := t.http.Do(req)
	if err != nil {
		return false
	}
	_, err = io.Copy(io.Discard, res.Body)
	res.Body.Close()
	return err == nil && res.StatusCode == http.StatusAccepted
}

// Handler authenticates the endpoints and exact encoded payload before decoding.
// Members share the secret and are trusted to act as their configured identity.
func (t *Transport) Handler(n *consensus.Node) http.Handler {
	slots := make(chan struct{}, 3*len(t.lanes)+8)
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		select {
		case slots <- struct{}{}:
			defer func() { <-slots }()
		default:
			w.WriteHeader(http.StatusServiceUnavailable)
			return
		}
		from, e := strconv.Atoi(r.Header.Get("X-Mixed-Sender"))
		proof, err := hex.DecodeString(r.Header.Get("X-Mixed-MAC"))
		if e != nil || err != nil || len(proof) != sha256.Size || from < 1 || from >= len(t.lanes) || from == t.self {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		b, err := io.ReadAll(http.MaxBytesReader(w, r.Body, maxFrame))
		if err != nil || !hmac.Equal(t.mac(from, t.self, b), proof) {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		var batch []consensus.Message
		if err := gob.NewDecoder(bytes.NewReader(b)).Decode(&batch); err != nil || len(batch) == 0 || len(batch) > frameMessages {
			w.WriteHeader(http.StatusBadRequest)
			return
		}
		ok := true
		for _, m := range batch {
			if !n.Receive(from, m) {
				ok = false
			}
		}
		if !ok {
			w.WriteHeader(http.StatusServiceUnavailable)
			return
		}
		w.WriteHeader(http.StatusAccepted)
	})
}
