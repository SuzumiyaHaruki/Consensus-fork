// Package consensus implements the crash-stop Mixed EPaxos replica.
package consensus

import (
	"encoding/hex"
	"fmt"
	"math"
	"time"
	"unicode/utf8"
)

type ID struct {
	Replica int
	Number  uint64
}

type RID struct {
	Client string `json:"client"`
	Seq    uint64 `json:"seq"`
}

type Command struct {
	RID   RID    `json:"rid"`
	Op    string `json:"op"`
	Key   string `json:"key"`
	Value string `json:"value,omitempty"`
}

func (c Command) Valid() bool {
	id, err := hex.DecodeString(c.RID.Client)
	if err != nil || len(id) != 32 || hex.EncodeToString(id) != c.RID.Client || c.RID.Seq == 0 ||
		len(c.Key) == 0 || len(c.Key) > 1024 || len(c.Value) > 65536 || !utf8.ValidString(c.Key) || !utf8.ValidString(c.Value) {
		return false
	}
	return c.Op == "put" || (c.Op == "get" || c.Op == "delete") && c.Value == ""
}

type Status string

const (
	Applied   Status = "APPLIED"
	Duplicate Status = "ALREADY_EXECUTED"
	Rejected  Status = "REJECTED"
	Pending   Status = "INCOMPLETE"
	Unknown   Status = "UNKNOWN"
)

type Result struct {
	Status Status `json:"status"`
	Found  bool   `json:"found,omitempty"`
	Value  string `json:"value,omitempty"`
	Error  string `json:"error,omitempty"`
}

type Value struct {
	Command Command
	Deps    []uint64
	Seq     uint64
}

func Equal(a, b *Value) bool {
	if a == nil || b == nil {
		return a == b
	}
	if a.Command != b.Command || a.Seq != b.Seq || len(a.Deps) != len(b.Deps) {
		return false
	}
	for i := range a.Deps {
		if a.Deps[i] != b.Deps[i] {
			return false
		}
	}
	return true
}

type Ballot struct {
	Round uint64
	Owner int
}

func (b Ballot) less(other Ballot) bool {
	return b.Round < other.Round || b.Round == other.Round && b.Owner < other.Owner
}

type Kind uint8

const (
	PreAccept Kind = iota + 1
	Prepare
	Observe
	Validate
	Accept
	Vote
	Nack
	Learn
	Done
	Initial
	Stored
	Fetch
	NeedRecover
	Help
	HelpStrong
	HelpInitial
	Heartbeat
	Complaint
	Bad
	NoticeAck
)

type First struct {
	Suggestion *Value
	Fast       bool
}

type Accepted struct {
	Ballot Ballot
	Value  *Value
}

// Message is immutable after handoff. From identifies the authenticated transport
// peer separately when delivered to Node, and is never read from Message.
type Message struct {
	AllStored bool      `json:",omitzero"`
	Kind      Kind      `json:",omitzero"`
	Request   Kind      `json:",omitzero"`
	X         ID        `json:",omitzero"`
	Key       string    `json:",omitzero"`
	Ballot    Ballot    `json:",omitzero"`
	Attempt   uint64    `json:",omitzero"`
	Phase     uint8     `json:",omitzero"`
	Nonce     uint64    `json:",omitzero"`
	Init      *Value    `json:",omitzero"`
	Value     *Value    `json:",omitzero"`
	First     *First    `json:",omitzero"`
	Record    *Accepted `json:",omitzero"`
	Higher    Ballot    `json:",omitzero"`

	Other   ID   `json:",omitzero"`
	Strong  bool `json:",omitzero"`
	Origin  int  `json:",omitzero"`
	HasDone bool `json:",omitzero"`

	Notice    uint64 `json:",omitzero"`
	Number    uint64 `json:",omitzero"`
	Subject   int    `json:",omitzero"`
	Witnesses []int  `json:",omitzero"`
}

// Transport attempts a nonblocking handoff. A false return indicates backpressure.
// Implementations may drop or reorder messages. Protocol retries repair loss when
// communication and scheduling are fair. Do not synchronously reenter Node state.
type Transport interface {
	Send(to int, m Message) bool
}

type Ticker interface {
	C() <-chan time.Time
	Stop()
}

type Clock interface {
	Now() time.Time
	NewTicker(time.Duration) Ticker
}

type realClock struct{}
type realTicker struct{ *time.Ticker }

func (realClock) Now() time.Time                   { return time.Now() }
func (realClock) NewTicker(d time.Duration) Ticker { return realTicker{time.NewTicker(d)} }
func (t realTicker) C() <-chan time.Time           { return t.Ticker.C }

type Config struct {
	Members int
	Self    int
	F       int
	S       int
	E       int
	Window  time.Duration

	Workers       int
	Queue         int
	MaxInflight   int
	MaxWaiters    int
	Retry         time.Duration
	RecoveryDelay time.Duration
	Overdue       time.Duration
	Heartbeat     time.Duration
	Tick          time.Duration
	Wait          time.Duration
	Clock         Clock
	// Trace may run concurrently and must return promptly. It is intended for
	// controlled tests and short diagnostic captures.
	Trace func(Event)
}

type Event struct {
	At     time.Time
	Stage  string
	Worker int
	X      ID
	Kind   Kind
}

func (c *Config) defaults() error {
	q := c.Members - c.F
	if c.Members <= 0 || c.Self < 0 || c.Self >= c.Members || c.F < 0 || c.F >= c.Members ||
		c.S < 0 || c.S >= q || q > c.F+1 || c.E < 0 || c.E > (q-1)/2 || c.Window <= 0 {
		return fmt.Errorf("invalid membership or protocol parameters")
	}
	if c.Workers <= 0 {
		c.Workers = 2
	}
	if c.Queue <= 0 {
		c.Queue = 1024
	}
	if c.MaxInflight <= 0 {
		c.MaxInflight = 256
	}
	if c.MaxWaiters <= 0 {
		c.MaxWaiters = 1024
	}
	if c.Retry <= 0 {
		c.Retry = c.Window
	}
	if c.RecoveryDelay <= 0 {
		c.RecoveryDelay = scaled(c.Window, 6)
	}
	if c.Overdue <= 0 {
		c.Overdue = scaled(c.Window, 8)
	}
	if c.Heartbeat <= 0 {
		c.Heartbeat = max(c.Window/2, time.Millisecond)
	}
	if c.Tick <= 0 {
		c.Tick = min(c.Window/10, 5*time.Millisecond)
		c.Tick = max(c.Tick, time.Microsecond)
	}
	if c.Wait <= 0 {
		c.Wait = 3 * time.Second
	}
	if c.Clock == nil {
		c.Clock = realClock{}
	}
	return nil
}

func scaled(d time.Duration, multiply int64) time.Duration {
	if int64(d) > math.MaxInt64/multiply {
		return time.Duration(math.MaxInt64)
	}
	return d * time.Duration(multiply)
}
