package consensus

import (
	"context"
	"runtime/trace"
	"time"
)

type collection struct {
	kind          Kind
	req           Message
	deadline      time.Time
	windowChecked bool
	a, b          map[int]Message
}

type initialRound struct {
	requests  [2]Message
	seen      [2][]bool
	deadline  time.Time
	slowReady bool
	replies   []Message
}

type task struct {
	ballot     Ballot
	leader     *leader
	collect    *collection
	pre        *initialRound
	fast       map[int]bool
	mismatch   map[int]bool
	frozen     *Value
	validation *validation
}

func (w *worker) current(x *instance) *task {
	t := x.task
	if t != nil && (x.decided != nil || t.ballot.less(x.promise) ||
		t.leader != nil && t.leader != w.omega.Load()) {
		w.stopTask(x)
		return nil
	}
	return t
}

func (w *worker) stopTask(x *instance) {
	if x.task != nil && x.task.validation != nil {
		w.clearValidation(x, x.task.validation)
	}
	x.task = nil
	w.pruneVotes(x)
	if x.decided == nil {
		x.pendingRecovery = true
	}
}

func (w *worker) raise(x *instance, b Ballot) {
	if x.promise.less(b) {
		x.promise = b
		w.current(x)
	}
}

func (w *worker) start(x *instance, kind Kind, v *Value) {
	t := w.current(x)
	if t == nil {
		return
	}
	x.nonce++
	x.attempt++
	now := w.now()
	req := Message{
		Kind: kind, X: x.id, Key: x.c.key, Ballot: t.ballot, Attempt: x.attempt, Phase: 1,
		Nonce: x.nonce, Init: x.v0, Value: v,
	}
	col := &collection{
		kind: kind, req: req, deadline: now.Add(w.cfg.Window), a: make(map[int]Message), b: make(map[int]Message),
	}
	t.collect = col
	w.pruneVotes(x)
	if kind == PreAccept {
		t.pre = &initialRound{deadline: col.deadline}
	}
	w.issue(x, req)
	w.schedule(x)
}

func (w *worker) issue(x *instance, m Message) {
	if m.Kind == PreAccept {
		i := m.Phase - 1
		x.task.pre.requests[i] = m
		x.task.pre.seen[i] = make([]bool, w.cfg.Members)
	}
	if x.rounds == nil {
		x.rounds = make(map[uint64]Message)
	}
	identity := m
	identity.Init, identity.Value = nil, nil
	x.rounds[m.Nonce] = identity
	w.trace("broadcast", x.id, m.Kind)
	w.broadcast(m)
}

func (w *worker) validBallot(b Ballot) bool {
	return b.Owner >= 0 && b.Owner < w.cfg.Members && (b.Round != 0 || b.Owner == 0)
}

func (w *worker) validRequest(from int, m Message) bool {
	if !w.validBallot(m.Ballot) || m.Attempt == 0 || m.Nonce == 0 || m.Phase < 1 || m.Phase > 2 {
		return false
	}
	if m.Ballot.Round == 0 {
		return from == m.X.Replica && (m.Kind == PreAccept || m.Kind == Accept)
	}
	return from == m.Ballot.Owner && m.Kind != PreAccept
}

func (w *worker) matches(x *instance, m Message) bool {
	req, ok := x.rounds[m.Nonce]
	return ok && req.Kind == m.Request && req.Ballot == m.Ballot && req.Attempt == m.Attempt && req.Phase == m.Phase
}

func response(req Message, kind Kind) Message {
	return Message{Kind: kind, Request: req.Kind, X: req.X, Key: req.Key,
		Ballot: req.Ballot, Attempt: req.Attempt, Phase: req.Phase, Nonce: req.Nonce}
}

func (w *worker) handle(in incoming) {
	m := in.msg
	ordinary := m.Kind == PreAccept || m.Kind == Vote && (m.Request == PreAccept || m.Request == Accept) || m.Kind == Accept
	if ordinary {
		w.count.tasks.Add(1)
		incrementPeak(&w.count.overlap, w.Node.active.Add(1))
		defer w.Node.active.Add(^uint64(0))
	}
	if trace.IsEnabled() {
		defer trace.StartRegion(context.Background(), kindName(m)).End()
	}
	w.trace("handle", m.X, m.Kind)
	switch m.Kind {
	case PreAccept, Prepare, Observe, Validate, Accept:
		if !w.validRequest(in.from, m) {
			w.count.invalid.Add(1)
			return
		}
	}
	if m.Init != nil && !w.validInitial(m.X, m.Key, m.Init) {
		w.count.invalid.Add(1)
		return
	}
	if key, ok := w.Node.ids.Load(m.X); ok && key != m.Key {
		w.count.invalid.Add(1)
		return
	}
	c := w.classes[m.Key]
	if c == nil && (m.Kind == Vote || m.Kind == Nack || m.Kind == Stored || m.Kind == HelpStrong || m.Kind == HelpInitial || m.Kind == Fetch) {
		return
	}
	if c == nil {
		c = w.class(m.Key)
	}
	x := c.records[m.X]
	if x == nil && (m.Kind == Vote || m.Kind == Nack || m.Kind == Stored || m.Kind == HelpStrong || m.Kind == HelpInitial || m.Kind == Fetch) {
		return
	}
	if x == nil {
		x = w.instance(c, m.X)
	}
	if m.Init != nil && !w.saveInitial(x, m.Init) {
		return
	}
	w.current(x)
	switch m.Kind {
	case PreAccept, Prepare, Observe, Validate, Accept:
		w.request(in, x)
	case Vote:
		w.vote(in, x)
	case Nack:
		if w.matches(x, m) && w.validBallot(m.Higher) && m.Ballot.less(m.Higher) {
			w.raise(x, m.Higher)
			w.kick(x)
		}
	case Initial:
		if x.registered {
			w.stored(in.from, x)
		}
	case Learn, Done:
		w.receiveDecision(in.from, x, m.Value)
	case Stored:
		if x.registered {
			x.hasInitial[in.from] = true
		}
		if x.decided != nil && m.HasDone {
			x.hasDecision[in.from] = true
			if m.AllStored && in.from == x.id.Replica {
				for p := range x.hasDecision {
					x.hasInitial[p] = true
					x.hasDecision[p] = true
				}
			}
			if w.cfg.Self == x.id.Replica && !x.notifiedAll && all(x.hasDecision) {
				x.notifiedAll = true
				for p := 0; p < w.cfg.Members; p++ {
					if p != w.cfg.Self {
						w.send(p, Message{Kind: Stored, X: x.id, Key: x.c.key, HasDone: true, AllStored: true})
					}
				}
			}
		}
	case Fetch:
		w.serveData(in.from, x)
	case NeedRecover:
		if x.decided != nil {
			w.send(in.from, w.decisionMessage(x, Done))
		} else {
			x.pendingRecovery = true
			w.fetch(x)
			w.kick(x)
		}
	case Help:
		w.receiveHelp(in, x)
	case HelpStrong, HelpInitial:
		w.helpReply(in, x)
	}
	w.schedule(x)
}

func kindName(m Message) string {
	switch m.Kind {
	case PreAccept:
		return "consensus.PreAccept"
	case Accept:
		return "consensus.Accept"
	case Vote:
		switch m.Request {
		case PreAccept:
			return "consensus.PreAcceptReply"
		case Accept:
			return "consensus.AcceptACK"
		default:
			return "consensus.RecoveryReply"
		}
	case Prepare:
		return "consensus.Prepare"
	case Observe:
		return "consensus.Observe"
	case Validate:
		return "consensus.Validate"
	default:
		return "consensus.BackgroundMessage"
	}
}

func (w *worker) request(in incoming, x *instance) {
	from, m := in.from, in.msg
	if m.Kind == Accept {
		missing, ok := w.missing(x, m.Value)
		if !ok {
			return
		}
		if len(missing) != 0 {
			w.deferMessage(in, x, missing)
			return
		}
	} else if !x.registered {
		if m.Kind == PreAccept {
			x.prePending[m.Phase-1] = &in
		} else {
			w.deferMessage(in, x, []*instance{x})
		}
		w.fetch(x)
		return
	} else if !Equal(x.v0, m.Value) {
		w.count.invalid.Add(1)
		return
	}
	if x.decided != nil {
		r := response(m, Done)
		r.Init, r.Value = x.v0, x.decided
		w.send(from, r)
		return
	}
	if m.Ballot.less(x.promise) {
		r := response(m, Nack)
		r.Higher = x.promise
		w.send(from, r)
		return
	}
	r := response(m, Vote)
	switch m.Kind {
	case PreAccept:
		if x.first == nil {
			v := join(x.c.scan(x.v0.Command, x), x.v0)
			x.first = &First{Suggestion: v, Fast: Equal(v, x.v0)}
		}
		r.First = x.first
	case Prepare:
		w.raise(x, m.Ballot)
		r.First, r.Record = x.first, x.accepted
	case Observe, Validate:
		w.raise(x, m.Ballot)
		r.Value = join(x.c.scan(x.v0.Command, x), x.v0)
	case Accept:
		if x.accepted != nil && x.accepted.Ballot == m.Ballot && !Equal(x.accepted.Value, m.Value) {
			w.count.invalid.Add(1)
			return
		}
		w.raise(x, m.Ballot)
		x.accepted = &Accepted{m.Ballot, m.Value}
		r.Value = m.Value
	}
	w.send(from, r)
}

func join(a, b *Value) *Value {
	a.Seq = max(a.Seq, b.Seq)
	for i, d := range b.Deps {
		a.Deps[i] = max(a.Deps[i], d)
	}
	return a
}

func copyValue(v *Value) *Value {
	c := *v
	c.Deps = append([]uint64(nil), v.Deps...)
	return &c
}

func (w *worker) vote(in incoming, x *instance) {
	from, m := in.from, in.msg
	t := w.current(x)
	if t == nil || !w.matches(x, m) || m.Ballot != t.ballot {
		return
	}
	col := t.collect
	inCollect := col != nil && col.req.Nonce == m.Nonce
	if !inCollect && m.Request != PreAccept {
		return
	}
	var refs []*instance
	var ok bool
	switch m.Request {
	case PreAccept, Prepare:
		if m.Request == PreAccept && m.First == nil {
			return
		}
		if m.First != nil {
			if m.First.Fast != Equal(x.v0, m.First.Suggestion) {
				return
			}
			refs, ok = w.missing(x, m.First.Suggestion)
			if !ok {
				return
			}
		}
		if m.Record != nil {
			if m.Request != Prepare || !w.validBallot(m.Record.Ballot) || m.Ballot.less(m.Record.Ballot) {
				return
			}
			missing, ok := w.missing(x, m.Record.Value)
			if !ok {
				return
			}
			refs = append(refs, missing...)
		}
	case Accept:
		if !Equal(t.frozen, m.Value) {
			return
		}
	case Observe, Validate:
		refs, ok = w.missing(x, m.Value)
		if !ok {
			return
		}
	}
	if len(refs) != 0 {
		w.deferMessage(in, x, refs)
		return
	}
	x.hasInitial[from] = true
	if m.Request == PreAccept {
		t.pre.seen[m.Phase-1][from] = true
		if m.First.Fast {
			t.fast[from] = true
		} else {
			if t.mismatch == nil {
				t.mismatch = make(map[int]bool)
			}
			t.mismatch[from] = true
			if len(t.mismatch) > w.cfg.E {
				x.noFast = true
			}
		}
		if w.maybeFast(x) {
			return
		}
	}
	if inCollect {
		if m.Phase == 1 {
			if _, ok := col.a[from]; !ok {
				col.a[from] = m
			}
		} else if _, ok := col.b[from]; !ok {
			col.b[from] = m
		}
		w.advanceCollect(x)
	}
}

func (w *worker) maybeFast(x *instance) bool {
	t := w.current(x)
	if t != nil && t.ballot.Round == 0 && len(t.mismatch) == 0 && !x.noFast &&
		len(t.fast) >= w.cfg.Members-w.cfg.E {
		w.decide(x, x.v0, true)
		return true
	}
	return false
}

func (w *worker) advanceCollect(x *instance) {
	t := w.current(x)
	if t == nil || t.collect == nil {
		return
	}
	c := t.collect
	q, l := w.cfg.Members-w.cfg.F, w.cfg.F+1
	members := len(c.a)
	for p := range c.b {
		if _, ok := c.a[p]; !ok {
			members++
		}
	}
	if c.req.Phase == 1 && len(c.a) >= l ||
		c.req.Phase == 2 && (len(c.b) >= q || members >= l) {
		t.collect = nil
		w.pruneVotes(x)
		w.trace("collect", x.id, c.kind)
		replies := make([]Message, 0, len(c.a)+len(c.b))
		for _, reply := range c.a {
			replies = append(replies, reply)
		}
		for _, reply := range c.b {
			replies = append(replies, reply)
		}
		w.collected(x, c.kind, replies, members, c)
		return
	}
	if c.req.Phase == 1 && len(c.a) >= q && !w.now().Before(c.deadline) {
		c.windowChecked = true
		x.nonce++
		c.req.Nonce, c.req.Phase = x.nonce, 2
		w.pruneVotes(x)
		w.issue(x, c.req)
	}
}

func (w *worker) collected(x *instance, kind Kind, replies []Message, members int, c *collection) {
	t := w.current(x)
	if t == nil {
		return
	}
	switch kind {
	case PreAccept:
		t.pre.replies = replies
		w.slow(x)
	case Accept:
		w.decide(x, t.frozen, false)
	case Prepare:
		var best *Accepted
		votes := make(map[int]bool)
		mismatches := make(map[int]bool)
		for _, phase := range []map[int]Message{c.a, c.b} {
			for p, m := range phase {
				if m.Record != nil && (best == nil || best.Ballot.less(m.Record.Ballot)) {
					best = m.Record
				}
				if m.First != nil {
					if m.First.Fast {
						votes[p] = true
					} else {
						mismatches[p] = true
					}
				}
			}
		}
		if len(mismatches) > w.cfg.E {
			x.noFast = true
		}
		if best != nil {
			w.freeze(x, best.Value)
		} else if x.noFast || members-len(votes) > w.cfg.E {
			x.noFast = true
			w.rebuild(x)
		} else {
			x.strong = true
			t.validation = &validation{}
			w.start(x, Validate, x.v0)
			t.validation.attempt = x.attempt
		}
	case Observe, Validate:
		v := copyValue(x.v0)
		for _, m := range replies {
			join(v, m.Value)
		}
		if kind == Observe {
			if x.forced != nil {
				join(v, x.forced)
			}
			w.freeze(x, v)
		} else {
			t.validation.cursor = v.Deps
			w.progressValidation(x)
		}
	}
}

func (w *worker) slow(x *instance) {
	t := w.current(x)
	if t == nil || t.pre == nil || t.frozen != nil || t.pre.replies == nil || w.now().Before(t.pre.deadline) {
		return
	}
	t.pre.slowReady = true
	v := copyValue(x.v0)
	for _, r := range t.pre.replies {
		join(v, r.First.Suggestion)
	}
	t.pre.replies = nil
	w.freeze(x, v)
}

func (w *worker) freeze(x *instance, v *Value) {
	t := w.current(x)
	if t == nil || t.frozen != nil {
		return
	}
	if t.validation != nil {
		w.clearValidation(x, t.validation)
		t.validation = nil
	}
	t.frozen = v
	w.start(x, Accept, v)
}

func (w *worker) retryCoordination(x *instance) {
	t := w.current(x)
	if t == nil {
		return
	}
	if c := t.collect; c != nil {
		seen := c.a
		if c.req.Phase == 2 {
			seen = c.b
		}
		for p := 0; p < w.cfg.Members; p++ {
			if _, ok := seen[p]; !ok {
				w.send(p, c.req)
			}
		}
	}
	if t.pre != nil {
		for i, req := range t.pre.requests {
			if req.Nonce == 0 || t.collect != nil && t.collect.req.Nonce == req.Nonce {
				continue
			}
			for p, seen := range t.pre.seen[i] {
				if !seen {
					w.send(p, req)
				}
			}
		}
	}
	if t.validation != nil {
		for y := range t.validation.unresolved {
			w.askHelp(x, y, t)
		}
	}
	w.progressValidation(x)
}
