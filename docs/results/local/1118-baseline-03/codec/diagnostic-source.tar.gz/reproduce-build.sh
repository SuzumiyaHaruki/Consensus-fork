#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
python3 - <<'PY'
from pathlib import Path
import json
root = Path.cwd()
files = (root / 'notice-src').glob('*.go')
overlay = {str(root / 'study/consensus' / file.name): str(file) for file in files}
(root / 'notice-overlay.json').write_text(json.dumps({'Replace': overlay}, indent=2))
PY
cd study
go test -count=1 ./...
go test -c -o ../bench-extra ./transport
go build -o ../server ./cmd/mixserver
cp ../server ../server-extra
go build -overlay=../notice-overlay.json -o ../server-notice ./cmd/mixserver
go build -o ../ctl ./cmd/mixctl
go build -o ../load ../load.go
