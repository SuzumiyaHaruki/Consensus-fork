package tests

import (
	"context"
	"runtime"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"example.com/mixepaxos/client"
	c "example.com/mixepaxos/consensus"
)

type packet struct {
	from, to int
	m        c.Message
}

type sender func(int, c.Message) bool

func (f sender) Send(to int, m c.Message) bool { return f(to, m) }

type manualTicker struct{ ch chan time.Time }

func (t manualTicker) C() <-chan time.Time { return t.ch }
func (t manualTicker) Stop()               {}

type manualClock struct {
	mu    sync.Mutex
	now   time.Time
	ticks []manualTicker
}

func (m *manualClock) Now() time.Time {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.now
}

func (m *manualClock) NewTicker(time.Duration) c.Ticker {
	m.mu.Lock()
	defer m.mu.Unlock()
	t := manualTicker{make(chan time.Time, 1)}
	m.ticks = append(m.ticks, t)
	return t
}

func (m *manualClock) advance(d time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.now = m.now.Add(d)
	for _, t := range m.ticks {
		select {
		case t.ch <- m.now:
		default:
		}
	}
}

type mesh struct {
	nodes   []*c.Node
	mu      sync.Mutex
	pending []packet
}

func newMesh(t *testing.T, n int, ids []int, cfg c.Config, controlled bool) *mesh {
	t.Helper()
	m := &mesh{nodes: make([]*c.Node, n)}
	// Publish the node slice before allowing a direct sender to read it.
	m.mu.Lock()
	defer m.mu.Unlock()
	t.Cleanup(func() {
		for _, node := range m.nodes {
			if node != nil {
				node.Close()
			}
		}
	})
	for _, id := range ids {
		cfg.Self, cfg.Members = id, n
		node, err := c.New(cfg, sender(func(to int, v c.Message) bool {
			m.mu.Lock()
			defer m.mu.Unlock()
			if controlled {
				m.pending = append(m.pending, packet{id, to, v})
				return true
			}
			return m.nodes[to] != nil && m.nodes[to].Deliver(id, v)
		}))
		if err != nil {
			t.Fatal(err)
		}
		m.nodes[id] = node
	}
	return m
}

func (m *mesh) pump(filter func(packet) bool) {
	m.mu.Lock()
	msgs := m.pending
	m.pending = nil
	m.mu.Unlock()
	for _, p := range msgs {
		if (filter == nil || filter(p)) && m.nodes[p.to] != nil {
			m.nodes[p.to].Deliver(p.from, p.m)
		}
	}
}

func (m *mesh) deliver(t *testing.T, from, to int, v c.Message) {
	t.Helper()
	if !m.nodes[to].Deliver(from, v) {
		t.Fatalf("message not queued: %+v", v)
	}
}

func until(t *testing.T, description string, f func() bool) {
	t.Helper()
	for end := time.Now().Add(5 * time.Second); time.Now().Before(end); {
		if f() {
			return
		}
		time.Sleep(200 * time.Microsecond)
		runtime.Gosched()
	}
	t.Fatalf("waiting for %s", description)
}

func command(t *testing.T, op, key, value string) c.Command {
	t.Helper()
	s, err := client.NewSession()
	if err != nil {
		t.Fatal(err)
	}
	cmd, err := s.NewCommand(op, key, value)
	if err != nil {
		t.Fatal(err)
	}
	return cmd
}

func submit(n *c.Node, cmd c.Command) <-chan c.Result {
	out := make(chan c.Result, 1)
	go func() { out <- n.Submit(context.Background(), cmd) }()
	return out
}

func await(t *testing.T, out <-chan c.Result) c.Result {
	t.Helper()
	select {
	case r := <-out:
		return r
	case <-time.After(5 * time.Second):
		t.Fatal("no client response")
		return c.Result{}
	}
}

func initial(x c.ID, v *c.Value) c.Message {
	return c.Message{X: x, Key: v.Command.Key, Init: v, Value: v, Kind: c.PreAccept, Attempt: 1, Phase: 1, Nonce: 1}
}

func TestConcurrentSession(t *testing.T) {
	s, err := client.NewSession()
	if err != nil {
		t.Fatal(err)
	}
	var wg sync.WaitGroup
	ids := make(chan c.RID, 128)
	for i := 0; i < cap(ids); i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			cmd, err := s.NewCommand("get", "key", "")
			if err != nil {
				t.Error(err)
				return
			}
			ids <- cmd.RID
		}()
	}
	wg.Wait()
	close(ids)
	seen := make(map[c.RID]bool)
	for id := range ids {
		if seen[id] || id.Seq == 0 || id.Seq > 128 {
			t.Fatalf("bad sequence: %+v", id)
		}
		seen[id] = true
	}
	if len(seen) != 128 {
		t.Fatal(len(seen))
	}
}

func TestServiceSemantics(t *testing.T) {
	m := newMesh(t, 7, []int{0, 1, 2, 3, 4, 5, 6}, c.Config{F: 4, E: 1, Window: 100 * time.Millisecond}, false)
	put := command(t, "put", "k", "v")
	if r := await(t, submit(m.nodes[0], put)); r.Status != c.Applied {
		t.Fatal(r)
	}
	if m.nodes[0].Stats().Fast != 1 {
		t.Fatalf("expected fast path: %+v", m.nodes[0].Stats())
	}
	if r := await(t, submit(m.nodes[0], put)); r.Status != c.Duplicate || r.Found || r.Value != "" {
		t.Fatal(r)
	}
	contradiction := put
	contradiction.Key = "another key"
	if r := await(t, submit(m.nodes[0], contradiction)); r.Status != c.Rejected {
		t.Fatal(r)
	}
	if r := await(t, submit(m.nodes[6], command(t, "get", "k", ""))); r.Status != c.Applied || !r.Found || r.Value != "v" {
		t.Fatal(r)
	}
	if r := await(t, submit(m.nodes[2], command(t, "delete", "k", ""))); r.Status != c.Applied || !r.Found {
		t.Fatal(r)
	}
	if r := await(t, submit(m.nodes[3], command(t, "get", "k", ""))); r.Status != c.Applied || r.Found {
		t.Fatal(r)
	}
}

func TestLateFastVoteDuringAccept(t *testing.T) {
	W := 100 * time.Millisecond
	clock := &manualClock{now: time.Unix(100, 0)}
	var collected atomic.Bool
	m := newMesh(t, 6, []int{0, 1, 2, 3, 4, 5}, c.Config{
		F: 3, S: 2, E: 1, Window: W, Clock: clock, Workers: 1, Trace: func(e c.Event) {
			if e.Stage == "collect" && e.Kind == c.PreAccept {
				collected.Store(true)
			}
		},
	}, true)
	out := submit(m.nodes[0], command(t, "put", "late", "fast"))
	t.Cleanup(func() {
		if t.Failed() {
			t.Logf("late vote node stats: %+v", m.nodes[0].Stats())
		}
	})
	var late packet
	var firstVotes int
	until(t, "four remote first votes captured (one held)", func() bool {
		m.pump(func(p packet) bool {
			if p.m.Kind == c.Vote && p.m.Request == c.PreAccept {
				if p.from == 4 {
					late = p
				}
				if p.from < 4 {
					firstVotes++
				}
				return p.from < 4
			}
			return p.m.Kind != c.Accept
		})
		return firstVotes >= 3 && late.m.Kind != 0 && collected.Load()
	})
	clock.advance(W)
	until(t, "slow Accept broadcast", func() bool {
		found := false
		m.pump(func(p packet) bool {
			found = found || p.m.Kind == c.Accept
			return false
		})
		return found
	})
	m.deliver(t, late.from, late.to, late.m)
	if r := await(t, out); r.Status != c.Applied {
		t.Fatal(r)
	}
	if s := m.nodes[0].Stats(); s.Fast != 1 || s.Formal != 0 {
		t.Fatalf("unexpected decisions: %+v", s)
	}
}

func TestSmallCollectPhasesAndRetryWaiters(t *testing.T) {
	W := 80 * time.Millisecond
	clock := &manualClock{now: time.Unix(200, 0)}
	m := newMesh(t, 7, []int{0, 1, 2}, c.Config{
		F: 4, E: 1, Window: W, Clock: clock, Workers: 1,
	}, true)
	cmd := command(t, "put", "small", "value")
	a, b := submit(m.nodes[0], cmd), submit(m.nodes[0], cmd)
	phase := [6]uint64{}
	until(t, "phase one PreAccept replies", func() bool {
		m.pump(func(p packet) bool {
			if p.m.Request == c.PreAccept && p.m.Kind == c.Vote {
				phase[0] = p.m.Nonce
			}
			return true
		})
		return phase[0] != 0
	})
	clock.advance(W)
	for step, kind := range []c.Kind{c.PreAccept, c.Accept, c.Accept} {
		until(t, "next collect phase", func() bool {
			m.pump(func(p packet) bool {
				if p.from == 0 && p.m.Kind == kind && (p.m.Phase == 2) == (step != 1) {
					phase[step+1] = p.m.Nonce
				}
				return true
			})
			return phase[step+1] != 0
		})
		if step == 1 {
			clock.advance(W)
		}
	}
	until(t, "single instance execution", func() bool {
		m.pump(nil)
		return m.nodes[0].Stats().OriginExecuted == 1
	})
	for _, out := range []<-chan c.Result{a, b} {
		if r := await(t, out); r.Status != c.Applied {
			t.Fatal(r)
		}
	}
	if !(phase[0] < phase[1] && phase[1] < phase[2] && phase[2] < phase[3]) {
		t.Fatalf("phase identities reused: %v", phase)
	}
	if s := m.nodes[0].Stats(); s.Admitted != 1 || s.Fast != 0 || s.Formal != 1 {
		t.Fatalf("unexpected state: %+v", s)
	}
}

func TestValidateHelpAfterCoordinatorCrash(t *testing.T) {
	W := 50 * time.Millisecond
	clock := &manualClock{now: time.Unix(300, 0)}
	var sawHelp atomic.Bool
	m := newMesh(t, 7, []int{1, 2, 3}, c.Config{
		F: 4, E: 1, Window: W, Clock: clock, RecoveryDelay: 200 * W, Workers: 1, Trace: func(e c.Event) {
			if e.Stage == "help" {
				sawHelp.Store(true)
			}
		},
	}, true)
	x, y := c.ID{Replica: 0, Number: 1}, c.ID{Replica: 4, Number: 1}
	vx := &c.Value{Command: command(t, "put", "conflict", "x"), Deps: make([]uint64, 7), Seq: 1}
	vy := &c.Value{Command: command(t, "put", "conflict", "y"), Deps: make([]uint64, 7), Seq: 1}
	m.deliver(t, 0, 1, initial(x, vx))
	m.deliver(t, 0, 2, initial(x, vx))
	m.deliver(t, 4, 3, initial(y, vy))
	hits := map[int]bool{}
	until(t, "disjoint first votes", func() bool {
		m.pump(func(p packet) bool {
			if p.m.Kind == c.Vote && p.m.First != nil && p.m.First.Fast {
				hits[p.from] = true
			}
			return false
		})
		return len(hits) == 3
	})
	for p := 1; p <= 3; p++ {
		for id, v := range map[c.ID]*c.Value{x: vx, y: vy} {
			m.deliver(t, id.Replica, p, c.Message{X: id, Key: "conflict", Kind: c.Initial, Init: v})
		}
	}
	// Establish Omega through exact heartbeats and real complaints.
	for i := 0; i < 5; i++ {
		clock.advance(W / 2)
		for j := 0; j < 8; j++ {
			m.pump(nil)
			time.Sleep(200 * time.Microsecond)
		}
	}
	until(t, "live common Omega", func() bool {
		m.pump(nil)
		return m.nodes[1].Stats().Omega == 1 && m.nodes[2].Stats().Omega == 1 && m.nodes[3].Stats().Omega == 1
	})
	m.deliver(t, 2, 1, c.Message{X: x, Key: "conflict", Kind: c.NeedRecover})
	decisions := make(map[c.ID]*c.Value)
	for i := 0; i < 80 && len(decisions) < 2; i++ {
		clock.advance(W / 2)
		for j := 0; j < 8; j++ {
			m.pump(func(p packet) bool {
				if p.m.Kind == c.Learn {
					decisions[p.m.X] = p.m.Value
				}
				return true
			})
			time.Sleep(200 * time.Microsecond)
		}
	}
	if !sawHelp.Load() || !c.Equal(decisions[x], vx) || decisions[y] == nil || decisions[y].Deps[0] != 1 {
		t.Fatalf("validation outcomes: help=%v x=%+v y=%+v", sawHelp.Load(), decisions[x], decisions[y])
	}
}

func TestClosureFetchAndCycle(t *testing.T) {
	got := make(chan c.Event, 128)
	m := newMesh(t, 3, []int{2}, c.Config{F: 1, Window: 100 * time.Millisecond, Workers: 1, Trace: func(e c.Event) {
		if e.Stage == "execute" {
			got <- e
		}
	}}, true)
	a, x, y := c.ID{Replica: 0, Number: 1}, c.ID{Replica: 0, Number: 3}, c.ID{Replica: 1, Number: 10}
	va := &c.Value{Command: command(t, "put", "cycle", "a"), Deps: []uint64{0, 0, 0}, Seq: 1}
	vx := &c.Value{Command: command(t, "put", "cycle", "x"), Deps: []uint64{1, 0, 0}, Seq: 2}
	vy := &c.Value{Command: command(t, "put", "cycle", "y"), Deps: []uint64{0, 0, 0}, Seq: 1}
	fx := &c.Value{Command: vx.Command, Deps: []uint64{1, 10, 0}, Seq: 4}
	fy := &c.Value{Command: vy.Command, Deps: []uint64{3, 0, 0}, Seq: 3}
	for _, p := range []packet{
		{0, 2, c.Message{Kind: c.Learn, X: x, Key: "cycle", Init: vx, Value: fx}},
		{1, 2, c.Message{Kind: c.Learn, X: y, Key: "cycle", Init: vy, Value: fy}},
	} {
		m.deliver(t, p.from, p.to, p.m)
	}
	until(t, "Fetch for missing predecessor", func() bool {
		found := false
		m.pump(func(p packet) bool {
			if p.m.Kind == c.Fetch {
				if p.m.X == (c.ID{Replica: 0, Number: 2}) {
					t.Fatal("unexpected unrelated gap Fetch")
				}
				found = found || p.m.X == a
			}
			return false
		})
		return found
	})
	select {
	case e := <-got:
		t.Fatalf("execution before data arrival: %+v", e)
	default:
	}
	m.deliver(t, 1, 2, c.Message{Kind: c.Done, X: a, Key: "cycle", Init: va, Value: va})
	for _, want := range []c.ID{a, y, x} {
		select {
		case e := <-got:
			if e.X != want {
				t.Fatalf("executed %+v, want %+v", e.X, want)
			}
		case <-time.After(5 * time.Second):
			t.Fatal("execution stalled")
		}
	}
	if r := await(t, submit(m.nodes[2], vx.Command)); r.Status != c.Duplicate {
		t.Fatal(r)
	}
}

func TestAdmissionTimeoutAndClassGate(t *testing.T) {
	clock := &manualClock{now: time.Unix(400, 0)}
	m := newMesh(t, 3, []int{0}, c.Config{
		F: 1, Window: 100 * time.Millisecond, Clock: clock, Overdue: 50 * time.Millisecond,
		MaxInflight: 2, Wait: 50 * time.Millisecond, Workers: 1,
	}, true)
	a := command(t, "put", "blocked", "a")
	if r := await(t, submit(m.nodes[0], a)); r.Status != c.Pending {
		t.Fatal(r)
	}
	clock.advance(60 * time.Millisecond)
	if r := await(t, submit(m.nodes[0], command(t, "put", "blocked", "b"))); r.Status != c.Rejected {
		t.Fatal(r)
	}
	if r := await(t, submit(m.nodes[0], command(t, "put", "independent", "b"))); r.Status != c.Pending {
		t.Fatal(r)
	}
	if r := await(t, submit(m.nodes[0], command(t, "put", "limit", "b"))); r.Status != c.Rejected {
		t.Fatal(r)
	}
	if r := await(t, submit(m.nodes[0], a)); r.Status != c.Pending || m.nodes[0].Stats().Admitted != 2 {
		t.Fatal(r, m.nodes[0].Stats())
	}
}

// Peers 1 and 2 saved different, partial accepted records before replica 0
// crashed. The new coordinator must carry the higher one through formal Accept.
func TestRecoveryInheritsHighestAccepted(t *testing.T) {
	W := 40 * time.Millisecond
	clock := &manualClock{now: time.Unix(600, 0)}
	m := newMesh(t, 3, []int{1, 2}, c.Config{
		F: 1, Window: W, RecoveryDelay: 50 * W, Clock: clock, Workers: 1,
	}, true)
	x, y := c.ID{Replica: 0, Number: 1}, c.ID{Replica: 2, Number: 1}
	vx := &c.Value{Command: command(t, "put", "inherited", "x"), Deps: []uint64{0, 0, 0}, Seq: 1}
	vy := &c.Value{Command: command(t, "put", "inherited", "y"), Deps: []uint64{0, 0, 0}, Seq: 1}
	higher := &c.Value{Command: vx.Command, Deps: []uint64{0, 0, 1}, Seq: 2}
	for _, p := range []int{1, 2} {
		m.deliver(t, 2, p, c.Message{Kind: c.Initial, X: y, Key: "inherited", Init: vy})
	}
	m.deliver(t, 0, 1, c.Message{Kind: c.Accept, X: x, Key: "inherited", Init: vx, Value: vx, Phase: 1, Attempt: 1, Nonce: 1})
	m.deliver(t, 0, 2, c.Message{Kind: c.Accept, X: x, Key: "inherited", Init: vx, Value: higher,
		Ballot: c.Ballot{Round: 1, Owner: 0}, Phase: 1, Attempt: 2, Nonce: 2})
	accepted := map[int]bool{}
	// Await both formal acknowledgments without letting any coordinator collect them.
	until(t, "partial accept records", func() bool {
		m.pump(func(p packet) bool {
			if p.m.Kind == c.Vote && p.m.Request == c.Accept && p.to == 0 {
				accepted[p.from] = true
			}
			return true
		})
		clock.advance(time.Millisecond)
		return len(accepted) == 2
	})
	for i := 0; i < 7; i++ {
		clock.advance(W / 2)
		for j := 0; j < 8; j++ {
			m.pump(nil)
			time.Sleep(200 * time.Microsecond)
		}
	}
	until(t, "Omega 1", func() bool {
		m.pump(nil)
		return m.nodes[1].Stats().Omega == 1 && m.nodes[2].Stats().Omega == 1
	})
	m.deliver(t, 2, 1, c.Message{Kind: c.NeedRecover, X: x, Key: "inherited"})
	var decision *c.Value
	until(t, "inherited decision", func() bool {
		m.pump(func(p packet) bool {
			if p.m.Kind == c.Learn && p.m.X == x {
				decision = p.m.Value
			}
			return true
		})
		return decision != nil
	})
	if !c.Equal(decision, higher) {
		t.Fatalf("decided %+v, expected highest accepted %+v", decision, higher)
	}
}

func TestDecisionDisseminationAfterPartialBroadcast(t *testing.T) {
	W := 40 * time.Millisecond
	clock := &manualClock{now: time.Unix(700, 0)}
	executions := make(chan c.Event, 32)
	m := newMesh(t, 3, []int{1, 2}, c.Config{
		F: 1, Window: W, Clock: clock, Workers: 1, Trace: func(e c.Event) {
			if e.Stage == "execute" {
				executions <- e
			}
		},
	}, true)
	x := c.ID{Replica: 0, Number: 1}
	v := &c.Value{Command: command(t, "put", "stray-decision", "held"), Deps: []uint64{0, 0, 0}, Seq: 1}
	m.deliver(t, 0, 1, c.Message{Kind: c.Learn, X: x, Key: v.Command.Key, Init: v, Value: v})
	until(t, "holder executes", func() bool { return len(executions) == 1 })
	clock.advance(W)
	until(t, "second survivor executes", func() bool {
		m.pump(nil)
		return len(executions) == 2
	})
	if r := await(t, submit(m.nodes[2], v.Command)); r.Status != c.Duplicate {
		t.Fatal(r)
	}
}

func TestOverloadedEntryStillRecognizesExecutedAndPendingRetries(t *testing.T) {
	clock := &manualClock{now: time.Unix(800, 0)}
	ran := make(chan struct{}, 1)
	m := newMesh(t, 3, []int{0}, c.Config{
		F: 1, Window: time.Second, Clock: clock, MaxWaiters: 1, Workers: 1, Trace: func(e c.Event) {
			if e.Stage == "execute" {
				ran <- struct{}{}
			}
		},
	}, true)
	cmd := command(t, "put", "completed", "value")
	x := c.ID{Replica: 1, Number: 1}
	v := &c.Value{Command: cmd, Deps: []uint64{0, 0, 0}, Seq: 1}
	m.deliver(t, 1, 0, c.Message{Kind: c.Done, X: x, Key: cmd.Key, Init: v, Value: v})
	until(t, "completed instance executes", func() bool { return len(ran) == 1 })
	pending := command(t, "put", "waiting", "value")
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	wait := make(chan c.Result, 1)
	go func() { wait <- m.nodes[0].Submit(ctx, pending) }()
	until(t, "sole waiter admission", func() bool { return m.nodes[0].Stats().Admitted == 1 })
	if r := m.nodes[0].Submit(context.Background(), cmd); r.Status != c.Duplicate {
		t.Fatal(r)
	}
	if r := m.nodes[0].Submit(context.Background(), pending); r.Status != c.Pending {
		t.Fatal(r)
	}
	cancel()
	if r := await(t, wait); r.Status != c.Unknown || m.nodes[0].Stats().Inflight != 1 {
		t.Fatal(r, m.nodes[0].Stats())
	}
}

func TestHigherHeartbeatDoesNotSatisfyMissingNumber(t *testing.T) {
	W := 40 * time.Millisecond
	clock := &manualClock{now: time.Unix(900, 0)}
	m := newMesh(t, 3, []int{1}, c.Config{
		F: 1, Window: W, Clock: clock, Workers: 1,
	}, true)
	until(t, "detector starts", func() bool {
		clock.advance(time.Millisecond)
		beat := false
		m.pump(func(p packet) bool {
			beat = beat || p.m.Kind == c.Heartbeat
			return false
		})
		return beat
	})
	m.deliver(t, 0, 1, c.Message{Kind: c.Heartbeat, Notice: 2, Number: 2})
	until(t, "heartbeat two saved", func() bool {
		acked := false
		m.pump(func(p packet) bool {
			acked = acked || p.to == 0 && p.m.Kind == c.NoticeAck && p.m.Notice == 2
			return false
		})
		return acked
	})
	clock.advance(2 * W)
	until(t, "complaint about missing heartbeat one", func() bool {
		complaint := false
		m.pump(func(p packet) bool {
			complaint = complaint || p.m.Kind == c.Complaint && p.m.Subject == 0 && p.m.Number == 1
			return false
		})
		return complaint
	})
	m.deliver(t, 2, 1, c.Message{Kind: c.Complaint, Notice: 1, Subject: 0, Number: 1})
	until(t, "two distinct witnesses move Omega", func() bool { return m.nodes[1].Stats().Omega == 1 })
}
