package tests

import (
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"example.com/mixepaxos/client"
	c "example.com/mixepaxos/consensus"
)

// TestHistoryCost can report a warm and a cold probe over an adjustable set of
// already-decided chains. Only the normal data and execution handlers run.
func TestHistoryCost(t *testing.T) {
	setting := os.Getenv("MIX_HISTORY")
	if setting == "" {
		setting = "12"
	}
	for _, s := range strings.Split(setting, ",") {
		length, err := strconv.Atoi(s)
		if err != nil || length < 1 || length > 100000 {
			t.Fatalf("invalid history length %q", s)
		}
		for _, cold := range []bool{false, true} {
			t.Run(fmt.Sprintf("%d/cold=%v", length, cold), func(t *testing.T) {
				probeHistory(t, length, cold)
			})
		}
	}
}

func probeHistory(t *testing.T, length int, cold bool) {
	session, err := client.NewSession()
	if err != nil {
		t.Fatal(err)
	}
	packets := make([]c.Message, length+2)
	for i := 1; i < len(packets); i++ {
		cmd, err := session.NewCommand("put", "history", "value")
		if err != nil {
			t.Fatal(err)
		}
		v := &c.Value{Command: cmd, Seq: uint64(i), Deps: []uint64{uint64(i - 1), 0, 0}}
		packets[i] = c.Message{
			Kind: c.Done, X: c.ID{Replica: 0, Number: uint64(i)},
			Key: cmd.Key, Init: v, Value: v,
		}
	}
	var node *c.Node
	var executed atomic.Uint64
	var messages, bytes atomic.Uint64
	clock := &manualClock{now: time.Unix(500, 0)}
	logical := os.Getenv("MIX_HISTORY") != ""
	runtime.GC()
	var b, a runtime.MemStats
	runtime.ReadMemStats(&b)
	node, err = c.New(c.Config{Members: 3, Self: 2, F: 1, Window: time.Second, Clock: clock, Workers: 1,
		Trace: func(e c.Event) {
			if e.Stage == "execute" {
				executed.Add(1)
			}
		},
	}, sender(func(to int, m c.Message) bool {
		if m.Kind == c.Fetch && to == 1 {
			r := packets[m.X.Number]
			if logical {
				body, _ := json.Marshal(r)
				bytes.Add(uint64(len(body)))
			}
			messages.Add(1)
			return node.Deliver(to, r)
		}
		return true
	}))
	if err != nil {
		t.Fatal(err)
	}
	defer node.Close()
	delivery := func(i int) {
		if !node.Deliver(0, packets[i]) {
			t.Fatal("fixture inbox full")
		}
	}
	if !cold {
		for i := 1; i <= length; i++ {
			delivery(i)
			until(t, "prefill execution", func() bool { return executed.Load() == uint64(i) })
		}
	}
	stats := node.Stats()
	start := time.Now()
	delivery(length + 1)
	for executed.Load() != uint64(length+1) && time.Since(start) < 5*time.Second {
		runtime.Gosched()
	}
	elapsed := time.Since(start)
	if executed.Load() != uint64(length+1) {
		t.Fatalf("incomplete history: %d, fetch count %d", executed.Load(), node.Stats().Fetch)
	}
	runtime.GC()
	runtime.ReadMemStats(&a)
	final := node.Stats()
	if cold && (messages.Load() != uint64(length) || final.Vertices-stats.Vertices != uint64(length+1)) {
		t.Fatalf("expected one fetched value per missing ID and one execution visit per vertex: %+v", final)
	}
	if !cold && (messages.Load() != 0 || final.Vertices-stats.Vertices != 1) {
		t.Fatalf("warm probe revisited history: %+v", final)
	}
	t.Logf("probe=%s fetch_rounds=%d fetched_values=%d logical_reply_JSON_bytes=%d execution_vertices=%d live_heap_delta_bytes=%d",
		elapsed, final.Fetch-stats.Fetch, messages.Load(), bytes.Load(), final.Vertices-stats.Vertices,
		int64(a.HeapAlloc)-int64(b.HeapAlloc))
}
