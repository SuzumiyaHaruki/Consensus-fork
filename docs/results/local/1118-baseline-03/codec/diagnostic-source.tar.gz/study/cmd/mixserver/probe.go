package main

import (
	"net/http"
	_ "net/http/pprof"
	"os"
)

func init() {
	if os.Getenv("CPU_PROBE") == "1" {
		go http.ListenAndServe("127.0.0.1:17820", nil)
	}
}
