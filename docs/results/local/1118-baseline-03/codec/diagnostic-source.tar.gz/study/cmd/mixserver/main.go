package main

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"runtime"
	"runtime/trace"
	"syscall"
	"time"

	"example.com/mixepaxos/consensus"
	"example.com/mixepaxos/transport"
)

func main() {
	if err := run(); err != nil {
		log.Print(err)
		os.Exit(1)
	}
}

func run() error {
	path := flag.String("config", "cluster/config.json", "cluster configuration")
	self := flag.Int("id", 0, "zero-based member index")
	certFile := flag.String("cert", "", "TLS certificate (default beside config)")
	keyFile := flag.String("key", "", "TLS private key (default beside config)")
	workers := flag.Int("workers", 2, "protocol workers")
	procs := flag.Int("procs", 0, "GOMAXPROCS override (default Go runtime setting)")
	queue := flag.Int("queue", 1024, "per-worker and per-peer queue capacities")
	limit := flag.Int("inflight", 256, "maximum local admitted, unexecuted instances")
	waiters := flag.Int("waiters", 1024, "maximum simultaneous request waiters")
	wait := flag.Duration("wait", 3*time.Second, "maximum server reply wait")
	retry := flag.Duration("retry", 0, "protocol retry interval (default W)")
	recovery := flag.Duration("recovery", 0, "recovery startup delay (default 6W)")
	overdue := flag.Duration("overdue", 0, "class admission pause threshold (default 8W)")
	heartbeat := flag.Duration("heartbeat", 0, "heartbeat broadcast interval (default W/2)")
	tick := flag.Duration("tick", 0, "worker timer sampling interval")
	batch := flag.Int("batch", 32, "maximum messages per peer frame")
	traceFile := flag.String("trace", "", "optional Go execution trace output file")
	flag.Parse()
	if *procs > 0 {
		runtime.GOMAXPROCS(*procs)
	}
	if *traceFile != "" {
		f, err := os.Create(*traceFile)
		if err != nil {
			return err
		}
		defer f.Close()
		if err := trace.Start(f); err != nil {
			return err
		}
		defer trace.Stop()
	}
	cfg, err := transport.ReadConfig(*path)
	if err != nil {
		return err
	}
	nc, err := cfg.Node(*self)
	if err != nil {
		return err
	}
	nc.Workers, nc.Queue, nc.MaxInflight, nc.MaxWaiters = *workers, *queue, *limit, *waiters
	nc.Wait, nc.Retry, nc.RecoveryDelay, nc.Overdue, nc.Heartbeat, nc.Tick = *wait, *retry, *recovery, *overdue, *heartbeat, *tick
	certDefault, keyDefault := transport.CredentialPaths(*path, *self)
	if *certFile == "" {
		*certFile = certDefault
	}
	if *keyFile == "" {
		*keyFile = keyDefault
	}
	cert, err := tls.LoadX509KeyPair(*certFile, *keyFile)
	if err != nil {
		return err
	}
	link, err := transport.NewTCP(cfg, *self, cert, *queue, *batch)
	if err != nil {
		return err
	}
	defer link.Close()
	node, err := consensus.New(nc, link)
	if err != nil {
		return err
	}
	defer node.Close()
	if err := link.Start(node.Deliver); err != nil {
		return err
	}
	mux := http.NewServeMux()
	mux.HandleFunc("POST /request", func(w http.ResponseWriter, r *http.Request) {
		var cmd consensus.Command
		dec := json.NewDecoder(http.MaxBytesReader(w, r.Body, 512<<10))
		dec.DisallowUnknownFields()
		if err := dec.Decode(&cmd); err != nil || dec.Decode(new(any)) != io.EOF {
			respond(w, consensus.Result{Status: consensus.Rejected, Error: "invalid request encoding"})
			return
		}
		respond(w, node.Submit(r.Context(), cmd))
	})
	mux.HandleFunc("GET /stats", func(w http.ResponseWriter, r *http.Request) {
		respond(w, struct {
			consensus.Stats
			transport.WireStats
			Workers, GOMAXPROCS int
		}{node.Stats(), link.Stats(), *workers, runtime.GOMAXPROCS(0)})
	})
	addr := cfg.Members[*self].Client
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	server := &http.Server{
		Handler: mux, ReadHeaderTimeout: 2 * time.Second, ReadTimeout: 5 * time.Second,
		IdleTimeout: 30 * time.Second, MaxHeaderBytes: 16 << 10,
	}
	defer server.Close()
	errorsCh := make(chan error, 1)
	go func() { errorsCh <- server.Serve(ln) }()
	log.Printf("member %d serving clients at %s with %d protocol workers and GOMAXPROCS=%d", *self, addr, *workers, runtime.GOMAXPROCS(0))
	stop, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	select {
	case <-stop.Done():
		node.Close()
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		return server.Shutdown(ctx)
	case err := <-errorsCh:
		if !errors.Is(err, http.ErrServerClosed) {
			return fmt.Errorf("client listener: %w", err)
		}
	}
	return nil
}

func respond(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(v); err != nil {
		return // A canceled client can retry using the same request ID.
	}
}
