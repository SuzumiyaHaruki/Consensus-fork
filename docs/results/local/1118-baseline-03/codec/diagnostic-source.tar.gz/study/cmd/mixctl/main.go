package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"strings"
	"time"

	"example.com/mixepaxos/client"
	"example.com/mixepaxos/consensus"
	"example.com/mixepaxos/transport"
)

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(args []string) error {
	if len(args) == 0 {
		return fmt.Errorf("usage: mixctl {config|request|submit} [flags]")
	}
	fs := flag.NewFlagSet(args[0], flag.ContinueOnError)
	out := json.NewEncoder(os.Stdout)
	switch args[0] {
	case "config":
		dir := fs.String("dir", "cluster", "new directory")
		n := fs.Int("n", 7, "member count")
		f := fs.Int("f", 4, "crash bound")
		s := fs.Int("s", 0, "number of slow living members allowed during W")
		e := fs.Int("e", 1, "fast-path missing vote allowance")
		window := fs.Duration("window", 100*time.Millisecond, "broadcast window")
		base := fs.Int("base", 7100, "first peer port, followed by client ports")
		if err := fs.Parse(args[1:]); err != nil {
			return err
		}
		return transport.GenerateLoopback(*dir, *n, *f, *s, *e, *base, *window)
	case "request":
		op := fs.String("op", "get", "put, get or delete")
		key := fs.String("key", "", "operation key")
		value := fs.String("value", "", "value for put")
		if err := fs.Parse(args[1:]); err != nil {
			return err
		}
		s, err := client.NewSession()
		if err != nil {
			return err
		}
		cmd, err := s.NewCommand(*op, *key, *value)
		if err != nil {
			return err
		}
		return out.Encode(cmd)
	case "submit":
		file := fs.String("request", "-", "request JSON file or stdin")
		entries := fs.String("entries", "127.0.0.1:7107", "comma-separated entry replica client addresses")
		attempts := fs.Int("attempts", 1, "maximum attempts")
		wait := fs.Duration("timeout", 4*time.Second, "timeout per attempt")
		if err := fs.Parse(args[1:]); err != nil {
			return err
		}
		if *attempts <= 0 || *wait <= 0 || strings.TrimSpace(*entries) == "" {
			return fmt.Errorf("provide at least one attempt and entry with a positive timeout")
		}
		var src io.Reader = os.Stdin
		if *file != "-" {
			f, err := os.Open(*file)
			if err != nil {
				return err
			}
			defer f.Close()
			src = f
		}
		var cmd consensus.Command
		d := json.NewDecoder(io.LimitReader(src, 512<<10))
		d.DisallowUnknownFields()
		if err := d.Decode(&cmd); err != nil {
			return err
		}
		if d.Decode(new(any)) != io.EOF {
			return fmt.Errorf("request file contains trailing data")
		}
		for _, r := range (client.Client{}).Retry(context.Background(), strings.Split(*entries, ","), cmd, *attempts, *wait) {
			if err := out.Encode(r); err != nil {
				return err
			}
		}
		return nil
	default:
		return fmt.Errorf("unknown command %q", args[0])
	}
}
