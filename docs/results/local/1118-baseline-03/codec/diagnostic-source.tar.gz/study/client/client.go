// Package client allocates sessions and submits immutable commands to replicas.
package client

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync/atomic"
	"time"

	"example.com/mixepaxos/consensus"
)

type Session struct {
	id  string
	seq atomic.Uint64
}

func NewSession() (*Session, error) {
	var id [32]byte
	if _, err := rand.Read(id[:]); err != nil {
		return nil, err
	}
	return &Session{id: hex.EncodeToString(id[:])}, nil
}

// NewCommand is safe for concurrent use of the session.
func (s *Session) NewCommand(op, key, value string) (consensus.Command, error) {
	for {
		previous := s.seq.Load()
		if previous == ^uint64(0) {
			return consensus.Command{}, fmt.Errorf("session sequence exhausted")
		}
		cmd := consensus.Command{RID: consensus.RID{Client: s.id, Seq: previous + 1}, Op: op, Key: key, Value: value}
		if !cmd.Valid() {
			return consensus.Command{}, fmt.Errorf("invalid operation, key or value")
		}
		if s.seq.CompareAndSwap(previous, previous+1) {
			return cmd, nil
		}
	}
}

type Client struct {
	HTTP *http.Client
}

func (c Client) Submit(ctx context.Context, endpoint string, command consensus.Command) consensus.Result {
	fail := func(e error) consensus.Result {
		return consensus.Result{Status: consensus.Unknown, Error: e.Error()}
	}
	if !command.Valid() {
		return consensus.Result{Status: consensus.Rejected, Error: "invalid command"}
	}
	if !strings.Contains(endpoint, "://") {
		endpoint = "http://" + endpoint
	}
	p, err := json.Marshal(command)
	if err != nil {
		return fail(err)
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, strings.TrimRight(endpoint, "/")+"/request", bytes.NewReader(p))
	if err != nil {
		return fail(err)
	}
	request.Header.Set("Content-Type", "application/json")
	hc := c.HTTP
	if hc == nil {
		hc = http.DefaultClient
	}
	resp, err := hc.Do(request)
	if err != nil {
		return fail(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fail(fmt.Errorf("unexpected HTTP status %s", resp.Status))
	}
	var r consensus.Result
	if err := json.NewDecoder(io.LimitReader(resp.Body, 512<<10)).Decode(&r); err != nil {
		return fail(err)
	}
	switch r.Status {
	case consensus.Applied, consensus.Duplicate, consensus.Rejected, consensus.Pending, consensus.Unknown:
		return r
	default:
		return fail(fmt.Errorf("unrecognized result status %q", r.Status))
	}
}

// Retry sends the same command, cycling entries after pending or unknown replies.
// Final rejection is returned to the caller with any earlier outcomes preserved.
func (c Client) Retry(ctx context.Context, endpoints []string, cmd consensus.Command, attempts int, perAttempt time.Duration) []consensus.Result {
	results := make([]consensus.Result, 0)
	for i := 0; i < attempts && len(endpoints) != 0 && ctx.Err() == nil; i++ {
		if i != 0 {
			delay := min(time.Second, 20*time.Millisecond<<min(i-1, 6))
			timer := time.NewTimer(delay)
			select {
			case <-ctx.Done():
				timer.Stop()
				return results
			case <-timer.C:
			}
		}
		call, cancel := context.WithTimeout(ctx, perAttempt)
		r := c.Submit(call, endpoints[i%len(endpoints)], cmd)
		cancel()
		results = append(results, r)
		if r.Status != consensus.Pending && r.Status != consensus.Unknown {
			break
		}
	}
	return results
}
