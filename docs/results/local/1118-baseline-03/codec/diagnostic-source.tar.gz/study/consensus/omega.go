package consensus

import "time"

type suspicion struct {
	member int
	number uint64
}

type observation struct {
	next     uint64
	deadline time.Time
	saved    map[uint64]bool
	bad      uint64
}

type noticePeer struct {
	delivered uint64
	beat      uint64
	acked     map[uint64]bool
}

type detector struct {
	*worker
	peers               []noticePeer
	observe             []observation
	complaints          map[suspicion]map[int]bool
	bad                 map[suspicion]bool
	notices             []Message
	offset              uint64
	heartbeat           uint64
	nextBeat, nextRetry time.Time
}

func newDetector(w *worker) *detector {
	d := &detector{
		worker: w, peers: make([]noticePeer, w.cfg.Members), observe: make([]observation, w.cfg.Members),
		complaints: make(map[suspicion]map[int]bool), bad: make(map[suspicion]bool),
	}
	for i := range d.observe {
		d.observe[i].next = 1
		d.observe[i].saved = make(map[uint64]bool)
		d.peers[i].acked = make(map[uint64]bool)
	}
	return d
}

func (d *detector) tick(now time.Time) {
	if !now.Before(d.nextBeat) {
		d.nextBeat = now.Add(d.cfg.Heartbeat)
		d.heartbeat++
		for p := range d.peers {
			if p != d.cfg.Self {
				d.sendBeat(p, d.heartbeat)
			}
		}
	}
	for p := range d.observe {
		if p == d.cfg.Self {
			continue
		}
		o := &d.observe[p]
		if o.deadline.IsZero() {
			d.check(p, now)
		} else if !now.Before(o.deadline) {
			k := o.next
			o.next++
			d.check(p, now)
			d.publish(Message{Kind: Complaint, Subject: p, Number: k})
			d.complain(d.cfg.Self, suspicion{p, k})
		}
	}
	if !now.Before(d.nextRetry) {
		d.nextRetry = now.Add(d.cfg.Retry)
		for p, peer := range d.peers {
			if p == d.cfg.Self {
				continue
			}
			for k := peer.beat + 1; k < d.heartbeat && k <= peer.beat+16; k++ {
				d.sendBeat(p, k)
			}
			end := min(d.offset+uint64(len(d.notices)), peer.delivered+16)
			for seq := peer.delivered + 1; seq <= end; seq++ {
				if !peer.acked[seq] {
					d.send(p, d.notices[seq-d.offset-1])
				}
			}
		}
	}
}

func (d *detector) check(p int, now time.Time) {
	o := &d.observe[p]
	for o.saved[o.next] {
		delete(o.saved, o.next)
		o.next++
	}
	o.deadline = now.Add(timeout(d.cfg.Window, o.bad))
}

func (d *detector) sendBeat(p int, k uint64) {
	d.send(p, Message{Kind: Heartbeat, Number: k, Notice: k})
}

func (d *detector) publish(m Message) {
	m.Notice = d.offset + uint64(len(d.notices)) + 1
	d.notices = append(d.notices, m)
	for p := range d.peers {
		if p != d.cfg.Self {
			d.send(p, m)
		}
	}
	if len(d.peers) == 1 {
		d.trim()
	}
}

func (d *detector) receive(in incoming) {
	m := in.msg
	if in.from == d.cfg.Self || m.Notice == 0 {
		return
	}
	if m.Kind == NoticeAck {
		if m.Request == Heartbeat {
			p := &d.peers[in.from]
			if p.beat+1 == m.Notice && m.Notice <= d.heartbeat {
				p.beat++
			}
		} else {
			d.ack(in.from, m.Notice)
		}
		return
	}
	if m.Number == 0 {
		return
	}
	switch m.Kind {
	case Heartbeat:
		o := &d.observe[in.from]
		if m.Number >= o.next {
			o.saved[m.Number] = true
			if m.Number == o.next {
				d.check(in.from, d.now())
			}
		}
	case Complaint:
		if m.Subject < 0 || m.Subject >= len(d.peers) || m.Subject == in.from {
			return
		}
		d.complain(in.from, suspicion{m.Subject, m.Number})
	case Bad:
		if m.Subject < 0 || m.Subject >= len(d.peers) || len(m.Witnesses) != d.cfg.Members-d.cfg.F {
			return
		}
		seen := make(map[int]bool)
		for _, p := range m.Witnesses {
			if p < 0 || p >= len(d.peers) || p == m.Subject || seen[p] {
				return
			}
			seen[p] = true
		}
		d.confirm(suspicion{m.Subject, m.Number}, m.Witnesses)
	}
	d.send(in.from, Message{Kind: NoticeAck, Request: m.Kind, Notice: m.Notice})
}

func (d *detector) ack(p int, number uint64) {
	peer := &d.peers[p]
	if number <= peer.delivered || number > d.offset+uint64(len(d.notices)) {
		return
	}
	peer.acked[number] = true
	before := peer.delivered
	for peer.acked[peer.delivered+1] {
		peer.delivered++
		delete(peer.acked, peer.delivered)
	}
	if peer.delivered != before {
		d.trim()
	}
}

func (d *detector) trim() {
	upTo := d.offset + uint64(len(d.notices))
	for p, peer := range d.peers {
		if p != d.cfg.Self {
			upTo = min(upTo, peer.delivered)
		}
	}
	n := upTo - d.offset
	clear(d.notices[:n])
	d.notices = d.notices[n:]
	d.offset = upTo
}

func (d *detector) complain(from int, key suspicion) {
	if d.bad[key] {
		return
	}
	witnesses := d.complaints[key]
	if witnesses == nil {
		witnesses = make(map[int]bool)
		d.complaints[key] = witnesses
	}
	witnesses[from] = true
	if len(witnesses) == d.cfg.Members-d.cfg.F {
		proof := make([]int, 0, len(witnesses))
		for p := range witnesses {
			proof = append(proof, p)
		}
		d.confirm(key, proof)
	}
}

func (d *detector) confirm(key suspicion, proof []int) {
	if d.bad[key] {
		return
	}
	d.bad[key] = true
	delete(d.complaints, key)
	d.observe[key.member].bad++
	omega := 0
	for p := 1; p < len(d.observe); p++ {
		if d.observe[p].bad < d.observe[omega].bad {
			omega = p
		}
	}
	if omega != d.omega.Load().id {
		d.omega.Store(&leader{id: omega})
		d.trace("omega", ID{Replica: omega}, Bad)
	}
	d.publish(Message{Kind: Bad, Subject: key.member, Number: key.number, Witnesses: proof})
}
