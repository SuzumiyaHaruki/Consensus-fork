package consensus

import (
	"context"
	"fmt"
	"hash/maphash"
	"sync"
	"sync/atomic"
	"time"
)

type counters struct {
	admitted, decided, executed, undecided, inflight atomic.Uint64
	fast, formal, recovered, windows, invalid        atomic.Uint64
	rejected, sent, dropped, fetch, vertices         atomic.Uint64
	ridConflict, decisionConflict, tasks, overlap    atomic.Uint64
	admitNS, decideNS, executeNS, replyNS            atomic.Uint64
	replies                                          atomic.Uint64
}

type Stats struct {
	Admitted, OriginDecided, OriginExecuted, Undecided, Inflight uint64
	Fast, Formal, Recovered, ShortWindows, Invalid               uint64
	Rejected, Sent, Dropped, Fetch, Vertices                     uint64
	RIDConflicts, DecisionConflicts, ParallelTasks, PeakParallel uint64
	AdmissionNS, DecisionNS, ExecutionNS, ReplyNS, Replies       uint64
	Omega                                                        int
}

type Node struct {
	cfg      Config
	link     Transport
	hash     maphash.Seed
	workers  []*worker
	stop     chan struct{}
	stopOnce sync.Once
	running  sync.WaitGroup
	omega    atomic.Pointer[leader]
	index    atomic.Uint64
	active   atomic.Uint64
	ids      sync.Map // instance ID -> conflict class
	count    counters
	bindings sync.Map // canonical rid -> binding, shared across key partitions
	waiters  chan struct{}
}

type leader struct{ id int }

type binding struct {
	command            Command
	admitted, executed atomic.Bool
}

type incoming struct {
	from int
	msg  Message
}

type submission struct {
	cmd Command
	ctx context.Context
	out chan Result
	at  time.Time
}

func New(cfg Config, t Transport) (*Node, error) {
	if err := cfg.defaults(); err != nil {
		return nil, err
	}
	if t == nil {
		return nil, fmt.Errorf("transport is required")
	}
	n := &Node{
		cfg: cfg, link: t, stop: make(chan struct{}), hash: maphash.MakeSeed(),
		waiters: make(chan struct{}, cfg.MaxWaiters),
	}
	n.omega.Store(&leader{id: 0})
	for i := 0; i < cfg.Workers; i++ {
		w := newWorker(n, i)
		n.workers = append(n.workers, w)
	}
	for _, w := range n.workers {
		n.running.Add(1)
		go func() {
			defer n.running.Done()
			w.run()
		}()
	}
	return n, nil
}

func (n *Node) Close() {
	n.stopOnce.Do(func() { close(n.stop) })
	n.running.Wait()
}

func (n *Node) Stats() Stats {
	c := &n.count
	return Stats{
		Admitted: c.admitted.Load(), OriginDecided: c.decided.Load(), OriginExecuted: c.executed.Load(),
		Undecided: c.undecided.Load(), Inflight: c.inflight.Load(),
		Fast: c.fast.Load(), Formal: c.formal.Load(), Recovered: c.recovered.Load(),
		ShortWindows: c.windows.Load(), Invalid: c.invalid.Load(), Rejected: c.rejected.Load(),
		Sent: c.sent.Load(), Dropped: c.dropped.Load(), Fetch: c.fetch.Load(), Vertices: c.vertices.Load(),
		RIDConflicts: c.ridConflict.Load(), DecisionConflicts: c.decisionConflict.Load(),
		ParallelTasks: c.tasks.Load(), PeakParallel: c.overlap.Load(), AdmissionNS: c.admitNS.Load(),
		DecisionNS: c.decideNS.Load(), ExecutionNS: c.executeNS.Load(), ReplyNS: c.replyNS.Load(),
		Replies: c.replies.Load(), Omega: n.omega.Load().id,
	}
}

func (n *Node) worker(key string) *worker {
	return n.workers[maphash.String(n.hash, key)%uint64(len(n.workers))]
}

func (n *Node) Deliver(from int, m Message) bool {
	if from < 0 || from >= n.cfg.Members || m.Kind < PreAccept || m.Kind > NoticeAck {
		return false
	}
	select {
	case <-n.stop:
		return false
	default:
	}
	in := incoming{from, m}
	if m.Kind >= Heartbeat {
		return offer(n.workers[0].control, in)
	}
	if len(m.Key) == 0 || len(m.Key) > 1024 || !n.validID(m.X) {
		return false
	}
	w := n.worker(m.Key)
	if m.Kind == Fetch || m.Kind == Initial || m.Kind == Done || m.Kind == Learn || m.Kind == Stored {
		return offer(w.data, in)
	}
	return offer(w.inbox, in)
}

func offer[T any](ch chan T, v T) bool {
	select {
	case ch <- v:
		return true
	default:
		return false
	}
}

func (n *Node) validID(x ID) bool {
	return x.Replica >= 0 && x.Replica < n.cfg.Members && x.Number != 0
}

// Submit waits up to Config.Wait for a result, subject to the caller context.
// A queued request with a canceled context is dropped if cancellation is
// observed before admission. An admitted request always remains protocol work.
func (n *Node) Submit(ctx context.Context, cmd Command) Result {
	reject := func(reason string) Result {
		n.count.rejected.Add(1)
		return Result{Status: Rejected, Error: reason}
	}
	if !cmd.Valid() {
		return reject("invalid command")
	}
	if b := n.lookup(cmd.RID); b != nil {
		if b.command != cmd {
			return reject("request ID already bound to a different command")
		}
		if b.executed.Load() {
			return Result{Status: Duplicate}
		}
	}
	overload := func(reason string) Result {
		if b := n.lookup(cmd.RID); b != nil && b.command == cmd {
			if b.executed.Load() {
				return Result{Status: Duplicate}
			}
			if b.admitted.Load() {
				return Result{Status: Pending, Error: reason}
			}
		}
		return reject(reason)
	}
	select {
	case <-ctx.Done():
		return Result{Status: Unknown, Error: ctx.Err().Error()}
	case <-n.stop:
		return reject("node closed")
	case n.waiters <- struct{}{}:
	default:
		return overload("waiter limit")
	}
	defer func() { <-n.waiters }()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	s := &submission{cmd: cmd, ctx: ctx, out: make(chan Result, 2), at: n.cfg.Clock.Now()}
	if !offer(n.worker(cmd.Key).client, s) {
		return overload("admission queue full")
	}
	timer := time.NewTimer(n.cfg.Wait)
	defer timer.Stop()
	admitted := false
	for {
		var fallback Result
		timedOut := false
		select {
		case r := <-s.out:
			if r.Status != Pending {
				return r
			}
			admitted = true
			continue
		case <-ctx.Done():
			fallback = Result{Status: Unknown, Error: ctx.Err().Error()}
		case <-n.stop:
			fallback = Result{Status: Unknown, Error: "node closed while waiting"}
		case <-timer.C:
			timedOut = true
			fallback = Result{Status: Unknown, Error: "admission or result unconfirmed"}
		}
		// Prefer any result already prepared when the wait ends.
		for {
			select {
			case r := <-s.out:
				if r.Status != Pending {
					return r
				}
				admitted = true
			default:
				if admitted && timedOut {
					return Result{Status: Pending, Error: "admitted, still waiting"}
				}
				return fallback
			}
		}
	}
}

func (n *Node) lookup(id RID) *binding {
	if v, ok := n.bindings.Load(id); ok {
		return v.(*binding)
	}
	return nil
}

func (n *Node) bind(cmd Command) *binding {
	v, _ := n.bindings.LoadOrStore(cmd.RID, &binding{command: cmd})
	b := v.(*binding)
	if b.command != cmd {
		return nil
	}
	return b
}

func (n *Node) send(to int, m Message) bool {
	ok := false
	if to == n.cfg.Self {
		ok = n.Deliver(to, m)
	} else {
		ok = n.link.Send(to, m)
	}
	if ok {
		n.count.sent.Add(1)
	} else {
		n.count.dropped.Add(1)
	}
	return ok
}

func (n *Node) broadcast(m Message) {
	for to := 0; to < n.cfg.Members; to++ {
		n.send(to, m)
	}
}
