package consensus

import (
	"container/heap"
	"sort"
)

func (w *worker) linkExecution(x *instance) {
	for r, i := range x.decided.Deps {
		w.edge(x, ID{r, i})
	}
	prev := x.v0.Deps[x.id.Replica]
	if prev != x.decided.Deps[x.id.Replica] {
		w.edge(x, ID{x.id.Replica, prev})
	}
	w.runReady = append(w.runReady, x)
	w.runReady = append(w.runReady, x.graphWait...)
	x.graphWait = nil
	offer(w.ready, struct{}{})
}

func (w *worker) edge(x *instance, id ID) {
	if id.Number == 0 || id == x.id {
		return
	}
	y := x.c.records[id]
	if !y.executed {
		x.edges = append(x.edges, y)
		if y.decided == nil {
			w.expediteRecovery(y)
		}
	}
}

type vertex struct {
	x          *instance
	index, low int
	onStack    bool
}

type execution struct {
	*worker
	nodes map[*instance]*vertex
	stack []*vertex
}

func (w *worker) execute(x *instance) {
	if x.executed || x.failed || x.blocked != nil && (x.blocked.decided == nil || x.blocked.failed) {
		return
	}
	e := execution{worker: w, nodes: make(map[*instance]*vertex)}
	e.visit(x)
}

// Tarjan traversal leaves cross-edges on the stack while finding cycles. A
// blocked component remembers one necessary undecided vertex. New roots can
// stop there until that decision arrives instead of exploring the same suffix.
func (e *execution) visit(x *instance) {
	index := len(e.nodes)
	u := &vertex{x: x, index: index, low: index, onStack: true}
	e.nodes[x] = u
	e.stack = append(e.stack, u)
	e.count.vertices.Add(1)
	for _, y := range x.edges {
		if y.executed || y.failed || y.decided == nil || y.blocked != nil && (y.blocked.decided == nil || y.blocked.failed) {
			continue
		}
		p := e.nodes[y]
		if p == nil {
			e.visit(y)
			p = e.nodes[y]
			u.low = min(u.low, p.low)
		} else if p.onStack {
			u.low = min(u.low, p.index)
		}
	}
	if u.low != u.index {
		return
	}
	var component []*instance
	for {
		p := e.stack[len(e.stack)-1]
		e.stack = e.stack[:len(e.stack)-1]
		p.onStack = false
		component = append(component, p.x)
		if p == u {
			break
		}
	}
	var blocker *instance
	for _, z := range component {
		for _, y := range z.edges {
			switch {
			case y.executed:
			case y.decided == nil || y.failed:
				blocker = y
			case y.blocked != nil && (y.blocked.decided == nil || y.blocked.failed):
				blocker = y.blocked
			}
			if blocker != nil {
				break
			}
		}
		if blocker != nil {
			break
		}
	}
	if blocker != nil {
		for _, z := range component {
			z.blocked = blocker
			if !blocker.failed {
				blocker.graphWait = append(blocker.graphWait, z)
			}
		}
		return
	}
	e.apply(component)
}

func (w *worker) apply(component []*instance) {
	sort.Slice(component, func(i, j int) bool {
		x, y := component[i], component[j]
		if x.decided.Seq != y.decided.Seq {
			return x.decided.Seq < y.decided.Seq
		}
		if x.id.Replica != y.id.Replica {
			return x.id.Replica < y.id.Replica
		}
		return x.id.Number < y.id.Number
	})
	c := component[0].c
	for _, x := range component {
		if x.binding == nil {
			w.count.ridConflict.Add(1)
			for _, z := range component {
				z.failed = true
			}
			// Out-of-model conflicting inputs must not apply partial SCCs.
			return
		}
	}
	type reply struct {
		s *submission
		r Result
	}
	var replies []reply
	for _, x := range component {
		cmd := x.v0.Command
		r := Result{Status: Duplicate}
		if _, ok := c.executed[cmd.RID]; !ok {
			r.Status = Applied
			switch cmd.Op {
			case "put":
				c.value, c.found = cmd.Value, true
			case "get":
				r.Found, r.Value = c.found, c.value
			case "delete":
				r.Found = c.found
				c.value, c.found = "", false
			}
			c.executed[cmd.RID] = struct{}{}
		}
		if local := c.local[cmd.RID]; local != nil {
			for _, s := range local.waiters {
				if s.ctx.Err() == nil {
					replies = append(replies, reply{s, r})
				}
			}
			local.waiters = nil
		}
	}
	now := w.now()
	for _, x := range component {
		x.executed = true
		x.edges, x.blocked = nil, nil
		heap.Remove(&c.deadlines, x.deadlineIdx)
		if x.overdue {
			x.overdue = false
			c.overdue--
		}
		if x.local {
			w.count.inflight.Add(^uint64(0))
			w.count.executed.Add(1)
			w.count.executeNS.Add(ns(now.Sub(x.decisionAt)))
		}
		w.trace("execute", x.id, Done)
		w.schedule(x)
	}
	for _, x := range component {
		x.binding.executed.Store(true)
	}
	for _, reply := range replies {
		w.count.replyNS.Add(ns(w.now().Sub(reply.s.at)))
		w.count.replies.Add(1)
		reply.s.out <- reply.r
	}
}
