package consensus

type helpKey struct {
	origin  int
	other   ID
	ballot  Ballot
	attempt uint64
}

type validation struct {
	attempt    uint64
	cursor     []uint64
	member     int
	unresolved map[*instance]struct{}
}

func covers(x *instance, v *Value, y *instance) bool {
	return x != y && x.c == y.c && y.id.Number <= v.Deps[y.id.Replica]
}

func (w *worker) clearValidation(x *instance, v *validation) {
	for y := range v.unresolved {
		delete(y.validators, x)
	}
}

func (w *worker) rebuild(x *instance) {
	if t := w.current(x); t != nil && t.frozen == nil {
		if t.validation != nil {
			w.clearValidation(x, t.validation)
			t.validation = nil
		}
		w.start(x, Observe, x.v0)
	}
}

func (w *worker) force(x, y *instance) {
	if x.forced == nil {
		x.forced = copyValue(x.v0)
	}
	x.forced.Deps[y.id.Replica] = max(x.forced.Deps[y.id.Replica], y.id.Number)
	x.forced.Seq = max(x.forced.Seq, y.v0.Seq+1)
}

func (w *worker) progressValidation(x *instance) {
	t := w.current(x)
	if t == nil || t.validation == nil {
		return
	}
	if x.noFast {
		w.rebuild(x)
		return
	}
	v := t.validation
	if v.cursor == nil {
		return
	}
	for steps := 0; steps < 64 && v.member < w.cfg.Members; steps++ {
		r := v.member
		i := v.cursor[r]
		if i == x.v0.Deps[r] {
			v.member++
			continue
		}
		y := x.c.records[ID{r, i}]
		if i < x.v0.Deps[r] || y == nil || !y.registered {
			// The complete scan replies must have saved every representative
			// and the whole initial closure before being counted.
			w.count.invalid.Add(1)
			w.stopTask(x)
			return
		}
		v.cursor[r] = y.v0.Deps[r]
		if y != x && !covers(y, y.v0, x) {
			if y.decided != nil {
				if !covers(y, y.decided, x) {
					w.force(x, y)
					x.noFast = true
					w.rebuild(x)
					return
				}
			} else {
				if v.unresolved == nil {
					v.unresolved = make(map[*instance]struct{})
				}
				v.unresolved[y] = struct{}{}
				if y.validators == nil {
					y.validators = make(map[*instance]*validation)
				}
				y.validators[x] = v
				w.askHelp(x, y, t)
			}
		}
	}
	if v.member < w.cfg.Members {
		w.validateReady = append(w.validateReady, x)
		offer(w.ready, struct{}{})
	} else if len(v.unresolved) == 0 {
		w.freeze(x, x.v0)
	}
}

func (w *worker) askHelp(x, y *instance, t *task) {
	w.trace("help", x.id, Help)
	w.send(w.omega.Load().id, Message{
		Kind: Help, X: y.id, Key: x.c.key, Other: x.id, Init: y.v0, Value: x.v0,
		Ballot: t.ballot, Attempt: t.validation.attempt, Strong: true, Origin: w.cfg.Self,
	})
	w.expediteRecovery(y)
}

func (w *worker) notifyValidators(y *instance) {
	for x, v := range y.validators {
		delete(y.validators, x)
		delete(v.unresolved, y)
		if t := w.current(x); t != nil && t.validation == v {
			if !covers(y, y.decided, x) && !covers(y, y.v0, x) {
				x.noFast = true
				w.force(x, y)
			}
			w.progressValidation(x)
		}
	}
}

func (w *worker) receiveHelp(in incoming, y *instance) {
	m := in.msg
	if m.Origin < 0 || m.Origin >= w.cfg.Members || m.Ballot.Owner != m.Origin || m.Ballot.Round == 0 ||
		m.Attempt == 0 || !w.validID(m.Other) || m.Other == y.id || m.Value == nil ||
		!w.validInitial(m.Other, y.c.key, m.Value) {
		return
	}
	x := w.instance(y.c, m.Other)
	if !w.saveInitial(x, m.Value) || !x.registered || !y.registered {
		// The live validation task retries HELP while evidence is unavailable.
		w.fetch(y)
		return
	}
	if y.decided != nil {
		w.send(m.Origin, w.decisionMessage(y, Done))
		return
	}
	if covers(y, y.v0, x) {
		w.send(m.Origin, helpResponse(m, HelpInitial, y.v0))
		return
	}
	if covers(x, x.v0, y) {
		return
	}
	if y.strong {
		w.send(m.Origin, helpResponse(m, HelpStrong, y.v0))
		return
	}
	if !m.Strong {
		return
	}
	y.noFast = true
	omega := w.omega.Load().id
	t := w.current(y)
	key := helpKey{m.Origin, x.id, m.Ballot, m.Attempt}
	if y.help == nil {
		y.help = make(map[helpKey]incoming)
	}
	_, exists := y.help[key]
	y.help[key] = in
	if omega != w.cfg.Self {
		if !exists {
			w.send(omega, m)
		}
		return
	}
	if t != nil && t.frozen != nil {
		return
	}
	w.force(y, x)
	y.pendingRecovery = true
	w.kick(y)
	w.progressValidation(y)
}

func helpResponse(m Message, kind Kind, v *Value) Message {
	return Message{Kind: kind, X: m.X, Other: m.Other, Key: m.Key, Init: v,
		Ballot: m.Ballot, Attempt: m.Attempt, Origin: m.Origin}
}

func (w *worker) helpReply(in incoming, y *instance) {
	m := in.msg
	x := y.c.records[m.Other]
	if x == nil || !y.registered || m.Origin != w.cfg.Self {
		return
	}
	t := w.current(x)
	if t == nil || t.validation == nil || t.ballot != m.Ballot || t.validation.attempt != m.Attempt {
		return
	}
	if _, ok := t.validation.unresolved[y]; !ok {
		return
	}
	if covers(y, y.v0, x) {
		delete(y.validators, x)
		delete(t.validation.unresolved, y)
	} else if m.Kind == HelpStrong && !covers(x, x.v0, y) {
		x.noFast = true
		w.force(x, y)
	}
	w.progressValidation(x)
}

func (w *worker) retryHelp(y *instance) {
	omega := w.omega.Load().id
	for _, h := range y.help {
		if omega != w.cfg.Self {
			w.send(omega, h.msg)
		} else {
			w.receiveHelp(h, y)
		}
	}
}

func (w *worker) answerHelp(y *instance) {
	for key, h := range y.help {
		m := w.decisionMessage(y, Done)
		m.Other, m.Ballot, m.Attempt = h.msg.Other, h.msg.Ballot, h.msg.Attempt
		w.send(key.origin, m)
	}
	y.help = nil
}
