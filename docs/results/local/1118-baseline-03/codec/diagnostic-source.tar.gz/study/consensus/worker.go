package consensus

import (
	"container/heap"
	"math"
	"sync/atomic"
	"time"
)

type class struct {
	key       string
	records   map[ID]*instance
	heads     [][2]*instance
	local     map[RID]*instance
	executed  map[RID]struct{}
	value     string
	found     bool
	overdue   int
	deadlines deadlineHeap
}

type instance struct {
	id                                           ID
	binding                                      *binding
	c                                            *class
	v0, decided, pendingDone                     *Value
	registered, executed, overdue, local, failed bool
	regAt, admitAt, decisionAt                   time.Time
	promise                                      Ballot
	first                                        *First
	accepted                                     *Accepted
	task                                         *task
	prePending                                   [2]*incoming
	deferred                                     map[messageSlot]*deferredMessage
	deferredWait                                 map[*deferredMessage]struct{}
	rounds                                       map[uint64]Message // only the identity fields of each issued request
	nonce, attempt                               uint64
	noFast, strong                               bool
	forced                                       *Value
	pendingRecovery                              bool
	recoverAt, retryAt, fetchedAt, neededAt      time.Time
	waiters                                      []*submission
	hasInitial, hasDecision                      []bool
	initMissing                                  int
	registerWait                                 []*instance
	checkWait                                    []*instance
	doneWaiting                                  int
	doneSenders                                  []bool
	validators                                   map[*instance]*validation
	help                                         map[helpKey]incoming
	graphWait                                    []*instance
	blocked                                      *instance
	edges                                        []*instance
	gossipBackoff                                time.Duration
	timerIdx, deadlineIdx                        int
	when                                         time.Time
}

type dueHeap []*instance

func (h dueHeap) Len() int           { return len(h) }
func (h dueHeap) Less(i, j int) bool { return h[i].when.Before(h[j].when) }
func (h dueHeap) Swap(i, j int)      { h[i], h[j] = h[j], h[i]; h[i].timerIdx = i; h[j].timerIdx = j }
func (h *dueHeap) Push(v any)        { x := v.(*instance); x.timerIdx = len(*h); *h = append(*h, x) }
func (h *dueHeap) Pop() any {
	a := *h
	x := a[len(a)-1]
	a[len(a)-1] = nil
	*h = a[:len(a)-1]
	x.timerIdx = -1
	return x
}

type worker struct {
	*Node
	index                int
	inbox, data, control chan incoming
	client               chan *submission
	classes              map[string]*class
	regReady             []*instance
	checkReady           []*instance
	runReady             []*instance
	validateReady        []*instance
	messageReady         []*deferredMessage
	timers               dueHeap
	detector             *detector
	ready                chan struct{}
	turn                 int
}

func newWorker(n *Node, index int) *worker {
	w := &worker{
		Node: n, index: index, inbox: make(chan incoming, n.cfg.Queue), data: make(chan incoming, n.cfg.Queue),
		client: make(chan *submission, n.cfg.Queue), classes: make(map[string]*class), ready: make(chan struct{}, 1),
	}
	if index == 0 {
		w.control = make(chan incoming, n.cfg.Queue)
		w.detector = newDetector(w)
	}
	return w
}

func (w *worker) now() time.Time { return w.cfg.Clock.Now() }

func (w *worker) trace(stage string, x ID, kind Kind) {
	if f := w.cfg.Trace; f != nil {
		f(Event{At: w.now(), Stage: stage, Worker: w.index, X: x, Kind: kind})
	}
}

func (w *worker) run() {
	ticker := w.cfg.Clock.NewTicker(w.cfg.Tick)
	defer ticker.Stop()
	for {
		select {
		case <-w.stop:
			return
		default:
		}
		select {
		case <-w.stop:
			return
		case <-ticker.C():
			w.tick()
		case <-w.ready:
			w.background()
		case in := <-w.control:
			w.detector.receive(in)
		case in := <-w.data:
			w.handle(in)
		case in := <-w.inbox:
			w.handle(in)
		case s := <-w.client:
			w.admit(s)
		}
	}
}

func (w *worker) tick() {
	now := w.now()
	if w.detector != nil {
		w.detector.tick(now)
	}
	for i := 0; i < 64 && len(w.timers) > 0 && !w.timers[0].when.After(now); i++ {
		x := heap.Pop(&w.timers).(*instance)
		w.timer(x, now)
		w.schedule(x)
	}
}

func (w *worker) class(key string) *class {
	c := w.classes[key]
	if c == nil {
		c = &class{
			key: key, records: make(map[ID]*instance), heads: make([][2]*instance, w.cfg.Members),
			local: make(map[RID]*instance), executed: make(map[RID]struct{}),
		}
		w.classes[key] = c
	}
	return c
}

func (w *worker) instance(c *class, id ID) *instance {
	x := c.records[id]
	if x == nil {
		now := w.now()
		x = &instance{id: id, c: c, timerIdx: -1, deadlineIdx: -1, recoverAt: now.Add(w.cfg.RecoveryDelay), retryAt: now.Add(w.cfg.Retry)}
		c.records[id] = x
		w.schedule(x)
	}
	return x
}

func (c *class) scan(cmd Command, exclude *instance) *Value {
	v := &Value{Command: cmd, Seq: 1, Deps: make([]uint64, len(c.heads))}
	for r, pair := range c.heads {
		p := pair[0]
		if p == exclude {
			p = pair[1]
		}
		if p != nil {
			v.Deps[r] = p.id.Number
			v.Seq = max(v.Seq, p.v0.Seq+1)
		}
	}
	return v
}

func (w *worker) register(x *instance) {
	if x.registered {
		return
	}
	x.registered = true
	x.regAt = w.now()
	heap.Push(&x.c.deadlines, x)
	pair := &x.c.heads[x.id.Replica]
	switch {
	case pair[0] == nil || pair[0].id.Number < x.id.Number:
		pair[1], pair[0] = pair[0], x
	case pair[1] == nil || pair[1].id.Number < x.id.Number:
		pair[1] = x
	}
	x.hasInitial = make([]bool, w.cfg.Members)
	x.hasInitial[w.cfg.Self] = true
	w.trace("register", x.id, Initial)
	for i, in := range x.prePending {
		if in != nil {
			x.prePending[i] = nil
			w.request(*in, x)
		}
	}
	for _, p := range x.registerWait {
		p.initMissing--
		if p.initMissing == 0 {
			w.regReady = append(w.regReady, p)
		}
	}
	x.registerWait = nil
	w.deferredRegistered(x)
	w.wakeChecks(x)
	w.schedule(x)
}

func (w *worker) wakeChecks(x *instance) {
	w.checkReady = append(w.checkReady, x.checkWait...)
	x.checkWait = nil
	offer(w.ready, struct{}{})
}

func (w *worker) background() {
	for done, empty := 0, 0; done < 32 && empty < 5; {
		progress := false
		switch w.turn {
		case 0:
			if len(w.regReady) > 0 {
				x := pop(&w.regReady)
				w.register(x)
				w.kick(x)
				progress = true
			}
		case 1:
			if len(w.checkReady) > 0 {
				x := pop(&w.checkReady)
				x.doneWaiting--
				w.checkDecision(x)
				w.kick(x)
				progress = true
			}
		case 2:
			if len(w.validateReady) > 0 {
				w.progressValidation(pop(&w.validateReady))
				progress = true
			}
		case 3:
			if len(w.runReady) > 0 {
				w.execute(pop(&w.runReady))
				progress = true
			}
		case 4:
			if len(w.messageReady) > 0 {
				d := pop(&w.messageReady)
				if d.x.deferred[d.slot] == d {
					w.removeDeferred(d)
					w.handle(d.in)
				}
				progress = true
			}
		}
		w.turn = (w.turn + 1) % 5
		if progress {
			done++
			empty = 0
		} else {
			empty++
		}
	}
	if len(w.regReady)+len(w.checkReady)+len(w.validateReady)+len(w.runReady)+len(w.messageReady) == 0 {
		return
	}
	offer(w.ready, struct{}{})
}

func pop[T any](q *[]T) T {
	a := *q
	x := a[0]
	var zero T
	a[0] = zero
	*q = a[1:]
	return x
}

func (w *worker) admit(s *submission) {
	reject := func(reason string) {
		w.count.rejected.Add(1)
		s.out <- Result{Status: Rejected, Error: reason}
	}
	if s.ctx.Err() != nil {
		return
	}
	if b := w.lookup(s.cmd.RID); b != nil && b.command != s.cmd {
		reject("request ID already bound to a different command")
		return
	}
	c := w.classes[s.cmd.Key]
	if c != nil {
		if _, ok := c.executed[s.cmd.RID]; ok {
			s.out <- Result{Status: Duplicate}
			return
		}
		if x := c.local[s.cmd.RID]; x != nil {
			x.waiters = liveWaiters(x.waiters)
			if len(x.waiters) >= w.cfg.MaxWaiters {
				s.out <- Result{Status: Pending, Error: "request waiter limit"}
				return
			}
			w.attach(x, s)
			return
		}
		if c.overdue != 0 || w.classOverdue(c, w.now()) {
			reject("class has overdue work")
			return
		}
	}
	// Reserve capacity before allocating any class or instance state.
	for {
		q := w.count.inflight.Load()
		if q >= uint64(w.cfg.MaxInflight) {
			reject("local inflight limit")
			return
		}
		if w.count.inflight.CompareAndSwap(q, q+1) {
			break
		}
	}
	b := w.bind(s.cmd)
	if b == nil {
		w.count.inflight.Add(^uint64(0))
		reject("request ID already bound to a different command")
		return
	}
	if c == nil {
		c = w.class(s.cmd.Key)
	}
	id := ID{w.cfg.Self, w.Node.index.Add(1)}
	x := w.instance(c, id)
	x.local, x.binding = true, b
	b.admitted.Store(true)
	x.admitAt = w.now()
	x.v0 = c.scan(s.cmd, nil)
	w.Node.ids.Store(id, c.key)
	x.first = &First{Suggestion: x.v0, Fast: true}
	c.local[s.cmd.RID] = x
	w.count.admitted.Add(1)
	w.count.undecided.Add(1)
	w.count.admitNS.Add(ns(x.admitAt.Sub(s.at)))
	w.register(x)
	w.attach(x, s)
	x.task = &task{fast: map[int]bool{w.cfg.Self: true}}
	w.trace("admit", id, PreAccept)
	w.start(x, PreAccept, x.v0)
	w.maybeFast(x)
	w.schedule(x)
}

func (w *worker) attach(x *instance, s *submission) {
	x.waiters = append(x.waiters, s)
	s.out <- Result{Status: Pending}
}

func liveWaiters(list []*submission) []*submission {
	i := 0
	for _, s := range list {
		if s.ctx.Err() == nil {
			list[i] = s
			i++
		}
	}
	clear(list[i:])
	return list[:i]
}

func ns(d time.Duration) uint64 { return uint64(max(d, 0)) }

func all(bits []bool) bool {
	for _, b := range bits {
		if !b {
			return false
		}
	}
	return true
}

func earlier(a, b time.Time) time.Time {
	if a.IsZero() || !b.IsZero() && b.Before(a) {
		return b
	}
	return a
}

func (w *worker) schedule(x *instance) {
	when := time.Time{}
	if x.decided == nil {
		when = x.recoverAt
	}
	if x.registered && !x.executed && !x.overdue {
		when = earlier(when, x.regAt.Add(w.cfg.Overdue))
	}
	if !x.registered || !all(x.hasInitial) || x.decided != nil && !all(x.hasDecision) ||
		x.task != nil || x.pendingDone != nil || len(x.help) != 0 {
		when = earlier(when, x.retryAt)
	}
	if t := x.task; t != nil {
		if col := t.collect; col != nil && !col.windowChecked {
			when = earlier(when, col.deadline)
		}
		if t.pre != nil && !t.pre.slowReady {
			when = earlier(when, t.pre.deadline)
		}
	}
	if when.IsZero() {
		if x.timerIdx >= 0 {
			heap.Remove(&w.timers, x.timerIdx)
		}
		return
	}
	x.when = when
	if x.timerIdx >= 0 {
		heap.Fix(&w.timers, x.timerIdx)
	} else {
		heap.Push(&w.timers, x)
	}
}

func (w *worker) timer(x *instance, now time.Time) {
	if x.registered && !x.executed && !x.overdue && !now.Before(x.regAt.Add(w.cfg.Overdue)) {
		x.overdue = true
		x.c.overdue++
	}
	w.current(x)
	if x.decided == nil && !now.Before(x.recoverAt) {
		x.recoverAt = now.Add(w.cfg.Retry)
		w.requestRecovery(x)
	}
	if t := x.task; t != nil {
		if col := t.collect; col != nil && !col.windowChecked && !now.Before(col.deadline) {
			col.windowChecked = true
			if len(col.a) < w.cfg.Members-w.cfg.F-w.cfg.S {
				w.count.windows.Add(1)
			}
			w.advanceCollect(x)
		}
		if x.task == t && t.pre != nil && !now.Before(t.pre.deadline) {
			t.pre.slowReady = true
			w.slow(x)
		}
	}
	if now.Before(x.retryAt) {
		return
	}
	if x.decided != nil {
		if x.gossipBackoff == 0 {
			x.gossipBackoff = w.cfg.Retry
		}
		x.retryAt = now.Add(x.gossipBackoff)
		if x.gossipBackoff < scaled(w.cfg.Retry, 16) && x.gossipBackoff < time.Second {
			x.gossipBackoff *= 2
		}
	} else {
		x.retryAt = now.Add(w.cfg.Retry)
	}
	x.waiters = liveWaiters(x.waiters)
	if !x.registered {
		w.fetch(x)
	} else {
		w.gossip(x)
	}
	w.retryCoordination(x)
	w.retryHelp(x)
	w.checkDecision(x)
	w.kick(x)
}

func (w *worker) classOverdue(c *class, now time.Time) bool {
	// Each class keeps its earliest unexecuted deadline in a separate heap.
	return len(c.deadlines) != 0 && !now.Before(c.deadlines[0].regAt.Add(w.cfg.Overdue))
}

func incrementPeak(peak *atomic.Uint64, n uint64) {
	for old := peak.Load(); n > old && !peak.CompareAndSwap(old, n); old = peak.Load() {
	}
}

func timeout(window time.Duration, count uint64) time.Duration {
	limit := uint64(math.MaxInt64 / int64(window))
	if limit < 2 || count >= limit-2 {
		return time.Duration(math.MaxInt64)
	}
	return time.Duration(count+2) * window
}

type deadlineHeap []*instance

func (h deadlineHeap) Len() int           { return len(h) }
func (h deadlineHeap) Less(i, j int) bool { return h[i].regAt.Before(h[j].regAt) }
func (h deadlineHeap) Swap(i, j int) {
	h[i], h[j] = h[j], h[i]
	h[i].deadlineIdx = i
	h[j].deadlineIdx = j
}
func (h *deadlineHeap) Push(v any) { x := v.(*instance); x.deadlineIdx = len(*h); *h = append(*h, x) }
func (h *deadlineHeap) Pop() any {
	a := *h
	x := a[len(a)-1]
	a[len(a)-1] = nil
	*h = a[:len(a)-1]
	x.deadlineIdx = -1
	return x
}
