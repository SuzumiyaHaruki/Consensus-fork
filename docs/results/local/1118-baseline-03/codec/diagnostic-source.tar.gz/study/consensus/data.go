package consensus

func (w *worker) validInitial(id ID, key string, v *Value) bool {
	return v.Command.Key == key && v.Command.Valid() && len(v.Deps) == w.cfg.Members &&
		v.Seq > 0 && v.Deps[id.Replica] < id.Number
}

func (w *worker) saveInitial(x *instance, v *Value) bool {
	if x.v0 != nil {
		if !Equal(x.v0, v) {
			w.count.invalid.Add(1)
			return false
		}
		return true
	}
	for r, i := range v.Deps {
		if i != 0 {
			if key, ok := w.Node.ids.Load(ID{r, i}); ok && key != x.c.key {
				w.count.invalid.Add(1)
				return false
			}
		}
	}
	if key, _ := w.Node.ids.LoadOrStore(x.id, x.c.key); key != x.c.key {
		w.count.invalid.Add(1)
		return false
	}
	x.binding = w.bind(v.Command)
	if x.binding == nil {
		w.count.ridConflict.Add(1)
		// A contradictory globally reused ID violates the client model. Retain
		// immutable protocol data to avoid hiding a later dependency on it.
	}
	x.v0 = v
	for r, i := range v.Deps {
		if i == 0 {
			continue
		}
		p := w.instance(x.c, ID{r, i})
		if !p.registered {
			x.initMissing++
			p.registerWait = append(p.registerWait, x)
			w.fetch(p)
		}
	}
	if x.initMissing == 0 {
		w.register(x)
	}
	w.schedule(x)
	return true
}

func (w *worker) fetch(x *instance) {
	if x.registered || x.v0 != nil {
		return
	}
	now := w.now()
	if !x.fetchedAt.IsZero() && now.Before(x.fetchedAt.Add(w.cfg.Retry)) {
		return
	}
	x.fetchedAt = now
	m := Message{Kind: Fetch, X: x.id, Key: x.c.key}
	w.count.fetch.Add(1)
	for i := 0; i < w.cfg.Members; i++ {
		if i != w.cfg.Self {
			w.send(i, m)
		}
	}
}

func (w *worker) serveData(to int, x *instance) {
	if !x.registered {
		return
	}
	if x.decided != nil {
		w.send(to, w.decisionMessage(x, Done))
	} else {
		w.send(to, Message{Kind: Initial, X: x.id, Key: x.c.key, Init: x.v0})
	}
}

func (w *worker) stored(to int, x *instance) {
	w.send(to, Message{Kind: Stored, X: x.id, Key: x.c.key, HasDone: x.decided != nil})
}

func (w *worker) gossip(x *instance) {
	for p := 0; p < w.cfg.Members; p++ {
		if x.decided != nil && !x.hasDecision[p] {
			w.send(p, w.decisionMessage(x, Done))
		} else if !x.hasInitial[p] {
			w.send(p, Message{Kind: Initial, X: x.id, Key: x.c.key, Init: x.v0})
		}
	}
}

// missing returns the direct unavailable representatives. Registration itself
// guarantees that each representative's initial closure has been saved.
func (w *worker) missing(x *instance, v *Value) ([]*instance, bool) {
	if v == nil || v.Command.Key != x.c.key || !v.Command.Valid() || v.Seq == 0 ||
		len(v.Deps) != w.cfg.Members {
		w.count.invalid.Add(1)
		return nil, false
	}
	if x.v0 == nil {
		w.fetch(x)
		return []*instance{x}, true
	}
	if v.Command != x.v0.Command || v.Seq < x.v0.Seq {
		w.count.invalid.Add(1)
		return nil, false
	}
	var missing []*instance
	if !x.registered {
		missing = append(missing, x)
	}
	for r, i := range v.Deps {
		if i < x.v0.Deps[r] {
			w.count.invalid.Add(1)
			return nil, false
		}
		if i == 0 || (ID{r, i}) == x.id {
			continue
		}
		id := ID{r, i}
		if key, ok := w.Node.ids.Load(id); ok && key != x.c.key {
			w.count.invalid.Add(1)
			return nil, false
		}
		p := w.instance(x.c, id)
		if !p.registered {
			missing = append(missing, p)
			w.fetch(p)
		}
	}
	return missing, true
}

func (w *worker) receiveDecision(from int, x *instance, v *Value) {
	if v == nil {
		w.count.invalid.Add(1)
		return
	}
	if x.decided != nil {
		if !Equal(x.decided, v) {
			w.count.decisionConflict.Add(1)
			return
		}
		x.hasInitial[from], x.hasDecision[from] = true, true
		w.stored(from, x)
		return
	}
	if x.pendingDone != nil && !Equal(x.pendingDone, v) {
		w.count.decisionConflict.Add(1)
		return
	}
	if x.pendingDone == nil {
		x.pendingDone = v
		x.doneSenders = make([]bool, w.cfg.Members)
	}
	x.doneSenders[from] = true
	w.checkDecision(x)
}

func (w *worker) checkDecision(x *instance) {
	if x.pendingDone == nil || x.doneWaiting != 0 {
		return
	}
	v := x.pendingDone
	missing, ok := w.missing(x, v)
	if !ok {
		x.pendingDone, x.doneSenders = nil, nil
		return
	}
	if len(missing) != 0 {
		for _, p := range missing {
			p.checkWait = append(p.checkWait, x)
		}
		x.doneWaiting = len(missing)
		return
	}
	senders := x.doneSenders
	x.pendingDone, x.doneSenders = nil, nil
	w.learn(x, v)
	for p, has := range senders {
		if has {
			x.hasDecision[p], x.hasInitial[p] = true, true
			w.stored(p, x)
		}
	}
}

func (w *worker) decisionMessage(x *instance, kind Kind) Message {
	return Message{Kind: kind, X: x.id, Key: x.c.key, Init: x.v0, Value: x.decided}
}

func (w *worker) decide(x *instance, v *Value, fast bool) {
	if x.decided != nil {
		return
	}
	if fast {
		w.count.fast.Add(1)
	} else {
		w.count.formal.Add(1)
		if x.task.ballot.Round > 0 {
			w.count.recovered.Add(1)
		}
	}
	w.learn(x, v)
	w.broadcast(w.decisionMessage(x, Learn))
}

func (w *worker) learn(x *instance, v *Value) {
	if x.decided != nil {
		if !Equal(x.decided, v) {
			w.count.decisionConflict.Add(1)
		}
		return
	}
	x.decided, x.decisionAt = v, w.now()
	x.retryAt = x.decisionAt.Add(w.cfg.Retry)
	x.hasDecision = make([]bool, w.cfg.Members)
	x.hasDecision[w.cfg.Self] = true
	w.stopTask(x)
	x.pendingRecovery = false
	x.forced = nil
	w.answerHelp(x)
	w.notifyValidators(x)
	if x.local {
		w.count.undecided.Add(^uint64(0))
		w.count.decided.Add(1)
		w.count.decideNS.Add(ns(x.decisionAt.Sub(x.admitAt)))
	}
	w.trace("decide", x.id, Done)
	w.linkExecution(x)
	w.schedule(x)
}

func (w *worker) requestRecovery(x *instance) {
	if x.decided != nil {
		return
	}
	omega := w.omega.Load()
	if omega.id == w.cfg.Self {
		x.pendingRecovery = true
		w.kick(x)
	} else {
		w.send(omega.id, Message{Kind: NeedRecover, X: x.id, Key: x.c.key})
	}
}

func (w *worker) kick(x *instance) {
	if x.decided != nil || !x.pendingRecovery || !x.registered {
		return
	}
	omega := w.omega.Load()
	if omega.id != w.cfg.Self {
		return
	}
	if t := w.current(x); t != nil && (t.ballot.Round != 0 || w.now().Before(x.admitAt.Add(w.cfg.RecoveryDelay))) {
		return
	}
	b := Ballot{Round: x.promise.Round + 1, Owner: w.cfg.Self}
	w.raise(x, b)
	x.task = &task{ballot: b, leader: omega}
	w.trace("recover", x.id, Prepare)
	w.start(x, Prepare, x.v0)
}

func (w *worker) expediteRecovery(x *instance) {
	if x.decided != nil || w.now().Before(x.neededAt.Add(w.cfg.Retry)) {
		return
	}
	x.neededAt = w.now()
	w.requestRecovery(x)
}

type messageSlot struct {
	from          int
	kind, request Kind
	phase         uint8
}

type deferredMessage struct {
	in   incoming
	slot messageSlot
	x    *instance
	refs []*instance
	wait int
}

// A slot retains only the newest nonce for a given sender, phase and handler.
// Votes are additionally pruned when their collection or coordinator stops.
func (w *worker) deferMessage(in incoming, x *instance, refs []*instance) {
	m := in.msg
	slot := messageSlot{in.from, m.Kind, m.Request, m.Phase}
	if old := x.deferred[slot]; old != nil {
		if old.in.msg.Nonce >= m.Nonce {
			return
		}
		w.removeDeferred(old)
	}
	if x.deferred == nil {
		x.deferred = make(map[messageSlot]*deferredMessage)
	}
	d := &deferredMessage{in: in, x: x, slot: slot}
	x.deferred[slot] = d
	for _, p := range refs {
		if p.deferredWait == nil {
			p.deferredWait = make(map[*deferredMessage]struct{})
		}
		if _, ok := p.deferredWait[d]; !ok {
			p.deferredWait[d] = struct{}{}
			d.wait++
			d.refs = append(d.refs, p)
		}
	}
}

func (w *worker) removeDeferred(d *deferredMessage) {
	delete(d.x.deferred, d.slot)
	for _, p := range d.refs {
		delete(p.deferredWait, d)
	}
	if len(d.x.deferred) == 0 {
		d.x.deferred = nil
	}
}

func (w *worker) deferredRegistered(x *instance) {
	for d := range x.deferredWait {
		d.wait--
		if d.wait == 0 {
			w.messageReady = append(w.messageReady, d)
		}
	}
	x.deferredWait = nil
}

func (w *worker) pruneVotes(x *instance) {
	for slot, d := range x.deferred {
		if slot.kind != Vote {
			continue
		}
		t := x.task
		if t == nil || slot.request != PreAccept &&
			(t.collect == nil || t.collect.req.Nonce != d.in.msg.Nonce) {
			w.removeDeferred(d)
		}
	}
}
