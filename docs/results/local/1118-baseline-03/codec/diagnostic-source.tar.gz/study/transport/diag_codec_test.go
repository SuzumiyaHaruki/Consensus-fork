package transport

import (
	"bytes"
	"encoding/binary"
	c "example.com/mixepaxos/consensus"
	w "example.com/mixepaxos/wirepb"
	"fmt"
	"google.golang.org/protobuf/proto"
	"reflect"
	"strings"
	"testing"
)

func sampleMessage(i, valueBytes int) c.Message {
	k := fmt.Sprintf("load/%09d", 9000+i)
	id := c.ID{Replica: i % 7, Number: uint64(1200 + i)}
	v := &c.Value{Command: c.Command{RID: c.RID{Client: strings.Repeat("cafe1234", 8), Seq: uint64(i + 9001)}, Op: "put", Key: k, Value: strings.Repeat("v", valueBytes)}, Deps: make([]uint64, 7), Seq: 1}
	m := c.Message{X: id, Key: k}
	// 6 PreAccept, 6 Vote, 6 Learn, 18 Done, 24 Stored in each cycle.
	switch (i * 7) % 60 {
	case 0, 1, 2, 3, 4, 5:
		m.Kind = c.PreAccept
		m.Attempt = 1
		m.Phase = 1
		m.Nonce = 1
		m.Init = v
		m.Value = v
	case 6, 7, 8, 9, 10, 11:
		m.Kind = c.Vote
		m.Request = c.PreAccept
		m.Attempt = 1
		m.Phase = 1
		m.Nonce = 1
		m.First = &c.First{Suggestion: v, Fast: true}
	case 12, 13, 14, 15, 16, 17:
		m.Kind = c.Learn
		m.Init = v
		m.Value = v
	default:
		if (i*7)%60 < 36 {
			m.Kind = c.Done
			m.Init = v
			m.Value = v
		} else {
			m.Kind = c.Stored
			m.HasDone = true
		}
	}
	return m
}
func TestCodecRoundTrip(t *testing.T) {
	full := sampleMessage(60, 16)
	full.Ballot = c.Ballot{Round: 17, Owner: 2}
	full.Other = c.ID{Replica: 5, Number: 37}
	full.Record = &c.Accepted{Ballot: full.Ballot, Value: full.Init}
	full.Higher = full.Ballot
	full.Witnesses = []int{0, 2, 4}
	full.Strong = true
	full.Notice = 2
	full.Number = 56
	full.Origin = 2
	full.Subject = 4
	for _, mode := range []string{"gob", "json", "reuse", "proto"} {
		var buf bytes.Buffer
		encode, decode := frameWriter(&buf, mode), frameReader(&buf, mode)
		for i := 0; i < 60; i++ {
			a := []c.Message{sampleMessage(i, 16), full}
			if err := encode(a); err != nil {
				t.Fatal(err)
			}
			var b []c.Message
			if err := decode(&b); err != nil || !reflect.DeepEqual(a, b) {
				t.Fatalf("%s %d mismatch: %v", mode, i, err)
			}
		}
	}
}
func BenchmarkWire(b *testing.B) {
	for _, s := range []struct {
		name           string
		batch, payload int
	}{{"one16", 1, 16}, {"eight16", 8, 16}, {"one4096", 1, 4096}} {
		frames := make([][]c.Message, 60)
		pframes := make([]*w.Frame, len(frames))
		for i := range frames {
			for j := 0; j < s.batch; j++ {
				frames[i] = append(frames[i], sampleMessage(i+j, s.payload))
			}
			pframes[i] = asProto(frames[i])
		}
		for _, mode := range []string{"gob", "json", "reuse", "proto", "protoNative"} {
			for _, op := range []string{"encode", "decode"} {
				b.Run(s.name+"/"+mode+"/"+op, func(b *testing.B) {
					var buf bytes.Buffer
					encoder, decoder := frameWriter(&buf, mode), frameReader(&buf, mode)
					enc := func(i int) {
						if mode == "protoNative" {
							data, e := proto.Marshal(pframes[i])
							if e != nil {
								b.Fatal(e)
							}
							var h [4]byte
							binary.BigEndian.PutUint32(h[:], uint32(len(data)))
							buf.Write(h[:])
							buf.Write(data)
						} else if e := encoder(frames[i]); e != nil {
							b.Fatal(e)
						}
					}
					dec := func() {
						if mode == "protoNative" {
							h := buf.Next(4)
							var decoded w.Frame
							if e := proto.Unmarshal(buf.Next(int(binary.BigEndian.Uint32(h))), &decoded); e != nil {
								b.Fatal(e)
							}
						} else {
							var decoded []c.Message
							if e := decoder(&decoded); e != nil {
								b.Fatal(e)
							}
						}
					}
					// Establish the per-connection Gob type dictionary for both sides beforehand.
					enc(0)
					dec()
					wire := make([][]byte, len(frames))
					size := 0
					for i := range frames {
						buf.Reset()
						enc(i)
						wire[i] = bytes.Clone(buf.Bytes())
						size += len(wire[i])
					}
					// Decode directly from the recorded frames rather than copying input during timing.
					var reader bytes.Reader
					decodeStream := frameReader(&reader, mode)
					if mode == "gob" {
						var warm bytes.Buffer
						ee := frameWriter(&warm, mode)
						if e := ee(frames[0]); e != nil {
							b.Fatal(e)
						}
						reader.Reset(warm.Bytes())
						var v []c.Message
						if e := decodeStream(&v); e != nil {
							b.Fatal(e)
						}
					}
					b.ReportAllocs()
					b.ResetTimer()
					for n := 0; n < b.N; n++ {
						i := n % len(frames)
						if op == "encode" {
							buf.Reset()
							enc(i)
						} else {
							if mode == "protoNative" {
								var v w.Frame
								if e := proto.Unmarshal(wire[i][4:], &v); e != nil {
									b.Fatal(e)
								}
							} else {
								reader.Reset(wire[i])
								var v []c.Message
								if e := decodeStream(&v); e != nil {
									b.Fatal(e)
								}
							}
						}
					}
					b.StopTimer()
					b.ReportMetric(float64(size)/float64(len(frames)*s.batch), "wireB/msg")
				})
			}
		}
	}
}
