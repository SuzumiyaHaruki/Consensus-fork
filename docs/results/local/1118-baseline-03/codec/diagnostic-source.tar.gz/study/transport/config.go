// Package transport provides authenticated, reusable TCP links between replicas.
package transport

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"time"

	"example.com/mixepaxos/consensus"
)

type Member struct {
	Peer   string `json:"peer"`
	Client string `json:"client"`
	Pin    string `json:"cert_sha256"`
}

type Config struct {
	Members []Member `json:"members"`
	F       int      `json:"f"`
	S       int      `json:"s"`
	E       int      `json:"e"`
	Window  string   `json:"window"`
}

func ReadConfig(path string) (Config, error) {
	var cfg Config
	data, err := os.ReadFile(path)
	if err != nil {
		return cfg, err
	}
	if err := json.Unmarshal(data, &cfg); err != nil {
		return cfg, err
	}
	addrs, pins := make(map[string]bool), make(map[string]bool)
	for _, m := range cfg.Members {
		for _, addr := range []string{m.Peer, m.Client} {
			if _, _, err := net.SplitHostPort(addr); err != nil || addrs[addr] {
				return cfg, fmt.Errorf("invalid or duplicate address %q", addr)
			}
			addrs[addr] = true
		}
		pin, err := hex.DecodeString(m.Pin)
		if err != nil || len(pin) != 32 || hex.EncodeToString(pin) != m.Pin || pins[m.Pin] {
			return cfg, fmt.Errorf("invalid or duplicate certificate pin")
		}
		pins[m.Pin] = true
	}
	return cfg, nil
}

func (c Config) Node(self int) (consensus.Config, error) {
	W, err := time.ParseDuration(c.Window)
	return consensus.Config{
		Members: len(c.Members), Self: self, F: c.F, S: c.S, E: c.E, Window: W,
	}, err
}
