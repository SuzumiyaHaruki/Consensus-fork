package transport

import (
	c "example.com/mixepaxos/consensus"
	w "example.com/mixepaxos/wirepb"
)

// One private set of temporary protobuf objects per sender. Nothing in these
// structures is retained by the runtime after MarshalAppend returns.
type valueSlot struct {
	v   w.Value
	q   w.Command
	rid w.RID
}

func (s *valueSlot) fill(v *c.Value) *w.Value {
	if v == nil {
		return nil
	}
	q := v.Command
	s.rid.Client = q.RID.Client
	s.rid.Seq = q.RID.Seq
	s.q.Rid = &s.rid
	s.q.Op = q.Op
	s.q.Key = q.Key
	s.q.Value = q.Value
	s.v.Command = &s.q
	s.v.Deps = v.Deps
	s.v.Seq = v.Seq
	return &s.v
}

type slot struct {
	m        w.Message
	x, y     w.ID
	b, h, ab w.Ballot
	f        w.First
	a        w.Accepted
	vals     [4]valueSlot
}

func fillID(s *w.ID, x c.ID) *w.ID {
	if x == (c.ID{}) {
		return nil
	}
	s.Replica = int64(x.Replica)
	s.Number = x.Number
	return s
}
func fillBallot(s *w.Ballot, b c.Ballot) *w.Ballot {
	if b == (c.Ballot{}) {
		return nil
	}
	s.Round = b.Round
	s.Owner = int64(b.Owner)
	return s
}
func (s *slot) fill(m c.Message) *w.Message {
	x := &s.m
	x.Kind = uint32(m.Kind)
	x.Request = uint32(m.Request)
	x.X = fillID(&s.x, m.X)
	x.Key = m.Key
	x.Ballot = fillBallot(&s.b, m.Ballot)
	x.Attempt = m.Attempt
	x.Phase = uint32(m.Phase)
	x.Nonce = m.Nonce
	x.Init = s.vals[0].fill(m.Init)
	x.Value = s.vals[1].fill(m.Value)
	x.Higher = fillBallot(&s.h, m.Higher)
	x.Other = fillID(&s.y, m.Other)
	x.Strong = m.Strong
	x.Origin = int64(m.Origin)
	x.HasDone = m.HasDone
	x.Notice = m.Notice
	x.Number = m.Number
	x.Subject = int64(m.Subject)
	x.First = nil
	if m.First != nil {
		s.f.Suggestion = s.vals[2].fill(m.First.Suggestion)
		s.f.Fast = m.First.Fast
		x.First = &s.f
	}
	x.Record = nil
	if m.Record != nil {
		s.a.Ballot = fillBallot(&s.ab, m.Record.Ballot)
		s.a.Value = s.vals[3].fill(m.Record.Value)
		x.Record = &s.a
	}
	x.Witnesses = x.Witnesses[:0]
	for _, v := range m.Witnesses {
		x.Witnesses = append(x.Witnesses, int64(v))
	}
	return x
}

type frameScratch struct {
	slots []slot
	f     w.Frame
}

func (s *frameScratch) fill(ms []c.Message) *w.Frame {
	if len(ms) > len(s.slots) {
		s.slots = make([]slot, len(ms))
		s.f.Messages = make([]*w.Message, len(ms))
	}
	s.f.Messages = s.f.Messages[:len(ms)]
	for i, m := range ms {
		s.f.Messages[i] = s.slots[i].fill(m)
	}
	return &s.f
}
