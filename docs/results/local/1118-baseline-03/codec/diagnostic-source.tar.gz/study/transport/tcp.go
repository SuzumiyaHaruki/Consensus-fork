package transport

import (
	"bufio"
	"context"
	"crypto/sha256"
	"crypto/tls"

	"encoding/hex"
	"fmt"
	"net"
	"os"
	"runtime"
	"sync"
	"sync/atomic"
	"time"

	"example.com/mixepaxos/consensus"
)

var measure = os.Getenv("MEASURE_WIRE") == "1"

type queues struct {
	ordinary chan consensus.Message
	data     chan consensus.Message
}

type WireStats struct {
	FramesWritten, HeapBytes, TotalAlloc, NumGC  uint64
	KindCounts                                   [21]uint64
	BytesWritten, MessagesWritten, FailedBatches uint64
}

type TCP struct {
	self    int
	members []Member
	pins    map[string]int
	tls     *tls.Config
	batch   int
	links   []queues

	frames                  atomic.Uint64
	kinds                   [21]atomic.Uint64
	stop                    context.Context
	cancel                  context.CancelFunc
	once                    sync.Once
	wg                      sync.WaitGroup
	listener                net.Listener
	mu                      sync.Mutex
	conns                   map[net.Conn]struct{}
	bytes, messages, failed atomic.Uint64
}

func NewTCP(cfg Config, self int, cert tls.Certificate, queue, batch int) (*TCP, error) {
	if self < 0 || self >= len(cfg.Members) || len(cert.Certificate) == 0 ||
		fingerprint(cert.Certificate[0]) != cfg.Members[self].Pin {
		return nil, fmt.Errorf("local certificate does not match member identity")
	}
	if queue < 1 || batch < 1 || batch > 128 {
		return nil, fmt.Errorf("invalid TCP queue or batch size")
	}
	ctx, cancel := context.WithCancel(context.Background())
	t := &TCP{
		self: self, members: cfg.Members, pins: make(map[string]int), batch: batch,
		stop: ctx, cancel: cancel, links: make([]queues, len(cfg.Members)), conns: make(map[net.Conn]struct{}),
		tls: &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13},
	}
	for p, m := range cfg.Members {
		t.pins[m.Pin] = p
		if p != self {
			t.links[p] = queues{make(chan consensus.Message, queue), make(chan consensus.Message, queue)}
		}
	}
	return t, nil
}

func fingerprint(der []byte) string {
	pin := sha256.Sum256(der)
	return hex.EncodeToString(pin[:])
}

func (t *TCP) Start(deliver func(int, consensus.Message) bool) error {
	ln, err := net.Listen("tcp", t.members[t.self].Peer)
	if err != nil {
		return err
	}
	t.listener = ln
	t.wg.Add(1)
	go t.serve(deliver)
	for p := range t.members {
		if p != t.self {
			t.wg.Add(1)
			go t.write(p)
		}
	}
	return nil
}

func (t *TCP) Close() {
	t.once.Do(func() {
		t.cancel()
		if t.listener != nil {
			t.listener.Close()
		}
		t.mu.Lock()
		for conn := range t.conns {
			conn.Close()
		}
		t.mu.Unlock()
		t.wg.Wait()
	})
}

func (t *TCP) Stats() WireStats {
	s := WireStats{BytesWritten: t.bytes.Load(), MessagesWritten: t.messages.Load(), FailedBatches: t.failed.Load()}
	if measure {
		var ms runtime.MemStats
		runtime.ReadMemStats(&ms)
		s.HeapBytes = ms.HeapAlloc
		s.TotalAlloc = ms.TotalAlloc
		s.NumGC = uint64(ms.NumGC)
		s.FramesWritten = t.frames.Load()
		for i := range s.KindCounts {
			s.KindCounts[i] = t.kinds[i].Load()
		}
	}
	return s
}

func (t *TCP) Send(to int, m consensus.Message) bool {
	if to < 0 || to >= len(t.links) || to == t.self || t.stop.Err() != nil {
		return false
	}
	q := t.links[to].ordinary
	switch m.Kind {
	case consensus.Fetch, consensus.Initial, consensus.Learn, consensus.Done, consensus.Stored,
		consensus.Heartbeat, consensus.Complaint, consensus.Bad, consensus.NoticeAck:
		q = t.links[to].data
	}
	select {
	case q <- m:
		return true
	default:
		return false
	}
}

func (t *TCP) track(conn net.Conn) bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.stop.Err() != nil {
		conn.Close()
		return false
	}
	t.conns[conn] = struct{}{}
	return true
}

func (t *TCP) untrack(conn net.Conn) {
	conn.Close()
	t.mu.Lock()
	delete(t.conns, conn)
	t.mu.Unlock()
}

func (t *TCP) serve(deliver func(int, consensus.Message) bool) {
	defer t.wg.Done()
	cfg := t.tls.Clone()
	cfg.ClientAuth = tls.RequireAnyClientCert
	cfg.VerifyConnection = func(s tls.ConnectionState) error {
		p, ok := t.pins[fingerprint(s.PeerCertificates[0].Raw)]
		if !ok || p == t.self {
			return fmt.Errorf("unconfigured peer key")
		}
		return nil
	}
	slots := make(chan struct{}, max(16, 4*len(t.members)))
	for {
		raw, err := t.listener.Accept()
		if err != nil {
			return
		}
		select {
		case slots <- struct{}{}:
		default:
			raw.Close()
			continue
		}
		if !t.track(raw) {
			<-slots
			return
		}
		t.wg.Add(1)
		go func() {
			defer t.wg.Done()
			defer func() { <-slots }()
			defer t.untrack(raw)
			conn := tls.Server(raw, cfg)
			ctx, cancel := context.WithTimeout(t.stop, time.Second)
			err := conn.HandshakeContext(ctx)
			cancel()
			if err != nil {
				return
			}
			peer := t.pins[fingerprint(conn.ConnectionState().PeerCertificates[0].Raw)]
			dec := frameReader(bufio.NewReader(conn), wireCodec)
			for {
				var frame []consensus.Message
				if err := dec(&frame); err != nil || len(frame) == 0 || len(frame) > 128 {
					return
				}
				for _, m := range frame {
					deliver(peer, m)
				}
			}
		}()
	}
}

type metered struct {
	net.Conn
	bytes *atomic.Uint64
}

func (m metered) Write(p []byte) (int, error) {
	n, err := m.Conn.Write(p)
	m.bytes.Add(uint64(n))
	return n, err
}

func (t *TCP) connect(peer int) (*tls.Conn, error) {
	cfg := t.tls.Clone()
	// Pin verification replaces the public CA and hostname verification path.
	cfg.InsecureSkipVerify = true
	cfg.VerifyConnection = func(s tls.ConnectionState) error {
		if len(s.PeerCertificates) == 0 || fingerprint(s.PeerCertificates[0].Raw) != t.members[peer].Pin {
			return fmt.Errorf("server key does not match member %d", peer)
		}
		return nil
	}
	ctx, cancel := context.WithTimeout(t.stop, 500*time.Millisecond)
	defer cancel()
	raw, err := (&net.Dialer{}).DialContext(ctx, "tcp", t.members[peer].Peer)
	if err != nil {
		return nil, err
	}
	conn := tls.Client(metered{raw, &t.bytes}, cfg)
	if !t.track(conn) {
		return nil, context.Canceled
	}
	if err := conn.HandshakeContext(ctx); err != nil {
		t.untrack(conn)
		return nil, err
	}
	return conn, nil
}

func (t *TCP) write(peer int) {
	defer t.wg.Done()
	q := t.links[peer]
	var conn *tls.Conn
	var enc func([]consensus.Message) error
	var buf *bufio.Writer
	var nextDial time.Time
	defer func() {
		if conn != nil {
			t.untrack(conn)
		}
	}()
	frame := make([]consensus.Message, 0, t.batch)
	for t.stop.Err() == nil {
		var m consensus.Message
		select {
		case <-t.stop.Done():
			return
		case m = <-q.data:
		case m = <-q.ordinary:
		}
		frame = append(frame[:0], m)
	drain:
		for len(frame) < t.batch {
			select {
			case m = <-q.data:
			case m = <-q.ordinary:
			default:
				break drain
			}
			frame = append(frame, m)
		}
		if conn == nil && !time.Now().Before(nextDial) {
			var err error
			conn, err = t.connect(peer)
			if err == nil {
				buf = bufio.NewWriterSize(conn, 32*1024)
				enc = frameWriter(buf, wireCodec)
			}
			nextDial = time.Now().Add(100 * time.Millisecond)
		}
		if conn == nil {
			t.failed.Add(1)
			clear(frame)
			continue
		}
		conn.SetWriteDeadline(time.Now().Add(time.Second))
		err := enc(frame)
		if err == nil {
			err = buf.Flush()
		}
		if err == nil {
			t.messages.Add(uint64(len(frame)))
			if measure {
				t.frames.Add(1)
				for _, m := range frame {
					t.kinds[m.Kind].Add(1)
				}
			}
		} else {
			t.failed.Add(1)
			t.untrack(conn)
			conn = nil
		}
		clear(frame)
	}
}
