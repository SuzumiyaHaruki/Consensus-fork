package transport

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"math/big"
	"os"
	"path/filepath"
	"time"
)

func CredentialPaths(config string, id int) (cert, key string) {
	dir := filepath.Dir(config)
	return filepath.Join(dir, fmt.Sprintf("member-%d.crt", id)), filepath.Join(dir, fmt.Sprintf("member-%d.key", id))
}

// GenerateLoopback creates a new development cluster directory with separate
// replica keys. It refuses to overwrite existing files.
func GenerateLoopback(dir string, n, f, s, e, base int, window time.Duration) error {
	q := n - f
	if n <= 0 || f < 0 || f >= n || s < 0 || s >= q || q > f+1 || e < 0 || e > (q-1)/2 ||
		window <= 0 || base < 1024 || base > 65535 || n > (65536-base)/2 {
		return fmt.Errorf("invalid protocol parameters or loopback port range")
	}
	if err := os.Mkdir(dir, 0700); err != nil {
		return err
	}
	path := filepath.Join(dir, "config.json")
	c := Config{Members: make([]Member, n), F: f, S: s, E: e, Window: window.String()}
	for p := range c.Members {
		cert, key, pin, err := generateKey(p)
		if err != nil {
			return err
		}
		certPath, keyPath := CredentialPaths(path, p)
		if err := os.WriteFile(certPath, cert, 0644); err != nil {
			return err
		}
		if err := os.WriteFile(keyPath, key, 0600); err != nil {
			return err
		}
		c.Members[p] = Member{
			Peer: fmt.Sprintf("127.0.0.1:%d", base+p), Client: fmt.Sprintf("127.0.0.1:%d", base+n+p), Pin: pin,
		}
	}
	body, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(body, '\n'), 0644)
}

func generateKey(p int) ([]byte, []byte, string, error) {
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, nil, "", err
	}
	now := time.Now()
	t := x509.Certificate{
		SerialNumber: big.NewInt(int64(p) + 1), Subject: pkix.Name{CommonName: fmt.Sprintf("member-%d", p)},
		NotBefore: now.Add(-time.Hour), NotAfter: now.AddDate(1, 0, 0), KeyUsage: x509.KeyUsageDigitalSignature,
		ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth, x509.ExtKeyUsageClientAuth},
	}
	der, err := x509.CreateCertificate(rand.Reader, &t, &t, pub, priv)
	if err != nil {
		return nil, nil, "", err
	}
	rawKey, err := x509.MarshalPKCS8PrivateKey(priv)
	if err != nil {
		return nil, nil, "", err
	}
	return pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}),
		pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: rawKey}), fingerprint(der), nil
}
