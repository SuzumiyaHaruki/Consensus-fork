package transport

import (
	"encoding/binary"
	"encoding/gob"
	"encoding/json"
	c "example.com/mixepaxos/consensus"
	w "example.com/mixepaxos/wirepb"
	"fmt"
	"google.golang.org/protobuf/proto"
	"io"
	"os"
)

var wireCodec = os.Getenv("WIRE_CODEC")

func pid(x c.ID) *w.ID {
	if x == (c.ID{}) {
		return nil
	}
	return &w.ID{Replica: int64(x.Replica), Number: x.Number}
}
func gid(x *w.ID) c.ID {
	if x == nil {
		return c.ID{}
	}
	return c.ID{Replica: int(x.Replica), Number: x.Number}
}
func pb(b c.Ballot) *w.Ballot {
	if b == (c.Ballot{}) {
		return nil
	}
	return &w.Ballot{Round: b.Round, Owner: int64(b.Owner)}
}
func gb(b *w.Ballot) c.Ballot {
	if b == nil {
		return c.Ballot{}
	}
	return c.Ballot{Round: b.Round, Owner: int(b.Owner)}
}
func pv(v *c.Value) *w.Value {
	if v == nil {
		return nil
	}
	q := v.Command
	return &w.Value{Command: &w.Command{Rid: &w.RID{Client: q.RID.Client, Seq: q.RID.Seq}, Op: q.Op, Key: q.Key, Value: q.Value}, Deps: v.Deps, Seq: v.Seq}
}
func gv(v *w.Value) *c.Value {
	if v == nil {
		return nil
	}
	q := v.GetCommand()
	r := q.GetRid()
	return &c.Value{Command: c.Command{RID: c.RID{Client: r.GetClient(), Seq: r.GetSeq()}, Op: q.GetOp(), Key: q.GetKey(), Value: q.GetValue()}, Deps: v.Deps, Seq: v.Seq}
}
func asProto(a []c.Message) *w.Frame {
	f := &w.Frame{Messages: make([]*w.Message, len(a))}
	for i, m := range a {
		x := &w.Message{Kind: uint32(m.Kind), Request: uint32(m.Request), X: pid(m.X), Key: m.Key, Ballot: pb(m.Ballot), Attempt: m.Attempt, Phase: uint32(m.Phase), Nonce: m.Nonce, Init: pv(m.Init), Value: pv(m.Value), Higher: pb(m.Higher), Other: pid(m.Other), Strong: m.Strong, Origin: int64(m.Origin), HasDone: m.HasDone, Notice: m.Notice, Number: m.Number, Subject: int64(m.Subject)}
		if m.First != nil {
			x.First = &w.First{Suggestion: pv(m.First.Suggestion), Fast: m.First.Fast}
		}
		if m.Record != nil {
			x.Record = &w.Accepted{Ballot: pb(m.Record.Ballot), Value: pv(m.Record.Value)}
		}
		for _, y := range m.Witnesses {
			x.Witnesses = append(x.Witnesses, int64(y))
		}
		f.Messages[i] = x
	}
	return f
}
func fromProto(f *w.Frame) []c.Message {
	a := make([]c.Message, len(f.Messages))
	for i, x := range f.Messages {
		m := c.Message{Kind: c.Kind(x.Kind), Request: c.Kind(x.Request), X: gid(x.X), Key: x.Key, Ballot: gb(x.Ballot), Attempt: x.Attempt, Phase: uint8(x.Phase), Nonce: x.Nonce, Init: gv(x.Init), Value: gv(x.Value), Higher: gb(x.Higher), Other: gid(x.Other), Strong: x.Strong, Origin: int(x.Origin), HasDone: x.HasDone, Notice: x.Notice, Number: x.Number, Subject: int(x.Subject)}
		if x.First != nil {
			m.First = &c.First{Suggestion: gv(x.First.Suggestion), Fast: x.First.Fast}
		}
		if x.Record != nil {
			m.Record = &c.Accepted{Ballot: gb(x.Record.Ballot), Value: gv(x.Record.Value)}
		}
		for _, y := range x.Witnesses {
			m.Witnesses = append(m.Witnesses, int(y))
		}
		a[i] = m
	}
	return a
}
func frameWriter(dst io.Writer, mode string) func([]c.Message) error {
	if mode == "" || mode == "gob" {
		g := gob.NewEncoder(dst)
		return func(m []c.Message) error { return g.Encode(m) }
	}
	var scratch frameScratch
	var output []byte
	return func(m []c.Message) error {
		var b []byte
		var err error
		switch mode {
		case "json":
			b, err = json.Marshal(m)
		case "reuse":
			output, err = proto.MarshalOptions{}.MarshalAppend(output[:0], scratch.fill(m))
			b = output
		case "proto":
			b, err = proto.Marshal(asProto(m))
		default:
			return fmt.Errorf("unexpected codec %s", mode)
		}
		if err != nil {
			return err
		}
		var head [4]byte
		binary.BigEndian.PutUint32(head[:], uint32(len(b)))
		if _, err = dst.Write(head[:]); err != nil {
			return err
		}
		_, err = dst.Write(b)
		return err
	}
}
func frameReader(src io.Reader, mode string) func(*[]c.Message) error {
	if mode == "" || mode == "gob" {
		g := gob.NewDecoder(src)
		return func(out *[]c.Message) error { return g.Decode(out) }
	}
	var body []byte
	return func(out *[]c.Message) error {
		var head [4]byte
		if _, e := io.ReadFull(src, head[:]); e != nil {
			return e
		}
		size := binary.BigEndian.Uint32(head[:])
		if size > 64<<20 {
			return fmt.Errorf("diagnostic frame too large")
		}
		if uint32(cap(body)) < size {
			body = make([]byte, size)
		}
		body = body[:size]
		if _, e := io.ReadFull(src, body); e != nil {
			return e
		}
		if mode == "json" {
			return json.Unmarshal(body, out)
		}
		var f w.Frame
		if e := proto.Unmarshal(body, &f); e != nil {
			return e
		}
		*out = fromProto(&f)
		return nil
	}
}
