from pathlib import Path
import statistics,collections,csv,json
P=Path(__file__).resolve().parent
def save(file,rows):
    if rows:
        with (P/file).open('w') as f:
            w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def codecs():
    records=collections.defaultdict(list)
    for l in (line for filename in ('micro.txt', 'micro-reuse.txt') for line in (P/filename).read_text().splitlines()):
        a=l.split()
        if not a or not a[0].startswith('BenchmarkWire/') or len(a)<10:continue
        _,shape,mode,op=a[0].split('/')
        batch=8 if shape.startswith('eight') else 1
        records[shape,mode,op].append([float(a[2])/batch/1000,float(a[4]),float(a[6])/batch,float(a[8])/batch])
    rows=[]
    for (shape,mode,op),data in records.items():
        us,size,mem,allocs=map(statistics.median,zip(*data))
        rows.append(dict(shape=shape,codec=mode,operation=op,us_per_message=round(us,3),bytes_on_wire=size,heap_bytes_per_message=round(mem,2),allocations_per_message=allocs,repetitions=len(data)))
    save('micro.csv',rows)
def cluster():
    rows=[]
    timeline=[]
    for p in sorted((P/'jobs').glob('*/after.json')):
        d=p.parent; a=json.loads(p.read_text());b=json.loads((d/'before.json').read_text()); load=json.loads((d/'load.json').read_text())
        issued=0; c=collections.Counter();bins=[0]*6; start,end=load['start_ns'],load['end_ns']
        with (d/'requests.csv').open() as f:
            for r in csv.DictReader(f):
                c[r['status']]+=1;issued+=int(r['sent_ns'])>0;t=int(r['reply_ns'])
                if r['status']=='APPLIED' and start<=t<=end: bins[min(5,(t-start)*6//(end-start))]+=1
        assert sum(bins)==load['window_completed'] and issued==load['issued'] and dict(c)==load['counts']
        for i,n in enumerate(bins):
            timeline.append(dict(case=d.name,start_s=i*5,end_s=(i+1)*5,applied_per_s=n/5))
        def delta(k):return sum(x[k]-y[k] for x,y in zip(a,b))
        adm=delta('Admitted')
        samples=[json.loads(s) for s in (d/'samples.jsonl').read_text().splitlines() if s.strip()]
        sw=[s for s in samples if start<=s['ns']<=end]
        cpu=sum(y['cpu']-x['cpu'] for x,y in zip(sw[0]['replicas'],sw[-1]['replicas']))/((sw[-1]['ns']-sw[0]['ns'])/1e9)
        rows.append(dict(case=d.name,rate=load['target_rate'],sent=issued,planned=load['planned'],window_tps=round(sum(bins)/30,1),first5_tps=bins[0]/5,last5_tps=bins[-1]/5,applied=c['APPLIED'],rejected=c['REJECTED'],other=issued-c['APPLIED']-c['REJECTED'],end_pending_origin=adm-delta('OriginExecuted'),lag_p99_ms=round(load['send_lag_ms']['p99'],1),cpu_cores=round(cpu,2),peak_rss_mib=round(max(sum(x['rss'] for x in s['replicas']) for s in samples)/2**20),msg_per_admission=round(delta('MessagesWritten')/adm,2),wire_kB_per_admission=round(delta('BytesWritten')/adm/1000,2),drops=delta('Dropped'),short_windows=delta('ShortWindows'),failed_batches=delta('FailedBatches'),fetch=delta('Fetch'),conflicts=delta('DecisionConflicts')+delta('RIDConflicts'),total_alloc_KB_per_admit=round(delta('TotalAlloc')/adm/1000,2) if delta('TotalAlloc') else None))
    save('cluster.csv',rows)
    save('windows.csv',timeline)
if __name__=='__main__':codecs();cluster()
