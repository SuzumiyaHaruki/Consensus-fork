#!/usr/bin/env python3
"""Run a loopback cluster smoke test or bounded multiprocess load measurement."""
import argparse
import concurrent.futures as futures
import http.client
import json
import os
from pathlib import Path
import random
import secrets
import signal
import socket
import statistics
import subprocess
import tempfile
import threading
import time


def proc(pid):
    stat = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
    return (int(stat[11]) + int(stat[12])) / os.sysconf("SC_CLK_TCK"), int(stat[21]) * os.sysconf("SC_PAGE_SIZE")


def environment():
    print(json.dumps({"affinity": sorted(os.sched_getaffinity(0)), "nproc": os.cpu_count(),
                      "available_memory": next(s.strip() for s in Path("/proc/meminfo").read_text().splitlines()
                                               if s.startswith("MemAvailable:")),
                      "cgroup": Path("/proc/self/cgroup").read_text().strip(),
                      "processes": subprocess.check_output(["ps", "-e", "-o", "pid,ppid,comm"], text=True).splitlines(),
                      "go": subprocess.check_output(["go", "version"], text=True).strip()}), flush=True)


class Cluster:
    def __init__(self, args, path):
        self.args, self.path = args, path
        self.children = []
        self.logs = []

    def setup(self):
        a, p = self.args, self.path
        self.ctl, self.server = p / "mixctl", p / "mixserver"
        self.ctl=Path(__file__).resolve().parent/"ctl"
        self.server=Path(__file__).resolve().parent/os.environ.get("DIAG_SERVER","server")
        cluster = p / "config"
        subprocess.run([self.ctl, "config", "-dir", cluster, "-n", str(a.nodes), "-f", str(a.f), "-s", str(a.s),
                        "-e", str(a.e), "-window", a.window, "-base", str(a.base)], check=True)
        self.config = cluster / "config.json"
        self.members = json.loads(self.config.read_text())["members"]
        cpus = sorted(os.sched_getaffinity(0))
        for member in range(a.nodes):
            command = [self.server, "-id", str(member), "-config", self.config, "-workers", str(a.workers),
                       "-procs", str(a.procs), "-inflight", str(a.inflight), "-wait", a.server_wait,
                       "-batch", str(a.batch), "-queue", str(a.queue)]
            if a.trace and member == 0:
                command += ["-trace", Path(a.trace).absolute()]
            if a.pin_entry and member == 0:
                command = ["taskset", "-c", ",".join(map(str, cpus[:a.pin_entry]))] + command
            log = (p / f"{member}.log").open("w+")
            self.logs.append(log)
            self.children.append(subprocess.Popen(command, stdout=log, stderr=log))
        self.until(lambda: all(self.stats(i) for i in range(a.nodes)), "HTTP listeners")
        time.sleep(0.5)

    def close(self):
        for p in self.children:
            if p.poll() is None:
                p.terminate()
        for p in self.children:
            try:
                p.wait(timeout=3)
            except subprocess.TimeoutExpired:
                p.kill()
                p.wait()
        for log in self.logs:
            log.close()

    def kill(self, index):
        self.children[index].send_signal(signal.SIGKILL)
        self.children[index].wait(timeout=3)

    def stats(self, i):
        conn = http.client.HTTPConnection(self.members[i]["client"], timeout=0.5)
        try:
            conn.request("GET", "/stats")
            return json.loads(conn.getresponse().read())
        finally:
            conn.close()

    def until(self, fn, label, limit=12):
        deadline = time.monotonic() + limit
        while time.monotonic() < deadline:
            try:
                r = fn()
                if r:
                    return r
            except (OSError, http.client.HTTPException):
                pass
            time.sleep(0.02)
        raise RuntimeError(f"timed out waiting for {label}")

    def cli_request(self, op, key, value=""):
        return subprocess.check_output([self.ctl, "request", "-op", op, "-key", key, "-value", value])

    def cli_submit(self, i, request):
        return json.loads(subprocess.check_output([self.ctl, "submit", "-entries", self.members[i]["client"]],
                                                  input=request))

    def smoke(self):
        request = self.cli_request("put", "smoke", "value")
        with futures.ThreadPoolExecutor(max_workers=2) as ex:
            results = [ex.submit(self.cli_submit, i, request) for i in (0, 1)]
            concurrent = [f.result() for f in results]
        assert any(r["status"] == "APPLIED" for r in concurrent), concurrent
        assert all(r["status"] in ("APPLIED", "ALREADY_EXECUTED") for r in concurrent), concurrent
        self.until(lambda: all(self.stats(i)["Inflight"] == 0 for i in range(2)), "origin executions")
        retry = self.cli_submit(0, request)
        assert retry == {"status": "ALREADY_EXECUTED"}, retry
        read = self.cli_submit(self.args.nodes-1, self.cli_request("get", "smoke"))
        assert read == {"status": "APPLIED", "found": True, "value": "value"}, read
        crashed = [0, 1, 2, 3]
        for i in crashed:
            self.kill(i)
        survivors = range(4, self.args.nodes)
        self.until(lambda: all(self.stats(i)["Omega"] == 4 for i in survivors), "common surviving Omega")
        slow = self.cli_submit(4, self.cli_request("delete", "smoke"))
        assert slow == {"status": "APPLIED", "found": True}, slow
        absent = self.cli_submit(6, self.cli_request("get", "smoke"))
        assert absent == {"status": "APPLIED"}, absent
        assert self.stats(4)["Formal"] >= 1, self.stats(4)
        print(json.dumps({"smoke": {"concurrent": concurrent, "retry": retry, "read": read, "crashed": crashed,
                                     "omega": 4, "slow_delete": slow, "absent": absent,
                                     "survivor_stats": [self.stats(i) for i in survivors]}}), flush=True)

    def measure(self):
        a = self.args
        stop = threading.Event()
        barrier = threading.Barrier(a.clients + 1)
        results = [[] for _ in range(a.clients)]
        started = [0] * a.clients
        start = 0.0

        def load(i):
            rnd = random.Random(a.seed + i)
            session = secrets.token_hex(32)
            connections = {}
            sequence = 0
            barrier.wait()
            while not stop.is_set():
                sequence += 1
                if a.entry == "all":
                    member = (i + sequence) % a.nodes
                else:
                    member = int(a.entry)
                key = f"{i}-{sequence}" if a.keys == 0 else str(rnd.randrange(a.keys))
                # A mixed operation population with the same sequence distribution per run.
                op = rnd.choices(["put", "get", "delete"], weights=[6, 3, 1])[0]
                cmd = {"rid": {"client": session, "seq": sequence}, "op": op, "key": key}
                if op == "put":
                    cmd["value"] = "x" * a.value_bytes
                began = time.monotonic()
                started[i] += 1
                try:
                    conn = connections.get(member)
                    if conn is None:
                        conn = http.client.HTTPConnection(self.members[member]["client"], timeout=a.timeout)
                        connections[member] = conn
                    conn.request("POST", "/request", json.dumps(cmd), {"Content-Type": "application/json"})
                    reply = conn.getresponse()
                    state = json.loads(reply.read())["status"]
                except (OSError, http.client.HTTPException, ValueError, KeyError) as exc:
                    state = "TIMEOUT" if isinstance(exc, (TimeoutError, socket.timeout)) else "UNKNOWN"
                    if member in connections:
                        connections.pop(member).close()
                ended = time.monotonic()
                results[i].append((began, ended, state))
                if state == "REJECTED":
                    stop.wait(0.002)
            for conn in connections.values():
                conn.close()

        def snapshot():
            at = time.monotonic()
            stats = [self.stats(i) for i in range(a.nodes)]
            cpu, rss = zip(*(proc(p.pid) for p in self.children))
            return {"seconds": at - start, "outstanding": sum(started) - sum(map(len, results)),
                    "undecided": sum(s["Undecided"] for s in stats), "inflight": sum(s["Inflight"] for s in stats),
                    "cpu_seconds": cpu, "rss_bytes": rss, "stats": stats}

        with futures.ThreadPoolExecutor(max_workers=a.clients) as executor:
            calls = [executor.submit(load, i) for i in range(a.clients)]
            start = time.monotonic()
            samples = [snapshot()]
            start = time.monotonic()
            samples[0]["seconds"] = 0
            barrier.wait()
            while time.monotonic() < start + a.seconds:
                stop.wait(min(a.sample, max(0, start + a.seconds - time.monotonic())))
                samples.append(snapshot())
            stopped = time.monotonic()
            stop.set()
            at_stop = {"seconds": stopped - start, "client_outstanding": sum(started) - sum(map(len, results))}
            while time.monotonic() < stopped + a.drain:
                time.sleep(min(a.sample, max(0, stopped + a.drain - time.monotonic())))
                samples.append(snapshot())
            at_end = {"seconds": time.monotonic() - start, "client_outstanding": sum(started) - sum(map(len, results))}
            for call in calls:
                call.result(timeout=a.timeout+1)

        def summarize(lo, hi):
            population = [r for group in results for r in group if lo <= r[1]-start < hi]
            counts = {s: 0 for s in ("APPLIED", "ALREADY_EXECUTED", "REJECTED", "INCOMPLETE", "UNKNOWN", "TIMEOUT")}
            for _, _, s in population:
                counts[s] = counts.get(s, 0) + 1
            latencies = sorted((end-begin)*1000 for begin, end, s in population if s == "APPLIED")
            return {"interval_s": [lo, hi], "states": counts, "applied_per_s": counts["APPLIED"] / (hi-lo),
                    "applied_p50_ms": statistics.median(latencies) if latencies else None,
                    "applied_p95_ms": latencies[int(0.95*(len(latencies)-1))] if latencies else None}

        active = [s for s in samples if s["seconds"] <= at_stop["seconds"]]
        mid = at_stop["seconds"]/2
        fields = ("Admitted", "OriginDecided", "OriginExecuted", "Fast", "Formal", "Recovered", "ShortWindows", "Invalid",
                  "DecisionConflicts", "RIDConflicts", "AdmissionNS", "DecisionNS", "ExecutionNS", "ReplyNS", "Replies",
                  "BytesWritten", "MessagesWritten", "Fetch", "Vertices", "Dropped")
        counters = {key: sum(s[key] for s in active[-1]["stats"]) - sum(s[key] for s in active[0]["stats"])
                    for key in fields}
        def interval_resources(left, right):
            def delta(key):
                return sum(s[key] for s in right["stats"]) - sum(s[key] for s in left["stats"])
            n = delta("OriginExecuted")
            return {"interval_s": [left["seconds"], right["seconds"]],
                    "origin_executions": n,
                    "wire_bytes_per_origin_execution": delta("BytesWritten") / n if n else None,
                    "wire_messages_per_origin_execution": delta("MessagesWritten") / n if n else None,
                    "fetch_rounds": delta("Fetch"), "vertices": delta("Vertices"),
                    "rss_mib": [value / (1024*1024) for value in right["rss_bytes"]]}

        midpoint = min(active, key=lambda x: abs(x["seconds"] - mid))
        config = vars(a).copy()
        print(json.dumps({
            "settings": config, "submitters": a.clients, "started": sum(started),
            "admitted_undecided_mean": statistics.mean(x["undecided"] for x in active),
            "admitted_undecided_peak": max(x["undecided"] for x in active),
            "first": summarize(0, mid), "second": summarize(mid, at_stop["seconds"]),
            "drain": summarize(at_stop["seconds"], at_end["seconds"]),
            "after_drain": sum(1 for group in results for r in group if r[1]-start >= at_end["seconds"]),
            "stop": at_stop, "end": at_end, "last": samples[-1], "counters": counters,
            "interval_resources": [interval_resources(active[0], midpoint), interval_resources(midpoint, active[-1])],
            "cpu_cores_by_replica": [(b-a)/active[-1]["seconds"] for a, b in
                                     zip(active[0]["cpu_seconds"], active[-1]["cpu_seconds"])],
            "rss_peak_mib": [max(sample["rss_bytes"][i] for sample in active)/(1024*1024) for i in range(a.nodes)],
            "outstanding_samples": [[round(s["seconds"], 3), s["outstanding"], s["undecided"], s["inflight"]] for s in samples],
        }), flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=("smoke", "measure"))
    p.add_argument("--nodes", type=int, default=7)
    p.add_argument("--f", type=int, default=4)
    p.add_argument("--s", type=int, default=0)
    p.add_argument("--e", type=int, default=1)
    p.add_argument("--window", default="150ms")
    p.add_argument("--base", type=int, default=17100)
    p.add_argument("--workers", type=int, default=2)
    p.add_argument("--procs", type=int, default=2)
    p.add_argument("--inflight", type=int, default=256)
    p.add_argument("--queue", type=int, default=1024)
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--server-wait", default="2s")
    p.add_argument("--clients", type=int, default=16)
    p.add_argument("--seconds", type=float, default=10)
    p.add_argument("--sample", type=float, default=0.1)
    p.add_argument("--drain", type=float, default=3)
    p.add_argument("--timeout", type=float, default=3)
    p.add_argument("--seed", type=int, default=19)
    p.add_argument("--keys", type=int, default=0, help="unique key per request when zero")
    p.add_argument("--entry", default="all", help="entry member index or all")
    p.add_argument("--value-bytes", type=int, default=48)
    p.add_argument("--trace", help="capture a Go execution trace for replica 0")
    p.add_argument("--pin-entry", type=int, default=0, help="restrict replica 0 to this many visible CPUs")
    args = p.parse_args()
    if args.mode == "smoke" and (args.nodes, args.f) != (7, 4):
        p.error("smoke exercises four crashes in a seven-member cluster")
    if min(args.clients, args.seconds, args.sample, args.drain, args.timeout) <= 0:
        p.error("client counts and times must be positive")
    with tempfile.TemporaryDirectory(prefix="mixepaxos-") as tmp:
        cluster = Cluster(args, Path(tmp))
        try:
            cluster.setup()
            if args.mode == "smoke":
                cluster.smoke()
            else:
                cluster.measure()
        except Exception:
            for log in cluster.logs:
                log.seek(0)
                print(log.read()[-4096:], flush=True)
            raise
        finally:
            cluster.close()


if __name__ == "__main__":
    main()
