import csv,json,re,subprocess
from collections import Counter
from pathlib import Path
P=Path(__file__).resolve().parent
rows=[]; stages=[]
for path in sorted(P.glob('jobs/gob-profile-*')):
 for file in ('early','late'):
    raw=subprocess.check_output([P/'pprof','-raw',P/'gob-profile-binary',path/(file+'.pprof')],text=True)
    lines=raw.splitlines(); split=lines.index('Locations'); part=lines[split+1:lines.index('Mappings')]
    locs={}
    for l in part:
        m=re.match(r'\s*(\d+): .*? M=\d+\s*(.*)',l)
        if m: key=int(m[1]);locs[key]=m[2].split(' /')[0]
        elif l.strip(): locs[key]+=' '+l.strip().split(' /')[0]
    data=Counter()
    for l in lines[:split]:
        m=re.match(r'\s*\d+\s+(\d+): (\d[ 0-9]*)$',l)
        if not m: continue
        stack=' '.join(locs[int(i)] for i in m[2].split())
        if 'internal/runtime/syscall.Syscall6' in stack: cat='syscall'
        elif re.search(r'runtime\.(gcDrain|gcAssistAlloc|scanobject|gcBgMarkWorker)',stack):cat='gc'
        elif 'crypto/tls.' in stack: cat='tls'
        elif 'encoding/gob.' in stack: cat='gob'
        elif 'example.com/mixepaxos/consensus.' in stack: cat='consensus'
        else: cat='remaining'
        data[cat]+=int(m[1])
    total=sum(data.values());r={k:round(100*data[k]/total,1) for k in ('syscall','gc','tls','gob','consensus','remaining')}
    rows.append(dict(job=path.name,window=file,sampled_cpu_s=total/1e9,**r))
 samples=[json.loads(s) for s in (path/'samples.jsonl').read_text().splitlines()]
 load=json.loads((path/'load.json').read_text())
 for lower,upper in ((0,10),(10,20),(20,30)):
    def nearest(t): return min((s for s in samples if 'stats' in s),key=lambda s:abs(s['ns']-(load['start_ns']+t*1e9)))
    a,b=nearest(lower),nearest(upper);seconds=(b['ns']-a['ns'])/1e9
    def ds(k):return sum(v[k]-u[k] for v,u in zip(b['stats'],a['stats']))
    admitted=ds('Admitted')
    stages.append(dict(job=path.name,t1=lower,t2=upper,actual_sample_seconds=round(seconds,3),admitted_per_s=round(admitted/seconds),executed_per_s=round(ds('OriginExecuted')/seconds),msg_adm=round(ds('MessagesWritten')/admitted,2),frame_adm=round(ds('FramesWritten')/admitted,2),alloc_kb_adm=round(ds('TotalAlloc')/admitted/1000,2),gib_heap=round(sum(s['HeapBytes'] for s in b['stats'])/2**30,2),inflight_end=sum(s['Inflight'] for s in b['stats']),undecided_end=sum(s['Undecided'] for s in b['stats']),drops=ds('Dropped'),short_windows=ds('ShortWindows')))
for name,data in [('cpu_exclusive',rows),('phase_stats',stages)]:
 with (P/(name+'.csv')).open('w') as f:
    w=csv.DictWriter(f,fieldnames=data[0]);w.writeheader();w.writerows(data)
 print((P/(name+'.csv')).read_text())
