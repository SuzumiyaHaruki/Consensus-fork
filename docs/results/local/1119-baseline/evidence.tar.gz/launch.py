import subprocess,sys,os,shutil
from pathlib import Path
work=Path(__file__).resolve().parent
sys.path.insert(0,'/home/nitro/Desktop/consensus-forge-vft-epaxos')
from runtime.local_exec import isolated_command
from runtime.toolchains import go_tool_roots
roots=go_tool_roots()
env={'PATH':':'.join([*(str(r/'bin') for r in roots),'/usr/bin','/bin']),'HOME':str(work),'TMPDIR':'/tmp','LANG':'C.UTF-8','GOPROXY':'off','GOSUMDB':'off','GOTOOLCHAIN':'local','GOCACHE':str(work/'go-cache')}
for name,args,cwd in [('build',['go','build','-o',str(work/'server'),'./cmd/server'],work/'candidate'),('load',['go','build','-o',str(work/'driver'),str(work/'load.go')],work),('native',['go','test','-count=1','./...'],work/'candidate'),('measure',['python3','bench.py'],work)]:
 cmd=isolated_command(args,work,cwd,work/'hosts',roots)
 with (work/(name+'.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:print((work/(name+'.log')).read_text()[-1600:]);sys.exit(r.returncode)
 print(name,flush=True)
