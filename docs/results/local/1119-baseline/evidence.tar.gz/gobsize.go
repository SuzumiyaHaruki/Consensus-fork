package main
import ("bytes"; "encoding/gob"; "fmt"; c "example.com/mixepaxos/consensus")
func main(){
 var buf bytes.Buffer
 enc:=gob.NewEncoder(&buf)
 msg:=c.Message{Kind:c.PreAcceptReply,Key:"load/000000001",X:c.InstanceID{Owner:1,Index:1},Attempt:1,Nonce:2,Phase:1,Vote:c.Vote{Kind:1}}
 if err:=enc.Encode(msg);err!=nil { panic(err) }
 first:=buf.Len()
 if err:=enc.Encode(msg);err!=nil { panic(err) }
 fmt.Printf("fresh_gob_bytes=%d incremental_same_stream_bytes=%d udp_app_header_bytes=12\n",first,buf.Len()-first)
}
