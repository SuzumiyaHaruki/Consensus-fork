import json, os, time, threading
from pathlib import Path
from bench import measure, stats, work

def with_samples(n,p,rate,duration,rep):
    case=work/f'n{n}-p{p}-r{rate}-s{duration}-rep{rep}'
    stop=threading.Event()
    def monitor():
        while not (case/'before.json').exists():
            if stop.wait(.1): return
        pids={}
        for proc in Path('/proc').glob('[0-9]*'):
            try:
                args=(proc/'cmdline').read_bytes().decode().split('\0')
                if args[0]==str(work/'server') and str(case/'cfg.json') in args:
                    pids[int(args[args.index('-id')+1])]=proc
            except (OSError,UnicodeDecodeError,ValueError): continue
        hz=os.sysconf('SC_CLK_TCK')
        with (case/'samples.jsonl').open('w') as out:
            while not stop.is_set():
                try:
                    ticks=[]
                    for i in range(n):
                        fields=(pids[i]/'stat').read_text().split()
                        ticks.append((int(fields[13])+int(fields[14]))/hz)
                    row={'time':time.time(),'replica_cpu_seconds':ticks,'stats':stats(range(21710,21710+n))}
                    print(json.dumps(row),file=out,flush=True)
                except (OSError,ValueError,KeyError,TimeoutError): pass
                stop.wait(5)
    thread=threading.Thread(target=monitor,daemon=True)
    thread.start()
    try: measure(n,p,rate,duration,rep)
    finally:
        stop.set()
        thread.join(5)
if __name__ == "__main__":
    for params in [(7,1,1500,30,1),(7,1,2000,30,1),(3,2,3500,30,1),(7,1,2500,30,2)]:
        with_samples(*params)
