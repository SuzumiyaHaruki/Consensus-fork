from pathlib import Path
work=Path(__file__).resolve().parent
prefix=(work/'launch.py').read_text().split('for name,args,cwd in [')[0]
exec(prefix)
for name,args,cwd in [('long',['python3','long.py'],work)]:
 cmd=isolated_command(args,work,cwd,work/'hosts',roots)
 with (work/(name+'.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:print((work/(name+'.log')).read_text()[-1600:]);sys.exit(r.returncode)
 print(name,flush=True)
