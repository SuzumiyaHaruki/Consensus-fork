from extra import with_samples
with_samples(3,2,2500,60,1)
with_samples(7,1,1500,60,1)
