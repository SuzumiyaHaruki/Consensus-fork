import csv,json,os,signal,subprocess,sys,time
from pathlib import Path
import urllib.request

work=Path(__file__).resolve().parent
web=urllib.request.build_opener(urllib.request.ProxyHandler({}))
cores=sorted(os.sched_getaffinity(0))
assert len(cores)>=8
def stats(ports):
 return [json.load(web.open(f'http://127.0.0.1:{p}/stats',timeout=2)) for p in ports]
def measure(n,p,rate,duration,rep):
 job=work/f'n{n}-p{p}-r{rate}-s{duration}-rep{rep}';job.mkdir()
 ports=list(range(21710,21710+n))
 cfg={'members':[{'peer':f'127.0.0.1:{15710+i}','client':f'127.0.0.1:{v}'} for i,v in enumerate(ports)],'f':1 if n==3 else 4,'s':0 if n==3 else 1,'e':0 if n==3 else 1,'window_ms':80 if n==3 else 200,'recovery_ms':600,'overdue_ms':1200,'workers':4,'queue':1024,'max_in_flight':512,'max_waiters':1024}
 (job/'cfg.json').write_text(json.dumps(cfg))
 servers=[];files=[]
 try:
  for i in range(n):
   used=cores[i*2:i*2+2] if n==3 else cores[i:i+1]
   log=(job/f'n{i}.log').open('w');files.append(log)
   proc=subprocess.Popen(['taskset','-c',','.join(map(str,used)),str(work/'server'),'-config',str(job/'cfg.json'),'-id',str(i),'-gomaxprocs',str(p)],stdout=log,stderr=log);servers.append(proc)
  until=time.monotonic()+8
  while time.monotonic()<until:
   try:
    if all(x['Omega']==0 for x in stats(ports)):break
   except OSError:pass
   time.sleep(.05)
  else:raise RuntimeError('not ready')
  warm=70
  for i in range(warm):
   msg={'wait_ms':3000,'command':{'id':{'client':'warm','seq':i+1},'op':'put','key':f'w{i}','value':'v'}}
   rsp=json.load(web.open(urllib.request.Request(f'http://127.0.0.1:{ports[i%n]}/request',json.dumps(msg).encode(),{'Content-Type':'application/json'}),timeout=4));assert rsp['status']=='RESULT',rsp
  for i in range(100):
   b=stats(ports)
   if all(x['Executed']==warm for x in b):break
   time.sleep(.03)
  assert all(x['Executed']==warm for x in b)
  bindings=[sorted(os.sched_getaffinity(v.pid)) for v in servers]
  dc=cores[6:8] if n==3 else cores[7:8]
  (job/'before.json').write_text(json.dumps({'stats':b,'bindings':bindings,'driver_cpus':dc}))
  args=['taskset','-c',','.join(map(str,dc)),str(work/'driver'),'-addresses',','.join('127.0.0.1:'+str(v) for v in ports),'-rate',str(rate),'-seconds',str(duration),'-timeout','15','-max-inflight','16384','-seed',str(17+rep-1),'-topology','balanced' if n==3 else 'random','-payload','16','-output',str(job)]
  subprocess.run(args,env={**os.environ,'GOMAXPROCS':str(len(dc))},check=True,timeout=duration+30)
  end=time.monotonic()+3
  while time.monotonic()<end:
   a=stats(ports); admitted=sum(x['Admitted']-y['Admitted'] for x,y in zip(a,b))
   if all(x['Executed']-y['Executed']==admitted for x,y in zip(a,b)):break
   time.sleep(.15)
  (job/'after.json').write_text(json.dumps(a))
  l=json.loads((job/'load.json').read_text()); print(job.name,l['throughput_ops_s'],l['counts'],'admitted',admitted,'executed',[x['Executed']-y['Executed'] for x,y in zip(a,b)],flush=True)
 finally:
  for v in servers:v.terminate()
  for v in servers:
   try:v.wait(timeout=4)
   except subprocess.TimeoutExpired:v.kill();v.wait()
  for f in files:f.close()
if __name__=='__main__':
 for case in [(3,2,2500,20,1),(3,2,5000,20,1),(7,1,2500,30,1),(3,2,8000,20,1),(3,1,5000,20,1),(3,2,5000,20,2)]:
  measure(*case)
