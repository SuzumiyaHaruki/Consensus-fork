import csv,json,re
from pathlib import Path
from datetime import datetime
from statistics import mean
work=Path(__file__).resolve().parent
names=('case','replicas','go_p','target_rps','seconds','repeat','issued','not_sent','ok_through_drain','rejected','incomplete','window_tps','first5_tps','last5_tps','ok_p50_ms','ok_p95_ms','ok_p99_ms','admitted','min_executed','max_executed','udp_kB_per_admitted','transport_drops','protocol_errors','send_lag_p99_ms','peak_client_waiters')
cases=[]
for f in sorted(work.glob('n*-p*-r*-s*-rep*/after.json')):
 d=f.parent
 n,p,rate,secs,rep=map(int,re.fullmatch(r'n(\d+)-p(\d+)-r(\d+)-s(\d+)-rep(\d+)',d.name).groups())
 l=json.loads((d/'load.json').read_text())
 b=json.loads((d/'before.json').read_text())['stats'];a=json.loads(f.read_text());s=l['counts'];win=l['five_second_completions']
 assert set(s).issubset({'NOT_SENT','RESULT','REJECTED','INCOMPLETE'}),s
 assert l['issued']==s.get('RESULT',0)+s.get('REJECTED',0)+s.get('INCOMPLETE',0) and s.get('DRIVER_LIMIT',0)==0
 delta=lambda key:sum(x[key]-y[key] for x,y in zip(a,b))
 udp=lambda key:sum(x['Transport'][key]-y['Transport'][key] for x,y in zip(a,b))
 executed=[x['Executed']-y['Executed'] for x,y in zip(a,b)];admit=delta('Admitted')
 assert s.get('RESULT',0)+s.get('INCOMPLETE',0)==admit
 res=(d.name,n,p,rate,secs,rep,l['issued'],s.get('NOT_SENT',0),s['RESULT'],s.get('REJECTED',0),s.get('INCOMPLETE',0),round(l['throughput_ops_s'],2),win.get('0',0)/5,win.get(str(secs//5-1),0)/5,*(round(l['completed_subset_latency_ms'][q],2) for q in ['p50','p95','p99']),admit,min(executed),max(executed),round(udp('SentBytes')/1000/admit,2),udp('QueueDrops'),delta('Problems'),round(l['send_lag_ms']['p99'],2),l['peak_client_waiters'])
 cases.append(res)
with (work/'jobs-summary.csv').open('w') as out:
 wr=csv.writer(out);wr.writerow(names);wr.writerows(sorted(cases,key=lambda c:(c[1],-c[2],c[3],c[5])))
