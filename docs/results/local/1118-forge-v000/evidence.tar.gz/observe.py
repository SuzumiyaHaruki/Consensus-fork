"""Launch a fresh seven-replica loopback cluster per measurement. Run inside the private network namespace."""
import argparse
import csv
import json
import os
from pathlib import Path
import subprocess as sp
import tempfile
import secrets
import time
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent
APIS = [f'127.0.0.1:{7507+i}' for i in range(7)]
def write(path, data):
    path.write_text(json.dumps(data, indent=2)+'\n')
def stats():
    result = []
    for api in APIS:
        with urlopen('http://'+api+'/status', timeout=1.2) as r:
            result.append(json.load(r))
    return result
def sample(procs):
    mem = Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0]
    row = {'ns':time.time_ns(), 'available_kib':int(mem), 'replicas':[]}
    for proc in procs:
        fields = Path(f'/proc/{proc.pid}/stat').read_text().rsplit(')',1)[1].split()
        row['replicas'].append({'rss':int(fields[21])*os.sysconf('SC_PAGE_SIZE'),'cpu':(int(fields[11])+int(fields[12]))/os.sysconf('SC_CLK_TCK')})
    return row
def run(rate, repeat, seconds, batch):
    out=ROOT/'observation'/f'r{rate}-rep{repeat}-s{seconds}'
    assert batch == 32  # The candidate sets its own frame limit internally.
    out.mkdir(parents=True)
    cpus=sorted(os.sched_getaffinity(0))
    assert len(cpus)>=8
    procs=[]; files=[]
    try:
        with tempfile.TemporaryDirectory(prefix='keys-') as tmp:
            temp=Path(tmp)/'members'
            sp.run([ROOT/'cluster','-dir',temp,'-port','7500','-n','7','-f','4','-s','1','-e','1','-w','200ms','-workers','4'],check=True,stdout=sp.DEVNULL)
            cfgfile=temp/'config.json'
            cfg=json.loads(cfgfile.read_text())
            cfg.update(queue=1024,active=1024)
            write(cfgfile,cfg)
            for i in range(7):
                log=(out/f'server{i}.log').open('w');files.append(log)
                cmd=['taskset','-c',str(cpus[i]),ROOT/'server-observe','-config',cfgfile,'-id',str(i),'-procs','1','-net-queue','4096']
                procs.append(sp.Popen(cmd,stdout=log,stderr=sp.STDOUT))
            for _ in range(100):
                try: stats(); break
                except OSError: time.sleep(.05)
            else: raise RuntimeError('cluster startup failed')
            time.sleep(.5)
            write(out/'before.json', stats())
            log=(out/'driver.log').open('w');files.append(log)
            cmd=['taskset','-c',str(cpus[7]),ROOT/'load','-addresses',','.join(APIS),'-rate',str(rate),'-seconds',str(seconds),
                 '-timeout','15','-topology','random','-output',out,'-seed',str(17+repeat),'-max-inflight','16384']
            driver=sp.Popen(cmd,stdout=log,stderr=sp.STDOUT,env=dict(os.environ,GOMAXPROCS='1')); procs.append(driver)
            with (out/'samples.jsonl').open('w') as samples:
                limit=time.monotonic()+seconds+35
                while True:
                    if any(p.poll() is not None for p in procs[:7]): raise RuntimeError('replica exited')
                    snap=sample(procs[:7])
                    if snap['available_kib']<1100*1024: raise RuntimeError('memory guard')
                    try: snap['stats']=stats()
                    except OSError as e: snap['stats_error']=str(e)
                    print(json.dumps(snap),file=samples,flush=True)
                    if driver.poll() is not None: break
                    if time.monotonic()>limit: raise RuntimeError('driver deadline')
                    time.sleep(.92)
            if driver.returncode: raise RuntimeError('driver failed')
            # Capture cluster convergence independently of client replies.
            started=time.monotonic()
            while True:
                s=stats(); admitted=sum(v['Node']['Admitted'] for v in s)
                if sum(v['Node']['LocalExecuted'] for v in s)==admitted or time.monotonic()-started>=10: break
                time.sleep(.2)
            write(out/'after.json',s)
            last=time.monotonic()
            with (out/'idle.jsonl').open('w') as df:
                while True:
                    snap=stats()
                    print(json.dumps({'ns':time.time_ns(),'stats':snap}),file=df,flush=True)
                    if max(v['Node']['SlowestPeerPending'] for v in snap)==0 or time.monotonic()-last>95: break
                    time.sleep(1)
            print(out.name,(out/'driver.log').read_text().strip(),f'admitted={admitted} origin_executed={sum(v["Node"]["LocalExecuted"] for v in s)}',flush=True)
    finally:
        for p in procs:
            if p.poll() is None:p.terminate()
        for p in procs:
            try:p.wait(2)
            except sp.TimeoutExpired:p.kill();p.wait()
        for f in files:f.close()
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('cases',nargs='+',help='rate:repeat:seconds')
    parser.add_argument('--batch', type=int, default=32)
    args=parser.parse_args()
    for case in args.cases:run(*map(int,case.split(':')),batch=args.batch)
