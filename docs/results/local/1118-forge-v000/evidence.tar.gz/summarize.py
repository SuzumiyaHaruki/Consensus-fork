from pathlib import Path
import csv,json,math,statistics,collections
root=Path(__file__).resolve().parent
def save(path,rows):
    if not rows:return
    with path.open('w') as f:
        w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
def summarize(group):
    rows=[];windows=[]
    for f in sorted((root/group).glob('*/after.json')):
        folder=f.parent
        a=json.loads(f.read_text());b=json.loads((folder/'before.json').read_text())
        load=json.loads((folder/'load.json').read_text());start,end=load['start_ns'],load['end_ns'];dt=(end-start)/1e9
        bins=[0]*6;count=collections.Counter();sent=0;pending=0;lat=[]
        with (folder/'requests.csv').open() as data:
            for r in csv.DictReader(data):
                t0,t=int(r['sent_ns']),int(r['reply_ns']);count[r['status']]+=1
                sent+=bool(t0);pending+=bool(t0 and t0<=end<t)
                if r['status']=='OK':
                    lat.append((t-t0)/1e6)
                    if start<=t<=end:bins[min(5,(t-start)*6//(end-start))]+=1
        assert (count,sent,len(lat),sum(bins))==(load['counts'],load['issued'],load['completed'],load['window_completed'])
        lat.sort()
        def diff(section,key):return sum(y[section][key]-x[section][key] for x,y in zip(b,a))
        adm=diff('Node','Admitted')
        samples=[json.loads(l) for l in (folder/'samples.jsonl').read_text().splitlines()];sw=[s for s in samples if start<=s['ns']<=end]
        cores=sum(y['cpu']-x['cpu'] for x,y in zip(sw[0]['replicas'],sw[-1]['replicas']))/((sw[-1]['ns']-sw[0]['ns'])/1e9)
        ex=[y['Node']['Executed']-x['Node']['Executed'] for x,y in zip(b,a)]
        whole=bool(lat) and sent==len(lat)
        rows.append(dict(case=folder.name,rate=load['target_rate'],issued=sent,not_sent=load['planned']-sent,ok=len(lat),rejections=count['REJECTED'],incomplete=count['INCOMPLETE'],unknown=count['UNKNOWN'],transport_errors=count['TRANSPORT_ERROR'],invalid=count['INVALID_RESULT'],window_tps=round(sum(bins)/dt,1),first5=bins[0]/5,last5=bins[-1]/5,mean_ms=round(statistics.mean(lat),2) if whole else '',p99_ms=round(lat[math.ceil(len(lat)*.99)-1],2) if whole else '',waiters_at_input_end=pending,admitted=adm,origin_executed=diff('Node','LocalExecuted'),min_replica_exec=min(ex),max_replica_exec=max(ex),fast=diff('Node','Fast'),recoveries=diff('Node','Recoveries'),fetch_broadcasts=diff('Node','Fetches'),net_failures=diff('Network','Failures'),ingress_refusals=diff('Network','Dropped'),send_busy=diff('Node','SendBusy'),window_short=diff('Node','WindowShort'),violations=diff('Node','Violations'),gob_kB_per_admit=round(diff('Network','Bytes')/adm/1000,2),remote_messages_per_admit=round(diff('Network','Messages')/adm,2),core_equiv=round(cores,2),peak_rss_mib=round(max(sum(v['rss'] for v in s['replicas']) for s in samples)/2**20),send_lag_p99_ms=round(load['send_lag_ms']['p99'],2)))
        for i,n in enumerate(bins):windows.append(dict(case=folder.name,start_s=5*i,end_s=5*(i+1),ok_per_s=n/5))
    save(root/(group+'-summary.csv'),rows);save(root/(group+'-windows.csv'),windows)
if __name__=='__main__':
    for group in ('jobs','observation'):summarize(group)
