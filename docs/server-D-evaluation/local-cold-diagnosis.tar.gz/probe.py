"""Short local diagnosis; not a server performance measurement."""
import concurrent.futures
import sys
import time
from pathlib import Path

sys.path.insert(0, '/home/nitro/Desktop/consensus-server-evaluation-1111/scripts')
from common import Cluster, dump, rpc
from cases import warm

out = Path(__file__).parent / 'local-probe'
options = dict(pin=False, cpu_per_replica=2, driver_cpus=2, drain_seconds=60,
               preparation_seconds=120, observation_seconds=2)
c = Cluster('baseline', out, dict(n=7, f=4, s=1, e=1, k=64, workers=4, window_ms=1000), options)
try:
    print('warmup', warm(c)['status'], flush=True)
    c.fault(6, [{'class': 'data', 'drop': True, 'origin': 0, 'after': 10,
                 'through': 1010, 'until_ns': time.time_ns() + 300_000_000_000}])
    result = c.load('prefill', sequential=True, count=1000, rate=0, entries=[0],
                    topology='single', workload='hot', key_prefix='history', preparation_seconds=120)
    assert result['all_completed'], result['counts']
    assert c.wait_executed(1070, replicas=list(range(6)), timeout=30)['complete']
    print('prepared', flush=True)
    c.fault(6, [])
    c.start_monitor()
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        pending = pool.submit(c.load, 'cold-read', sequential=True, count=1, rate=0,
                              entries=[6], topology='single', workload='get',
                              key_prefix='history', preparation_seconds=40)
        for second in range(40):
            if second == 10:
                rpc(c.addresses[6], '/bench/profile?kind=cpu&action=start', {})
            if second == 30:
                rpc(c.addresses[6], '/bench/profile?kind=cpu&action=stop', {})
                rpc(c.addresses[6], '/bench/profile?kind=allocs&action=sample', {})
            if second in (10, 20, 30):
                stats = rpc(c.addresses[6], '/bench/stats', timeout=10)[1]
                dump(out / f'stats-{second}.json', stats)
                print(second, stats, flush=True)
            time.sleep(1)
        dump(out / 'diagnosis-result.json', pending.result())
finally:
    c.close()
