from pathlib import Path
import csv
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from statistics import mean

root = Path(__file__).resolve().parent
rows = list(csv.DictReader((root / "windows.csv").open()))
fig, ax = plt.subplots(figsize=(8.8,4.1), layout="constrained")
for key, name, color, mark in [
    ("gob-base", "Gob", "#1b5b90","o"),
    ("json-test", "JSON", "#be5a10","s"),
    ("proto-test", "Protobuf, converted", "#943e68","D"),
    ("reuse-test", "Protobuf, send objects reused", "#6649a7","^"),
    ("gob-notice", "Gob + all-stored notice", "#157c6b","v"),
]:
    series = [[float(r["applied_per_s"]) for r in rows if r["case"]==f"{key}-r4500-rep{i}-s30"] for i in (1,2)]
    assert all(len(y)==6 for y in series)
    xs = [2.5 + 5*i for i in range(6)]
    ax.fill_between(xs, list(map(min,zip(*series))),list(map(max,zip(*series))),color=color,alpha=.10,linewidth=0)
    ax.plot(xs,list(map(mean,zip(*series))),color=color,marker=mark,ms=4,linewidth=2,label=name)
ax.set(xlim=(0,30),ylim=(0,4900),xlabel="Time since load began (s)",ylabel="Executed replies per second")
ax.grid(axis="y",alpha=.22)
ax.spines[["top","right"]].set_visible(False)
ax.legend(loc="lower left",fontsize=8,frameon=False)
fig.savefig(root / "window-throughput.png",dpi=180)
